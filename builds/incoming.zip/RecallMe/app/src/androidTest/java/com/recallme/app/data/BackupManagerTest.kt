package com.recallme.app.data

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Verifie que l'export/import JSON preserve les donnees et gere les fichiers
 * invalides sans planter (section "Compatibilité des anciennes sauvegardes").
 * Instrumente car org.json necessite un environnement Android.
 */
@RunWith(AndroidJUnit4::class)
class BackupManagerTest {

    @Test
    fun exportPuisImport_conserveLesDonnees() {
        val reminders = listOf(
            Reminder(id = 1, title = "Réviser", message = "Chapitre 3", dateTimeMillis = 1_800_000_000_000L, repeatRule = "WEEKLY"),
            Reminder(id = 2, title = "Sport", dateTimeMillis = 1_800_100_000_000L, isCompleted = true)
        )
        val categories = listOf(Category(id = 1, name = "Étude", colorHex = "#2F6FED", isDefault = true))
        val locations = listOf(GeoLocation(id = 1, name = "Maison", latitude = 48.85, longitude = 2.35, radiusMeters = 150))

        val json = BackupManager.buildBackupJson(reminders, categories, locations)
        val result = BackupManager.parseBackupJson(json)

        assertTrue(result.isSuccess)
        val backup = result.getOrThrow()
        assertEquals(2, backup.reminders.size)
        assertEquals("Réviser", backup.reminders[0].title)
        assertEquals("WEEKLY", backup.reminders[0].repeatRule)
        assertTrue(backup.reminders[1].isCompleted)
        assertEquals(1, backup.categories.size)
        assertEquals("Étude", backup.categories[0].name)
        assertEquals(1, backup.locations.size)
        assertEquals("Maison", backup.locations[0].name)
    }

    @Test
    fun fichierVide_renvoieUnEchecExplicite() {
        val result = BackupManager.parseBackupJson("")
        assertTrue(result.isFailure)
    }

    @Test
    fun fichierCorrompu_neFaitPasPlanterLApp() {
        val result = BackupManager.parseBackupJson("{ceci n'est pas du json valide")
        assertTrue(result.isFailure)
    }

    @Test
    fun sauvegardeSansCertainsChamps_utiliseLesValeursParDefaut() {
        val minimalJson = """{"reminders":[{"title":"Sans date"}],"categories":[],"locations":[]}"""
        val result = BackupManager.parseBackupJson(minimalJson)

        assertTrue(result.isSuccess)
        val backup = result.getOrThrow()
        assertEquals("Sans date", backup.reminders[0].title)
        assertEquals("NONE", backup.reminders[0].repeatRule)
        assertFalse(backup.reminders[0].isCompleted)
    }
}
