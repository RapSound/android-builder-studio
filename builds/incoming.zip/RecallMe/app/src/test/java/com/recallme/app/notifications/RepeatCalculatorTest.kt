package com.recallme.app.notifications

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.util.Calendar

/**
 * Verifie que la prochaine occurrence d'un rappel recurrent est correctement
 * calculee pour chaque type de repetition (section "Repetition").
 */
class RepeatCalculatorTest {

    private fun calendarFor(year: Int, month: Int, day: Int, hour: Int, minute: Int): Calendar {
        return Calendar.getInstance().apply {
            set(year, month, day, hour, minute, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }

    @Test
    fun `aucune repetition renvoie null`() {
        val base = calendarFor(2026, Calendar.JANUARY, 15, 9, 30).timeInMillis
        val next = RepeatCalculator.nextOccurrence(base, "NONE")
        assertNull(next)
    }

    @Test
    fun `repetition quotidienne ajoute un jour`() {
        val base = calendarFor(2026, Calendar.JANUARY, 15, 9, 30)
        val expected = (base.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis

        val next = RepeatCalculator.nextOccurrence(base.timeInMillis, "DAILY")

        assertEquals(expected, next)
    }

    @Test
    fun `repetition hebdomadaire ajoute sept jours`() {
        val base = calendarFor(2026, Calendar.JANUARY, 15, 9, 30)
        val expected = (base.clone() as Calendar).apply { add(Calendar.WEEK_OF_YEAR, 1) }.timeInMillis

        val next = RepeatCalculator.nextOccurrence(base.timeInMillis, "WEEKLY")

        assertEquals(expected, next)
    }

    @Test
    fun `repetition mensuelle gere le changement d'annee`() {
        val base = calendarFor(2025, Calendar.DECEMBER, 15, 9, 30)
        val expected = calendarFor(2026, Calendar.JANUARY, 15, 9, 30).timeInMillis

        val next = RepeatCalculator.nextOccurrence(base.timeInMillis, "MONTHLY")

        assertEquals(expected, next)
    }

    @Test
    fun `repetition annuelle gere le 29 fevrier`() {
        // Le calendrier Java reporte le 29 fevrier au 1er mars les annees non bissextiles.
        val base = calendarFor(2024, Calendar.FEBRUARY, 29, 8, 0)
        val expected = (base.clone() as Calendar).apply { add(Calendar.YEAR, 1) }.timeInMillis

        val next = RepeatCalculator.nextOccurrence(base.timeInMillis, "YEARLY")

        assertEquals(expected, next)
    }

    @Test
    fun `regle inconnue est traitee comme aucune repetition`() {
        val base = calendarFor(2026, Calendar.JANUARY, 15, 9, 30).timeInMillis
        val next = RepeatCalculator.nextOccurrence(base, "UNEXPECTED_VALUE")
        assertNull(next)
    }
}
