package com.recallme.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Verifie la logique de plage horaire du mode Ne pas deranger, y compris
 * le cas particulier ou la plage traverse minuit (ex : 22h -> 7h).
 */
class SettingsRepositoryDndTest {

    @Test
    fun `plage normale sans passage minuit`() {
        val start = 9 * 60   // 09:00
        val end = 18 * 60    // 18:00

        assertTrue(SettingsRepository.isMinuteWithinDndRange(12 * 60, start, end))
        assertFalse(SettingsRepository.isMinuteWithinDndRange(8 * 60, start, end))
        assertFalse(SettingsRepository.isMinuteWithinDndRange(19 * 60, start, end))
    }

    @Test
    fun `plage traversant minuit`() {
        val start = 22 * 60  // 22:00
        val end = 7 * 60      // 07:00

        assertTrue(SettingsRepository.isMinuteWithinDndRange(23 * 60, start, end))   // 23h -> dans la plage
        assertTrue(SettingsRepository.isMinuteWithinDndRange(3 * 60, start, end))    // 3h du matin -> dans la plage
        assertFalse(SettingsRepository.isMinuteWithinDndRange(12 * 60, start, end))  // midi -> hors plage
    }

    @Test
    fun `bornes de la plage`() {
        val start = 22 * 60
        val end = 7 * 60

        assertTrue(SettingsRepository.isMinuteWithinDndRange(start, start, end))
        assertFalse(SettingsRepository.isMinuteWithinDndRange(end, start, end))
    }
}
