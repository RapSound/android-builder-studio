package com.recallme.app.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

// Couleur principale — Rouge profond
val RedPrimary = Color(0xFFD81F32)

// Couleur secondaire — Rouge clair (degrades, halos)
val RedSecondary = Color(0xFFFF4D5A)

// Couleur d'accentuation — Rouge lumineux (bouton +, confirmations)
val RedAccent = Color(0xFFFF5A5F)

// Etats (identiques quel que soit le theme)
val SuccessGreen = Color(0xFF34C759)
val InfoBlue = Color(0xFF3B82F6)
val WarningOrange = Color(0xFFFF9500)
val CriticalRed = Color(0xFFFF3B30)

// Themes predefinis (apercu dans Personnalisation)
val ThemeBlue = Color(0xFF2F6FED)
val ThemeGreen = Color(0xFF1FAA59)
val ThemeViolet = Color(0xFF7C3AED)
val ThemePink = Color(0xFFEC4899)
val ThemeOrange = Color(0xFFFF7A1A)

// Categories predefinies
val CategoryPersonnel = Color(0xFFD81F32)
val CategoryTravail = Color(0xFFFF7A1A)
val CategorySante = Color(0xFF1FAA59)
val CategoryEtude = Color(0xFF2F6FED)
val CategorySport = Color(0xFF7C3AED)

// --- Palette sombre (par defaut) ---
private val DarkBackgroundPrimary = Color(0xFF121212)
private val DarkBackgroundSecondary = Color(0xFF1D1D1D)
private val DarkCardBackground = Color(0xFF242424)
private val DarkBorderColor = Color(0xFF323232)
private val DarkTextPrimary = Color(0xFFFFFFFF)
private val DarkTextSecondary = Color(0xFFB3B3B3)
private val DarkTextDisabled = Color(0xFF6E6E6E)

// --- Palette claire ---
private val LightBackgroundPrimary = Color(0xFFF7F7F8)
private val LightBackgroundSecondary = Color(0xFFEFEFF1)
private val LightCardBackground = Color(0xFFFFFFFF)
private val LightBorderColor = Color(0xFFE1E1E4)
private val LightTextPrimary = Color(0xFF1A1A1A)
private val LightTextSecondary = Color(0xFF6B6B70)
private val LightTextDisabled = Color(0xFFAFAFB4)

/**
 * Etat global du theme actif (sombre/clair), lu par les proprietes ci-dessous.
 * Pilote par RecallMeTheme() ; base sur un mutableStateOf pour que toute lecture
 * (y compris dans un DrawScope de Canvas, hors composition) declenche le
 * redessin necessaire au bon moment — voir section "Apparence".
 */
object AppTheme {
    var isDark by mutableStateOf(true)
}

// Ces proprietes conservent volontairement les memes noms qu'auparavant :
// tous les ecrans existants continuent de fonctionner sans modification,
// mais suivent desormais dynamiquement le theme actif.
val BackgroundPrimary: Color get() = if (AppTheme.isDark) DarkBackgroundPrimary else LightBackgroundPrimary
val BackgroundSecondary: Color get() = if (AppTheme.isDark) DarkBackgroundSecondary else LightBackgroundSecondary
val CardBackground: Color get() = if (AppTheme.isDark) DarkCardBackground else LightCardBackground
val BorderColor: Color get() = if (AppTheme.isDark) DarkBorderColor else LightBorderColor
val TextPrimary: Color get() = if (AppTheme.isDark) DarkTextPrimary else LightTextPrimary
val TextSecondary: Color get() = if (AppTheme.isDark) DarkTextSecondary else LightTextSecondary
val TextDisabled: Color get() = if (AppTheme.isDark) DarkTextDisabled else LightTextDisabled
