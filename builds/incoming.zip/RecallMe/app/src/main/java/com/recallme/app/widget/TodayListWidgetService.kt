package com.recallme.app.widget

import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.recallme.app.R
import com.recallme.app.data.AppDatabase
import com.recallme.app.data.Reminder
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.text.SimpleDateFormat
import java.util.*

class TodayListWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        TodayListFactory(applicationContext)
}

private class TodayListFactory(private val context: android.content.Context) : RemoteViewsService.RemoteViewsFactory {

    private var reminders: List<Reminder> = emptyList()
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate() {}

    override fun onDataSetChanged() {
        // Chargement synchrone requis par l'API RemoteViewsFactory (section "Widgets").
        reminders = runBlocking {
            val dao = AppDatabase.getInstance(context).reminderDao()
            val all = dao.getAllActive().first()
            val cal = Calendar.getInstance()
            all.filter { !it.isCompleted && isSameDay(it.dateTimeMillis, cal.timeInMillis) }
                .sortedBy { it.dateTimeMillis }
        }
    }

    override fun onDestroy() {}
    override fun getCount(): Int = reminders.size
    override fun getViewAt(position: Int): RemoteViews {
        val reminder = reminders[position]
        val views = RemoteViews(context.packageName, R.layout.widget_list_item)
        views.setTextViewText(R.id.item_time, timeFormat.format(Date(reminder.dateTimeMillis)))
        views.setTextViewText(R.id.item_title, reminder.title)
        return views
    }

    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1
    override fun getItemId(position: Int): Long = reminders[position].id
    override fun hasStableIds(): Boolean = true

    private fun isSameDay(millis1: Long, millis2: Long): Boolean {
        val c1 = Calendar.getInstance().apply { timeInMillis = millis1 }
        val c2 = Calendar.getInstance().apply { timeInMillis = millis2 }
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) && c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
    }
}
