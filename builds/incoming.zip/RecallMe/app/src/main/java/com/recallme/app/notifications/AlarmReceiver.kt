package com.recallme.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.recallme.app.data.AppDatabase
import com.recallme.app.data.SettingsRepository
import com.recallme.app.widget.ReminderWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra("reminder_id", -1)
        val title = intent.getStringExtra("title") ?: "Rappel"
        val message = intent.getStringExtra("message") ?: ""

        NotificationHelper.createChannel(context)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Mode Ne pas deranger : la notification est affichee silencieusement
                // pendant la plage horaire configuree (section "Mode Ne pas déranger").
                val silent = SettingsRepository(context).isWithinDnd()
                NotificationHelper.showReminderNotification(context, reminderId, title, message, silent = silent)

                // Fiabilite : si le rappel est recurrent, on planifie automatiquement
                // la prochaine occurrence (section "Repetition").
                if (reminderId != -1L) {
                    val dao = AppDatabase.getInstance(context).reminderDao()
                    val reminder = dao.getById(reminderId)
                    if (reminder != null) {
                        val next = RepeatCalculator.nextOccurrence(reminder.dateTimeMillis, reminder.repeatRule)
                        if (next != null) {
                            val updated = reminder.copy(dateTimeMillis = next)
                            dao.update(updated)
                            AlarmScheduler.schedule(context, updated)
                        } else {
                            dao.setCompleted(reminderId, true)
                        }
                    }
                }
                com.recallme.app.widget.WidgetRefresher.refreshAll(context)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
