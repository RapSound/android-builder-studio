package com.recallme.app.data

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Genere un export PDF simple des statistiques (section "Statistiques").
 * Le PDF est cree dans le cache de l'app puis partage via FileProvider,
 * sans jamais transiter par un serveur externe.
 */
object StatisticsPdfExporter {

    fun export(
        context: Context,
        total: Int,
        completed: Int,
        pending: Int,
        completionRate: Float,
        perCategory: List<Pair<String, Int>>
    ): android.net.Uri {
        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val titlePaint = Paint().apply { color = Color.parseColor("#D81F32"); textSize = 26f; isFakeBoldText = true }
        val labelPaint = Paint().apply { color = Color.DKGRAY; textSize = 14f }
        val valuePaint = Paint().apply { color = Color.BLACK; textSize = 16f; isFakeBoldText = true }
        val sectionPaint = Paint().apply { color = Color.BLACK; textSize = 18f; isFakeBoldText = true }

        var y = 60f
        canvas.drawText("RecallMe — Statistiques", 40f, y, titlePaint)
        y += 20f
        canvas.drawText(SimpleDateFormat("d MMMM yyyy", Locale.FRENCH).format(Date()), 40f, y, labelPaint)
        y += 50f

        canvas.drawText("Total de rappels", 40f, y, labelPaint)
        canvas.drawText(total.toString(), 300f, y, valuePaint)
        y += 26f
        canvas.drawText("Rappels terminés", 40f, y, labelPaint)
        canvas.drawText(completed.toString(), 300f, y, valuePaint)
        y += 26f
        canvas.drawText("Rappels en cours", 40f, y, labelPaint)
        canvas.drawText(pending.toString(), 300f, y, valuePaint)
        y += 26f
        canvas.drawText("Taux de complétion", 40f, y, labelPaint)
        canvas.drawText("${(completionRate * 100).toInt()}%", 300f, y, valuePaint)
        y += 50f

        canvas.drawText("Répartition par catégorie", 40f, y, sectionPaint)
        y += 30f

        val maxValue = (perCategory.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
        val barPaint = Paint().apply { color = Color.parseColor("#D81F32") }
        perCategory.forEach { (name, count) ->
            canvas.drawText(name, 40f, y, labelPaint)
            canvas.drawText(count.toString(), 480f, y, valuePaint)
            val barWidth = 400f * (count.toFloat() / maxValue)
            canvas.drawRect(40f, y + 8f, 40f + barWidth, y + 20f, barPaint)
            y += 40f
        }

        document.finishPage(page)

        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, "recallme_stats_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }
}
