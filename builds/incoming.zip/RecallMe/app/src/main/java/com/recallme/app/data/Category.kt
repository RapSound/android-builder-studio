package com.recallme.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Categorie de rappel (Personnel, Travail, Sante, Etude, Sport, + personnalisees).
 */
@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: String,
    val icon: String = "label",
    val isDefault: Boolean = false
)
