package com.recallme.app.notifications

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.recallme.app.data.GeoLocation

/**
 * Encapsule l'API de geofencing de Google Play Services pour declencher
 * un rappel a l'entree/sortie d'une zone (section "Rappels géolocalisés").
 */
object GeofenceManager {

    private fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val background = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        } else true
        return fine && background
    }

    private fun geofencingClient(context: Context): GeofencingClient =
        LocationServices.getGeofencingClient(context)

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, GeofenceBroadcastReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    fun registerGeofence(context: Context, location: GeoLocation) {
        if (!hasLocationPermission(context) || !location.isActive) return

        val geofence = Geofence.Builder()
            .setRequestId(location.id.toString())
            .setCircularRegion(location.latitude, location.longitude, location.radiusMeters.toFloat())
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(
                (if (location.triggerOnEnter) Geofence.GEOFENCE_TRANSITION_ENTER else 0) or
                    (if (location.triggerOnExit) Geofence.GEOFENCE_TRANSITION_EXIT else 0)
            )
            .build()

        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(geofence)
            .build()

        runCatching {
            geofencingClient(context).addGeofences(request, pendingIntent(context))
        }
    }

    fun unregisterGeofence(context: Context, locationId: Long) {
        runCatching {
            geofencingClient(context).removeGeofences(listOf(locationId.toString()))
        }
    }

    fun registerAll(context: Context, locations: List<GeoLocation>) {
        locations.filter { it.isActive }.forEach { registerGeofence(context, it) }
    }
}
