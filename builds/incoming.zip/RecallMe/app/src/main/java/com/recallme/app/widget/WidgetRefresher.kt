package com.recallme.app.widget

import android.content.Context

/**
 * Point d'entree unique pour rafraichir tous les widgets RecallMe
 * apres une modification de donnees (creation, completion, suppression...).
 */
object WidgetRefresher {
    fun refreshAll(context: Context) {
        ReminderWidgetProvider.requestUpdate(context)
        TodayListWidgetProvider.requestUpdate(context)
    }
}
