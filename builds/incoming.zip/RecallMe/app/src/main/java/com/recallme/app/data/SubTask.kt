package com.recallme.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Sous-tache (checklist) rattachee a un rappel (section "Sous-taches").
 */
@Entity(tableName = "subtasks")
data class SubTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reminderId: Long,
    val title: String,
    val isChecked: Boolean = false,
    val position: Int = 0
)
