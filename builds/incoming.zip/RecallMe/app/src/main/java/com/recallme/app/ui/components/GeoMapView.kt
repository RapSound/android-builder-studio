package com.recallme.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.viewinterop.AndroidView
import com.recallme.app.data.GeoLocation
import com.recallme.app.ui.theme.RedPrimary
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Polygon

/**
 * Carte interactive OpenStreetMap (gratuite, sans cle API) affichant les
 * lieux de rappels geolocalises avec leur rayon de declenchement.
 * Un appui long sur la carte permet de choisir l'emplacement d'un nouveau lieu.
 */
@Composable
fun GeoMapView(
    locations: List<GeoLocation>,
    center: GeoPoint,
    modifier: Modifier = Modifier,
    onMapLongPress: ((GeoPoint) -> Unit)? = null
) {
    val accentColor = RedPrimary

    AndroidView(
        modifier = modifier,
        factory = { context ->
            MapView(context).apply {
                setMultiTouchControls(true)
                controller.setZoom(14.0)
                controller.setCenter(center)
            }
        },
        update = { mapView ->
            val centerKey = "${center.latitude},${center.longitude}"
            if (mapView.tag != centerKey) {
                mapView.controller.setCenter(center)
                mapView.tag = centerKey
            }
            mapView.overlays.clear()

            if (onMapLongPress != null) {
                val eventsReceiver = object : MapEventsReceiver {
                    override fun singleTapConfirmedHelper(p: GeoPoint?) = false
                    override fun longPressHelper(p: GeoPoint?): Boolean {
                        p?.let { onMapLongPress(it) }
                        return true
                    }
                }
                mapView.overlays.add(MapEventsOverlay(eventsReceiver))
            }

            locations.forEach { location ->
                val point = GeoPoint(location.latitude, location.longitude)

                val circle = Polygon(mapView).apply {
                    points = Polygon.pointsAsCircle(point, location.radiusMeters.toDouble())
                    fillColor = accentColor.copy(alpha = 0.2f).toArgb()
                    strokeColor = accentColor.toArgb()
                    strokeWidth = 2f
                }
                mapView.overlays.add(circle)

                val marker = Marker(mapView).apply {
                    position = point
                    title = location.name
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                }
                mapView.overlays.add(marker)
            }

            mapView.invalidate()
        }
    )
}
