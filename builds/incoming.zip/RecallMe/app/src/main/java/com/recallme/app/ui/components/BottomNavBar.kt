package com.recallme.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.theme.BackgroundSecondary
import com.recallme.app.ui.theme.TextDisabled

data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

val bottomNavItems = listOf(
    NavItem("home", "Notification", Icons.Filled.Notifications),
    NavItem("geo", "Localisation", Icons.Filled.LocationOn),
    NavItem("personalization", "Personnalisation", Icons.Filled.Palette),
    NavItem("history", "Historique", Icons.Filled.History),
    NavItem("settings", "Paramètres", Icons.Filled.Settings)
)

@Composable
fun RecallMeBottomBar(currentRoute: String, accentColor: Color, onNavigate: (String) -> Unit) {
    NavigationBar(containerColor = BackgroundSecondary) {
        bottomNavItems.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = accentColor,
                    selectedTextColor = accentColor,
                    unselectedIconColor = TextDisabled,
                    unselectedTextColor = TextDisabled,
                    indicatorColor = accentColor.copy(alpha = 0.15f)
                )
            )
        }
    }
}
