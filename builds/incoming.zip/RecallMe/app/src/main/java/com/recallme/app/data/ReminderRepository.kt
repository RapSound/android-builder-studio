package com.recallme.app.data

class ReminderRepository(
    private val reminderDao: ReminderDao,
    private val categoryDao: CategoryDao,
    private val geoLocationDao: GeoLocationDao,
    private val subTaskDao: SubTaskDao
) {
    val activeReminders = reminderDao.getAllActive()
    val history = reminderDao.getHistory()
    val trash = reminderDao.getTrash()
    val categories = categoryDao.getAll()
    val geoLocations = geoLocationDao.getAll()

    suspend fun addReminder(reminder: Reminder): Long = reminderDao.insert(reminder)
    suspend fun updateReminder(reminder: Reminder) = reminderDao.update(reminder)
    suspend fun deleteReminder(reminder: Reminder) = reminderDao.softDelete(reminder.id)
    suspend fun restoreReminder(id: Long) = reminderDao.restore(id)
    suspend fun deleteReminderPermanently(id: Long) = reminderDao.deletePermanently(id)
    suspend fun emptyTrash() = reminderDao.emptyTrash()
    suspend fun toggleCompleted(id: Long, completed: Boolean) = reminderDao.setCompleted(id, completed)
    suspend fun toggleFavorite(id: Long, favorite: Boolean) = reminderDao.setFavorite(id, favorite)
    suspend fun getReminder(id: Long) = reminderDao.getById(id)

    suspend fun addCategory(category: Category): Long = categoryDao.insert(category)

    suspend fun addLocation(location: GeoLocation): Long = geoLocationDao.insert(location)
    suspend fun updateLocation(location: GeoLocation) = geoLocationDao.update(location)
    suspend fun deleteLocation(location: GeoLocation) = geoLocationDao.delete(location)
    suspend fun activeLocations() = geoLocationDao.getActive()

    fun subTasksFor(reminderId: Long) = subTaskDao.getForReminder(reminderId)
    suspend fun addSubTask(subTask: SubTask): Long = subTaskDao.insert(subTask)
    suspend fun updateSubTask(subTask: SubTask) = subTaskDao.update(subTask)
    suspend fun deleteSubTask(subTask: SubTask) = subTaskDao.delete(subTask)
}
