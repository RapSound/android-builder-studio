package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onOpenLockSetup: () -> Unit = {},
    onOpenBackup: () -> Unit = {},
    onOpenStatistics: () -> Unit = {},
    onOpenDnd: () -> Unit = {}
) {
    val themeName by viewModel.themeName.collectAsState()
    val lockEnabled by viewModel.lockEnabled.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Text("Paramètres", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(20.dp))

            SectionTitle("Compte")
            SettingsCard {
                SettingsRow(
                    icon = Icons.Filled.Shield,
                    title = "Mode local",
                    subtitle = "100% privé",
                    trailing = { Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionTitle("Sécurité")
            SettingsCard {
                SettingsRow(
                    icon = Icons.Filled.Lock,
                    title = "Verrouillage de l'app",
                    subtitle = if (lockEnabled) "Activé" else "Désactivé",
                    onClick = onOpenLockSetup
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionTitle("Général")
            SettingsCard {
                SettingsRow(icon = Icons.Filled.Notifications, title = "Notifications", subtitle = "Ne pas déranger", onClick = onOpenDnd)
                Divider(color = BorderColor, thickness = 0.5.dp)
                SettingsRow(icon = Icons.Filled.Save, title = "Sauvegarde locale", subtitle = "Exporter / importer", onClick = onOpenBackup)
                Divider(color = BorderColor, thickness = 0.5.dp)
                SettingsRow(icon = Icons.Filled.Language, title = "Langue", subtitle = "Français")
                Divider(color = BorderColor, thickness = 0.5.dp)
                SettingsRow(icon = Icons.Filled.Schedule, title = "Fuseau horaire", subtitle = "Automatique")
                Divider(color = BorderColor, thickness = 0.5.dp)
                SettingsRow(icon = Icons.Filled.BarChart, title = "Statistiques", subtitle = "Suivi de tes rappels", onClick = onOpenStatistics)
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionTitle("Apparence")
            SettingsCard {
                SettingsRow(icon = Icons.Filled.Circle, title = "Thème", subtitle = themeName, iconTint = accentColor)
                Divider(color = BorderColor, thickness = 0.5.dp)
                SettingsRow(icon = Icons.Filled.Palette, title = "Personnalisation", subtitle = "Couleurs, icônes, widgets")
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardBackground)
                    .padding(4.dp)
            ) {
                ThemeModeChip("Sombre", themeMode == "dark", accentColor, Modifier.weight(1f)) { viewModel.setThemeMode("dark") }
                ThemeModeChip("Clair", themeMode == "light", accentColor, Modifier.weight(1f)) { viewModel.setThemeMode("light") }
                ThemeModeChip("Système", themeMode == "system", accentColor, Modifier.weight(1f)) { viewModel.setThemeMode("system") }
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionTitle("À propos")
            SettingsCard {
                SettingsRow(icon = Icons.Filled.HelpOutline, title = "Aide & FAQ")
                Divider(color = BorderColor, thickness = 0.5.dp)
                SettingsRow(icon = Icons.Filled.Info, title = "À propos de RecallMe", subtitle = "Version 2.0.0")
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun ThemeModeChip(label: String, selected: Boolean, accentColor: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) accentColor else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.White else TextSecondary, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = TextSecondary, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
    Spacer(modifier = Modifier.height(8.dp))
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = CardBackground, shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
}

@Composable
private fun SettingsRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    iconTint: Color = TextSecondary,
    trailing: @Composable (() -> Unit)? = null,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = iconTint)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.Medium)
            if (subtitle != null) {
                Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (trailing != null) {
            trailing()
        } else {
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextDisabled)
        }
    }
}
