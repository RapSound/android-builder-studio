package com.recallme.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.theme.BackgroundPrimary
import com.recallme.app.ui.theme.CardBackground
import com.recallme.app.ui.theme.TextPrimary
import com.recallme.app.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private data class OnboardingPage(val icon: ImageVector, val title: String, val description: String)

private val onboardingPages = listOf(
    OnboardingPage(
        Icons.Filled.Notifications,
        "Ne rate plus jamais rien",
        "Crée des rappels précis, avec ou sans répétition, et reçois des notifications fiables même app fermée."
    ),
    OnboardingPage(
        Icons.Filled.LocationOn,
        "Des rappels selon le lieu",
        "Active un rappel automatiquement quand tu arrives ou quittes un endroit : maison, université, salle de sport..."
    ),
    OnboardingPage(
        Icons.Filled.Palette,
        "Une app à ton image",
        "Choisis parmi plusieurs thèmes ou crée ta propre couleur d'accent pour personnaliser RecallMe."
    ),
    OnboardingPage(
        Icons.Filled.Shield,
        "100% privé",
        "Toutes tes données restent sur ton téléphone. Tu peux ajouter un verrouillage PIN ou biométrique à tout moment."
    )
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(accentColor: Color, onFinish: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { onboardingPages.size })
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().background(BackgroundPrimary).padding(24.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onFinish) {
                Text("Passer", color = TextSecondary)
            }
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { page ->
            val item = onboardingPages[page]
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(item.icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(52.dp))
                }
                Spacer(modifier = Modifier.height(32.dp))
                Text(
                    item.title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    item.description,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(onboardingPages.size) { index ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .size(if (pagerState.currentPage == index) 10.dp else 8.dp)
                        .clip(CircleShape)
                        .background(if (pagerState.currentPage == index) accentColor else CardBackground)
                )
            }
        }

        Button(
            onClick = {
                if (pagerState.currentPage < onboardingPages.size - 1) {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                } else {
                    onFinish()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text(
                if (pagerState.currentPage < onboardingPages.size - 1) "Suivant" else "Commencer",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
