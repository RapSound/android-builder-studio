package com.recallme.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Couleur d'accent active, personnalisable par l'utilisateur (section 8 du cahier des charges).
 * Par defaut : rouge profond (#D81F32).
 */
val LocalAccentColor = compositionLocalOf { RedPrimary }

@Composable
fun RecallMeTheme(
    accentColor: Color = RedPrimary,
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    // Synchronise l'etat global lu par les proprietes de Color.kt (BackgroundPrimary,
    // TextPrimary, etc.) afin que tous les ecrans existants suivent le theme actif
    // sans avoir besoin d'etre modifies individuellement.
    AppTheme.isDark = darkTheme

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = accentColor,
            secondary = RedSecondary,
            tertiary = RedAccent,
            background = BackgroundPrimary,
            surface = CardBackground,
            surfaceVariant = BackgroundSecondary,
            onPrimary = TextPrimary,
            onBackground = TextPrimary,
            onSurface = TextPrimary,
            outline = BorderColor,
            error = CriticalRed
        )
    } else {
        lightColorScheme(
            primary = accentColor,
            secondary = RedSecondary,
            tertiary = RedAccent,
            background = BackgroundPrimary,
            surface = CardBackground,
            surfaceVariant = BackgroundSecondary,
            onPrimary = Color.White,
            onBackground = TextPrimary,
            onSurface = TextPrimary,
            outline = BorderColor,
            error = CriticalRed
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        val activity = view.context as? android.app.Activity
        activity?.window?.let { window ->
            window.statusBarColor = BackgroundPrimary.toArgb()
            window.navigationBarColor = BackgroundPrimary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    CompositionLocalProvider(LocalAccentColor provides accentColor) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = RecallMeTypography,
            content = content
        )
    }
}
