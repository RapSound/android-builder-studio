package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LockSetupScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    val lockEnabled by viewModel.lockEnabled.collectAsState()
    val biometricEnabled by viewModel.biometricEnabled.collectAsState()
    var step by remember { mutableStateOf(if (lockEnabled) 0 else 1) } // 0 = reglages, 1 = creation PIN
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var confirming by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().background(BackgroundPrimary).padding(20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Retour", tint = TextPrimary, modifier = Modifier.clickable { onBack() })
            Spacer(modifier = Modifier.width(16.dp))
            Text("Verrouillage", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
        }
        Spacer(modifier = Modifier.height(24.dp))

        if (step == 0) {
            SettingsSwitchRow("Verrouillage par code PIN", lockEnabled, accentColor) { enabled ->
                if (enabled) {
                    step = 1
                } else {
                    viewModel.disableLock()
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            if (lockEnabled) {
                SettingsSwitchRow("Déverrouillage biométrique", biometricEnabled, accentColor) { enabled ->
                    viewModel.setBiometricEnabled(enabled)
                }
                Spacer(modifier = Modifier.height(12.dp))
                TextButton(onClick = { step = 1 }) { Text("Modifier le code PIN", color = accentColor) }
            }
        } else {
            Text(
                if (!confirming) "Choisissez un code à 4 chiffres" else "Confirmez le code",
                color = TextPrimary, fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                val current = if (!confirming) newPin else confirmPin
                repeat(4) { index ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    error -> MaterialTheme.colorScheme.error
                                    index < current.length -> accentColor
                                    else -> CardBackground
                                }
                            )
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "back")
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                keys.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        row.forEach { key ->
                            Box(
                                modifier = Modifier
                                    .size(58.dp)
                                    .clip(CircleShape)
                                    .background(CardBackground)
                                    .clickable(enabled = key.isNotEmpty()) {
                                        if (!confirming) {
                                            if (key == "back") newPin = newPin.dropLast(1)
                                            else if (newPin.length < 4) newPin += key
                                            if (newPin.length == 4) confirming = true
                                        } else {
                                            if (key == "back") confirmPin = confirmPin.dropLast(1)
                                            else if (confirmPin.length < 4) confirmPin += key
                                            if (confirmPin.length == 4) {
                                                if (confirmPin == newPin) {
                                                    scope.launch {
                                                        viewModel.setPin(newPin)
                                                        step = 0
                                                        confirming = false
                                                        newPin = ""
                                                        confirmPin = ""
                                                    }
                                                } else {
                                                    error = true
                                                    scope.launch {
                                                        kotlinx.coroutines.delay(400)
                                                        error = false
                                                        confirmPin = ""
                                                        confirming = false
                                                        newPin = ""
                                                    }
                                                }
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (key == "back") {
                                    Icon(Icons.Filled.ArrowBack, contentDescription = "Effacer", tint = TextPrimary)
                                } else if (key.isNotEmpty()) {
                                    Text(key, color = TextPrimary, style = MaterialTheme.typography.titleLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSwitchRow(title: String, checked: Boolean, accentColor: Color, onCheckedChange: (Boolean) -> Unit) {
    Surface(color = CardBackground, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.Medium)
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = accentColor)
            )
        }
    }
}
