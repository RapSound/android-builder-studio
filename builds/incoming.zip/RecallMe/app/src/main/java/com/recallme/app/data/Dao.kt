package com.recallme.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE isDeleted = 0 ORDER BY dateTimeMillis ASC")
    fun getAllActive(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE isDeleted = 0 AND isCompleted = 1 ORDER BY dateTimeMillis DESC")
    fun getHistory(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE isDeleted = 1 ORDER BY dateTimeMillis DESC")
    fun getTrash(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getById(id: Long): Reminder?

    @Insert
    suspend fun insert(reminder: Reminder): Long

    @Update
    suspend fun update(reminder: Reminder)

    @Delete
    suspend fun delete(reminder: Reminder)

    @Query("UPDATE reminders SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)

    @Query("UPDATE reminders SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("UPDATE reminders SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: Long)

    @Query("UPDATE reminders SET isDeleted = 0 WHERE id = :id")
    suspend fun restore(id: Long)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deletePermanently(id: Long)

    @Query("DELETE FROM reminders WHERE isDeleted = 1")
    suspend fun emptyTrash()
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAll(): Flow<List<Category>>

    @Insert
    suspend fun insert(category: Category): Long

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(categories: List<Category>)
}

@Dao
interface SubTaskDao {
    @Query("SELECT * FROM subtasks WHERE reminderId = :reminderId ORDER BY position ASC")
    fun getForReminder(reminderId: Long): Flow<List<SubTask>>

    @Insert
    suspend fun insert(subTask: SubTask): Long

    @Update
    suspend fun update(subTask: SubTask)

    @Delete
    suspend fun delete(subTask: SubTask)

    @Query("DELETE FROM subtasks WHERE reminderId = :reminderId")
    suspend fun deleteForReminder(reminderId: Long)

    @Query("SELECT COUNT(*) FROM subtasks WHERE reminderId = :reminderId")
    suspend fun countForReminder(reminderId: Long): Int

    @Query("SELECT COUNT(*) FROM subtasks WHERE reminderId = :reminderId AND isChecked = 1")
    suspend fun countCheckedForReminder(reminderId: Long): Int
}

@Dao
interface GeoLocationDao {
    @Query("SELECT * FROM geo_locations ORDER BY name ASC")
    fun getAll(): Flow<List<GeoLocation>>

    @Query("SELECT * FROM geo_locations WHERE isActive = 1")
    suspend fun getActive(): List<GeoLocation>

    @Insert
    suspend fun insert(location: GeoLocation): Long

    @Update
    suspend fun update(location: GeoLocation)

    @Delete
    suspend fun delete(location: GeoLocation)
}
