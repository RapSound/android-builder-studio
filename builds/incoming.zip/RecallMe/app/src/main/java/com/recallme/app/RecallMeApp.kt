package com.recallme.app

import android.app.Application
import com.recallme.app.data.AppDatabase
import com.recallme.app.data.LockRepository
import com.recallme.app.data.ReminderRepository
import com.recallme.app.data.SettingsRepository
import com.recallme.app.notifications.NotificationHelper

class RecallMeApp : Application() {

    lateinit var repository: ReminderRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var lockRepository: LockRepository
        private set

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)

        // Configuration de la bibliotheque de cartes OpenStreetMap (cache local, user-agent)
        org.osmdroid.config.Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = java.io.File(cacheDir, "osmdroid")
            osmdroidTileCache = java.io.File(cacheDir, "osmdroid/tiles")
        }

        val db = AppDatabase.getInstance(this)
        repository = ReminderRepository(db.reminderDao(), db.categoryDao(), db.geoLocationDao(), db.subTaskDao())
        settingsRepository = SettingsRepository(this)
        lockRepository = LockRepository(this)
    }
}
