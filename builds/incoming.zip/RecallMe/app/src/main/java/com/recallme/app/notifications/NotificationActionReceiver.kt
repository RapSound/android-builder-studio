package com.recallme.app.notifications

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.recallme.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Gere les actions rapides directement depuis la notification
 * (section "Notifications" : marquer comme termine, reporter de 15 minutes).
 */
class NotificationActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_COMPLETE = "com.recallme.app.action.COMPLETE"
        const val ACTION_SNOOZE = "com.recallme.app.action.SNOOZE"
        const val EXTRA_REMINDER_ID = "reminder_id"
        private const val SNOOZE_MINUTES = 15
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra(EXTRA_REMINDER_ID, -1)
        if (reminderId == -1L) return

        NotificationManagerCompat.from(context).cancel(reminderId.toInt())

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.getInstance(context).reminderDao()
                when (intent.action) {
                    ACTION_COMPLETE -> {
                        dao.setCompleted(reminderId, true)
                    }
                    ACTION_SNOOZE -> {
                        val reminder = dao.getById(reminderId)
                        if (reminder != null) {
                            val newTime = Calendar.getInstance().apply {
                                add(Calendar.MINUTE, SNOOZE_MINUTES)
                            }.timeInMillis
                            val updated = reminder.copy(dateTimeMillis = newTime)
                            dao.update(updated)
                            AlarmScheduler.schedule(context, updated)
                        }
                    }
                }
                com.recallme.app.widget.WidgetRefresher.refreshAll(context)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
