package com.recallme.app.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream

/**
 * Sauvegarde et restauration locales (section "Sauvegarde locale").
 * Format JSON simple, lisible, sans dependance externe.
 * Aucune donnee ne quitte l'appareil : l'utilisateur choisit lui-meme
 * l'emplacement du fichier via le selecteur systeme (Storage Access Framework).
 */
object BackupManager {

    fun buildBackupJson(
        reminders: List<Reminder>,
        categories: List<Category>,
        locations: List<GeoLocation>
    ): String {
        val root = JSONObject()
        root.put("version", "2.0.0")
        root.put("exportedAt", System.currentTimeMillis())

        val remindersArray = JSONArray()
        reminders.forEach { r ->
            remindersArray.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("title", r.title)
                    put("message", r.message)
                    put("dateTimeMillis", r.dateTimeMillis)
                    put("categoryId", r.categoryId ?: JSONObject.NULL)
                    put("repeatRule", r.repeatRule)
                    put("locationId", r.locationId ?: JSONObject.NULL)
                    put("isCompleted", r.isCompleted)
                    put("isFavorite", r.isFavorite)
                    put("isDeleted", r.isDeleted)
                }
            )
        }
        root.put("reminders", remindersArray)

        val categoriesArray = JSONArray()
        categories.forEach { c ->
            categoriesArray.put(
                JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("colorHex", c.colorHex)
                    put("icon", c.icon)
                    put("isDefault", c.isDefault)
                }
            )
        }
        root.put("categories", categoriesArray)

        val locationsArray = JSONArray()
        locations.forEach { l ->
            locationsArray.put(
                JSONObject().apply {
                    put("id", l.id)
                    put("name", l.name)
                    put("latitude", l.latitude)
                    put("longitude", l.longitude)
                    put("radiusMeters", l.radiusMeters)
                    put("isActive", l.isActive)
                }
            )
        }
        root.put("locations", locationsArray)

        return root.toString(2)
    }

    fun writeToUri(context: Context, uri: Uri, json: String) {
        context.contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
            out.write(json.toByteArray())
        }
    }

    fun readFromUri(context: Context, uri: Uri): String? {
        return context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
    }

    data class ParsedBackup(
        val reminders: List<Reminder>,
        val categories: List<Category>,
        val locations: List<GeoLocation>
    )

    /**
     * Analyse un fichier de sauvegarde. Gere les cas d'erreur (section "Compatibilite
     * des anciennes sauvegardes") : fichier vide, format invalide.
     */
    fun parseBackupJson(json: String): Result<ParsedBackup> {
        return try {
            if (json.isBlank()) return Result.failure(IllegalArgumentException("Le fichier de sauvegarde est vide."))
            val root = JSONObject(json)

            val reminders = mutableListOf<Reminder>()
            val remindersArray = root.optJSONArray("reminders") ?: JSONArray()
            for (i in 0 until remindersArray.length()) {
                val o = remindersArray.getJSONObject(i)
                reminders.add(
                    Reminder(
                        id = 0, // nouvel identifiant genere a l'insertion pour eviter les conflits
                        title = o.optString("title"),
                        message = o.optString("message", ""),
                        dateTimeMillis = o.optLong("dateTimeMillis"),
                        categoryId = if (o.isNull("categoryId")) null else o.optLong("categoryId"),
                        repeatRule = o.optString("repeatRule", "NONE"),
                        locationId = if (o.isNull("locationId")) null else o.optLong("locationId"),
                        isCompleted = o.optBoolean("isCompleted", false),
                        isFavorite = o.optBoolean("isFavorite", false),
                        isDeleted = o.optBoolean("isDeleted", false)
                    )
                )
            }

            val categories = mutableListOf<Category>()
            val categoriesArray = root.optJSONArray("categories") ?: JSONArray()
            for (i in 0 until categoriesArray.length()) {
                val o = categoriesArray.getJSONObject(i)
                categories.add(
                    Category(
                        id = 0,
                        name = o.optString("name"),
                        colorHex = o.optString("colorHex", "#D81F32"),
                        icon = o.optString("icon", "label"),
                        isDefault = o.optBoolean("isDefault", false)
                    )
                )
            }

            val locations = mutableListOf<GeoLocation>()
            val locationsArray = root.optJSONArray("locations") ?: JSONArray()
            for (i in 0 until locationsArray.length()) {
                val o = locationsArray.getJSONObject(i)
                locations.add(
                    GeoLocation(
                        id = 0,
                        name = o.optString("name"),
                        latitude = o.optDouble("latitude"),
                        longitude = o.optDouble("longitude"),
                        radiusMeters = o.optInt("radiusMeters", 150),
                        isActive = o.optBoolean("isActive", true)
                    )
                )
            }

            Result.success(ParsedBackup(reminders, categories, locations))
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Fichier de sauvegarde invalide ou corrompu."))
        }
    }
}
