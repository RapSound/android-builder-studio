package com.recallme.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represente un rappel (section "Creer un rappel" du cahier des charges).
 * Stockage 100% local, aucune donnee transmise (devise RecallMe).
 */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String = "",
    val dateTimeMillis: Long,
    val categoryId: Long? = null,
    val repeatRule: String = "NONE", // NONE, DAILY, WEEKLY, MONTHLY, YEARLY
    val imageUri: String? = null,
    val locationId: Long? = null,
    val isCompleted: Boolean = false,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false
)
