package com.recallme.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.recallme.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Fiabilite : le systeme doit continuer a fonctionner apres un redemarrage
 * ou une mise a jour de l'application (section "Fiabilite").
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getInstance(context)
                    val reminders = db.reminderDao().getAllActive().first()
                    val now = System.currentTimeMillis()
                    reminders
                        .filter { !it.isCompleted && it.dateTimeMillis > now }
                        .forEach { reminder -> AlarmScheduler.schedule(context, reminder) }

                    val locations = db.geoLocationDao().getActive()
                    GeofenceManager.registerAll(context, locations)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
