package com.recallme.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.recallme.app.R

/**
 * Widget affichant la liste complete des rappels du jour
 * (section "Widgets" du cahier des charges).
 */
class TodayListWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.recallme.app.widget.TODAY_LIST_REFRESH"

        fun requestUpdate(context: Context) {
            context.sendBroadcast(Intent(context, TodayListWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            })
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH || intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TodayListWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                onUpdate(context, manager, ids)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_today_list)
            val serviceIntent = Intent(context, TodayListWidgetService::class.java).apply {
                data = android.net.Uri.parse("recallme://widget/$id")
            }
            views.setRemoteAdapter(R.id.widget_list_view, serviceIntent)
            views.setEmptyView(R.id.widget_list_view, R.id.widget_list_empty)
            appWidgetManager.updateAppWidget(id, views)
            appWidgetManager.notifyAppWidgetViewDataChanged(id, R.id.widget_list_view)
        }
    }
}
