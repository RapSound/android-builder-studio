package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.data.Category
import com.recallme.app.data.Reminder
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(viewModel: RecallMeViewModel, accentColor: Color) {
    val history by viewModel.history.collectAsState()
    val trash by viewModel.trash.collectAsState()
    val categories by viewModel.categories.collectAsState()

    var tab by remember { mutableStateOf(0) } // 0 = Historique, 1 = Corbeille
    var categoryFilter by remember { mutableStateOf<Long?>(null) }
    var periodFilter by remember { mutableStateOf("Tout") }
    var confirmEmptyTrash by remember { mutableStateOf(false) }

    val periods = listOf("Tout", "7 jours", "30 jours")

    val filteredHistory = history
        .filter { categoryFilter == null || it.categoryId == categoryFilter }
        .filter { withinPeriod(it.dateTimeMillis, periodFilter) }

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Historique", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
                if (tab == 1 && trash.isNotEmpty()) {
                    Icon(
                        Icons.Filled.DeleteForever,
                        contentDescription = "Vider la corbeille",
                        tint = CriticalRed,
                        modifier = Modifier.clickable { confirmEmptyTrash = true }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(BackgroundSecondary)
                    .padding(4.dp)
            ) {
                ModePill("Historique", tab == 0, accentColor, Modifier.weight(1f)) { tab = 0 }
                ModePill("Corbeille (${trash.size})", tab == 1, accentColor, Modifier.weight(1f)) { tab = 1 }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (tab == 0) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip("Toutes", categoryFilter == null, accentColor) { categoryFilter = null }
                    }
                    items(categories) { cat ->
                        FilterChip(cat.name, categoryFilter == cat.id, accentColor) { categoryFilter = cat.id }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(periods) { p ->
                        FilterChip(p, periodFilter == p, accentColor) { periodFilter = p }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                if (filteredHistory.isEmpty()) {
                    EmptyState("Aucun rappel dans l'historique")
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 100.dp)
                    ) {
                        items(filteredHistory, key = { it.id }) { reminder ->
                            val category = categories.find { it.id == reminder.categoryId }
                            HistoryRow(reminder, category, accentColor) {
                                viewModel.deleteReminder(reminder)
                            }
                        }
                    }
                }
            } else {
                if (trash.isEmpty()) {
                    EmptyState("La corbeille est vide")
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 100.dp)
                    ) {
                        items(trash, key = { it.id }) { reminder ->
                            val category = categories.find { it.id == reminder.categoryId }
                            TrashRow(
                                reminder, category, accentColor,
                                onRestore = { viewModel.restoreReminder(reminder) },
                                onDeleteForever = { viewModel.deletePermanently(reminder) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmEmptyTrash) {
        AlertDialog(
            onDismissRequest = { confirmEmptyTrash = false },
            title = { Text("Vider la corbeille ?") },
            text = { Text("Cette action est définitive et supprimera tous les rappels de la corbeille.") },
            confirmButton = {
                TextButton(onClick = { viewModel.emptyTrash(); confirmEmptyTrash = false }) {
                    Text("Supprimer définitivement", color = CriticalRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmEmptyTrash = false }) { Text("Annuler") }
            }
        )
    }
}

private fun withinPeriod(millis: Long, period: String): Boolean {
    if (period == "Tout") return true
    val days = if (period == "7 jours") 7 else 30
    val cutoff = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000
    return millis >= cutoff
}

@Composable
private fun EmptyState(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(top = 48.dp), contentAlignment = Alignment.Center) {
        Text(text, color = TextSecondary)
    }
}

@Composable
private fun ModePill(text: String, selected: Boolean, accentColor: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) accentColor else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.White else TextSecondary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun FilterChip(text: String, selected: Boolean, accentColor: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) accentColor else CardBackground)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (selected) Color.White else TextSecondary, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun HistoryRow(reminder: Reminder, category: Category?, accentColor: Color, onDelete: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("d MMM · HH:mm", Locale.FRENCH) }
    Surface(color = CardBackground, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(reminder.title, color = TextPrimary, fontWeight = FontWeight.Medium)
                Text(
                    "${dateFormat.format(Date(reminder.dateTimeMillis))}${category?.let { " · ${it.name}" } ?: ""}",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Icon(Icons.Filled.Delete, contentDescription = "Supprimer", tint = TextSecondary, modifier = Modifier.clickable { onDelete() })
        }
    }
}

@Composable
private fun TrashRow(
    reminder: Reminder,
    category: Category?,
    accentColor: Color,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("d MMM · HH:mm", Locale.FRENCH) }
    Surface(color = CardBackground, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(reminder.title, color = TextPrimary, fontWeight = FontWeight.Medium)
                Text(
                    "${dateFormat.format(Date(reminder.dateTimeMillis))}${category?.let { " · ${it.name}" } ?: ""}",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Icon(Icons.Filled.Restore, contentDescription = "Restaurer", tint = accentColor, modifier = Modifier.clickable { onRestore() })
            Spacer(modifier = Modifier.width(16.dp))
            Icon(Icons.Filled.DeleteForever, contentDescription = "Supprimer définitivement", tint = CriticalRed, modifier = Modifier.clickable { onDeleteForever() })
        }
    }
}
