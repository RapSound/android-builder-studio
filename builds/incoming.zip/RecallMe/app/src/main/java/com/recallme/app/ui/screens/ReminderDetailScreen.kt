package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.recallme.app.data.SubTask
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReminderDetailScreen(
    viewModel: RecallMeViewModel,
    reminderId: Long,
    accentColor: Color,
    onBack: () -> Unit
) {
    val allReminders by viewModel.activeReminders.collectAsState()
    val history by viewModel.history.collectAsState()
    val reminder = (allReminders + history).find { it.id == reminderId }
    val categories by viewModel.categories.collectAsState()
    val subTasksFlow = remember(reminderId) { viewModel.subTasksFor(reminderId) }
    val subTasks by subTasksFlow.collectAsState(initial = emptyList())
    var newSubTask by remember { mutableStateOf("") }

    if (reminder == null) {
        Box(modifier = Modifier.fillMaxSize().background(BackgroundPrimary), contentAlignment = Alignment.Center) {
            Text("Rappel introuvable", color = TextSecondary)
        }
        return
    }

    val category = categories.find { it.id == reminder.categoryId }
    val dateFormat = remember { SimpleDateFormat("EEEE d MMMM yyyy · HH:mm", Locale.FRENCH) }

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(androidx.compose.foundation.rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Retour", tint = TextPrimary, modifier = Modifier.clickable { onBack() })
                Spacer(modifier = Modifier.width(16.dp))
                Text("Détail du rappel", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.weight(1f))
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "Supprimer",
                    tint = CriticalRed,
                    modifier = Modifier.clickable { viewModel.deleteReminder(reminder); onBack() }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (reminder.imageUri != null) {
                AsyncImage(
                    model = reminder.imageUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            Text(
                reminder.title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium,
                textDecoration = if (reminder.isCompleted) TextDecoration.LineThrough else null
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(dateFormat.format(Date(reminder.dateTimeMillis)), color = accentColor, fontWeight = FontWeight.Medium)

            if (category != null) {
                Spacer(modifier = Modifier.height(8.dp))
                val catColor = runCatching { Color(android.graphics.Color.parseColor(category.colorHex)) }.getOrDefault(accentColor)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(catColor.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(category.name, color = catColor, style = MaterialTheme.typography.bodyMedium)
                }
            }

            if (reminder.message.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(reminder.message, color = TextSecondary, style = MaterialTheme.typography.bodyLarge)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { viewModel.toggleCompleted(reminder) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (reminder.isCompleted) CardBackground else accentColor
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(
                    if (reminder.isCompleted) "Marquer comme non terminé" else "Marquer comme terminé",
                    color = if (reminder.isCompleted) TextPrimary else Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
            Text("Sous-tâches", color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                subTasks.forEach { subTask ->
                    SubTaskRow(subTask, accentColor,
                        onToggle = { viewModel.toggleSubTask(subTask) },
                        onDelete = { viewModel.deleteSubTask(subTask) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newSubTask,
                    onValueChange = { newSubTask = it },
                    placeholder = { Text("Ajouter une étape...", color = TextDisabled) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardBackground,
                        unfocusedContainerColor = CardBackground,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    Icons.Filled.Add,
                    contentDescription = "Ajouter",
                    tint = accentColor,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(CardBackground)
                        .clickable {
                            if (newSubTask.isNotBlank()) {
                                viewModel.addSubTask(reminder.id, newSubTask.trim())
                                newSubTask = ""
                            }
                        }
                        .padding(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SubTaskRow(subTask: SubTask, accentColor: Color, onToggle: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBackground)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = subTask.isChecked,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(checkedColor = accentColor)
        )
        Text(
            subTask.title,
            color = if (subTask.isChecked) TextSecondary else TextPrimary,
            textDecoration = if (subTask.isChecked) TextDecoration.LineThrough else null,
            modifier = Modifier.weight(1f)
        )
        Icon(
            Icons.Filled.Delete,
            contentDescription = "Supprimer",
            tint = TextDisabled,
            modifier = Modifier.clickable { onDelete() }
        )
    }
}
