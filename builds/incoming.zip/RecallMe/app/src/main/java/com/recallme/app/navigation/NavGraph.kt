package com.recallme.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.components.RecallMeBottomBar
import com.recallme.app.ui.screens.*

private val topLevelRoutes = setOf("home", "geo", "personalization", "history", "settings")

@Composable
fun RecallMeNavHost(viewModel: RecallMeViewModel, accentColor: Color, startAtCreate: Boolean = false) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "home"

    androidx.compose.runtime.LaunchedEffect(startAtCreate) {
        if (startAtCreate) {
            navController.navigate("create")
        }
    }

    Scaffold(
        bottomBar = {
            if (currentRoute in topLevelRoutes) {
                RecallMeBottomBar(currentRoute = currentRoute, accentColor = accentColor) { route ->
                    navController.navigate(route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(bottom = if (currentRoute in topLevelRoutes) padding.calculateBottomPadding() else 0.dp)
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = viewModel,
                    accentColor = accentColor,
                    onCreateReminder = { navController.navigate("create") },
                    onOpenReminder = { id -> navController.navigate("detail/$id") }
                )
            }
            composable("geo") {
                GeoRemindersScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable("personalization") {
                PersonalizationScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable("history") {
                HistoryScreen(viewModel = viewModel, accentColor = accentColor)
            }
            composable("settings") {
                SettingsScreen(
                    viewModel = viewModel,
                    accentColor = accentColor,
                    onOpenLockSetup = { navController.navigate("lock_setup") },
                    onOpenBackup = { navController.navigate("backup") },
                    onOpenStatistics = { navController.navigate("statistics") },
                    onOpenDnd = { navController.navigate("dnd") }
                )
            }
            composable("create") {
                CreateReminderScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable("lock_setup") {
                LockSetupScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable("backup") {
                BackupScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable("statistics") {
                StatisticsScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable("dnd") {
                DoNotDisturbScreen(viewModel = viewModel, accentColor = accentColor, onBack = { navController.popBackStack() })
            }
            composable(
                "detail/{reminderId}",
                arguments = listOf(navArgument("reminderId") { type = NavType.LongType })
            ) { backStackEntry ->
                val reminderId = backStackEntry.arguments?.getLong("reminderId") ?: -1L
                ReminderDetailScreen(
                    viewModel = viewModel,
                    reminderId = reminderId,
                    accentColor = accentColor,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
