package com.recallme.app.notifications

import java.util.Calendar

/**
 * Calcule la prochaine occurrence d'un rappel recurrent
 * (section "Repetition" : Aucune, Quotidien, Hebdomadaire, Mensuel, Annuel).
 */
object RepeatCalculator {
    fun nextOccurrence(currentMillis: Long, repeatRule: String): Long? {
        val calendar = Calendar.getInstance().apply { timeInMillis = currentMillis }
        when (repeatRule) {
            "DAILY" -> calendar.add(Calendar.DAY_OF_YEAR, 1)
            "WEEKLY" -> calendar.add(Calendar.WEEK_OF_YEAR, 1)
            "MONTHLY" -> calendar.add(Calendar.MONTH, 1)
            "YEARLY" -> calendar.add(Calendar.YEAR, 1)
            else -> return null
        }
        return calendar.timeInMillis
    }
}
