package com.recallme.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.recallme.app.MainActivity
import com.recallme.app.R
import com.recallme.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Widget d'ecran d'accueil affichant le prochain rappel actif
 * (section "Widgets" du cahier des charges).
 */
class ReminderWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.recallme.app.widget.REFRESH"

        fun requestUpdate(context: Context) {
            val intent = Intent(context, ReminderWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH || intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, ReminderWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                onUpdate(context, manager, ids)
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id) }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getInstance(context).reminderDao()
            val reminders = dao.getAllActive().first()
            val now = System.currentTimeMillis()
            val next = reminders
                .filter { !it.isCompleted && it.dateTimeMillis >= now }
                .minByOrNull { it.dateTimeMillis }

            val views = RemoteViews(context.packageName, R.layout.widget_recallme)

            if (next != null) {
                views.setTextViewText(R.id.widget_reminder_title, next.title)
                val format = SimpleDateFormat("EEEE d MMM · HH:mm", Locale.FRENCH)
                views.setTextViewText(R.id.widget_reminder_time, format.format(Date(next.dateTimeMillis)))
            } else {
                views.setTextViewText(R.id.widget_reminder_title, "Aucun rappel à venir")
                views.setTextViewText(R.id.widget_reminder_time, "")
            }

            val openIntent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_reminder_title, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
