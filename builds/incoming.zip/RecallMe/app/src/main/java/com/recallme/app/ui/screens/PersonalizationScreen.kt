package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*

data class ThemeOption(val name: String, val color: Color)

val predefinedThemes = listOf(
    ThemeOption("Rouge", RedPrimary),
    ThemeOption("Bleu", ThemeBlue),
    ThemeOption("Vert", ThemeGreen),
    ThemeOption("Violet", ThemeViolet),
    ThemeOption("Rose", ThemePink),
    ThemeOption("Orange", ThemeOrange),
    ThemeOption("AMOLED", Color(0xFF000000)),
    ThemeOption("Pastel", Color(0xFFB39DDB)),
    ThemeOption("Neon", Color(0xFFFF2079))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalizationScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    val themeName by viewModel.themeName.collectAsState()
    var selectedTheme by remember(themeName) { mutableStateOf(themeName) }
    var pendingColor by remember(accentColor) { mutableStateOf(accentColor) }
    var tab by remember { mutableStateOf(0) } // 0 = Themes, 1 = Couleurs

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.ArrowBack,
                    contentDescription = "Retour",
                    tint = TextPrimary,
                    modifier = Modifier.clickable { onBack() }
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text("Personnalisation", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(BackgroundSecondary)
                    .padding(4.dp)
            ) {
                PillTab("Thèmes", tab == 0, pendingColor, Modifier.weight(1f)) { tab = 0 }
                PillTab("Couleurs", tab == 1, pendingColor, Modifier.weight(1f)) { tab = 1 }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (tab == 0) {
                Text("Thèmes prédéfinis", color = TextSecondary, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(12.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.height(260.dp)
                ) {
                    items(predefinedThemes) { theme ->
                        ThemeSwatch(
                            theme = theme,
                            selected = selectedTheme == theme.name
                        ) {
                            selectedTheme = theme.name
                            pendingColor = theme.color
                        }
                    }
                }
            } else {
                Text("Couleur personnalisée", color = TextSecondary, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(12.dp))
                ColorPicker(color = pendingColor, onColorChange = {
                    pendingColor = it
                    selectedTheme = "Personnalisé"
                })
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Aperçu", color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = pendingColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, pendingColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Notifications, contentDescription = null, tint = pendingColor)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Titre du rappel", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Message du rappel...", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Text("09:30", color = pendingColor, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    viewModel.setThemeName(selectedTheme)
                    viewModel.setAccentColor(String.format("#%06X", 0xFFFFFF and pendingColor.toArgbInt()))
                },
                colors = ButtonDefaults.buttonColors(containerColor = pendingColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).padding(bottom = 24.dp)
            ) {
                Text("Appliquer", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PillTab(text: String, selected: Boolean, accentColor: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) accentColor else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.White else TextSecondary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ColorPicker(color: Color, onColorChange: (Color) -> Unit) {
    var r by remember(color) { mutableStateOf(color.red * 255) }
    var g by remember(color) { mutableStateOf(color.green * 255) }
    var b by remember(color) { mutableStateOf(color.blue * 255) }
    var hex by remember(color) { mutableStateOf(colorToHex(color)) }

    fun updateFromRgb(newR: Float, newG: Float, newB: Float) {
        r = newR; g = newG; b = newB
        val newColor = Color(newR / 255f, newG / 255f, newB / 255f)
        hex = colorToHex(newColor)
        onColorChange(newColor)
    }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        com.recallme.app.ui.components.ColorWheel(
            color = color,
            onColorChange = { newColor ->
                r = newColor.red * 255; g = newColor.green * 255; b = newColor.blue * 255
                hex = colorToHex(newColor)
                onColorChange(newColor)
            }
        )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(r / 255f, g / 255f, b / 255f))
    )

    Spacer(modifier = Modifier.height(16.dp))

    OutlinedTextField(
        value = hex,
        onValueChange = { input ->
            hex = input
            val parsed = runCatching { Color(android.graphics.Color.parseColor(if (input.startsWith("#")) input else "#$input")) }.getOrNull()
            if (parsed != null) {
                r = parsed.red * 255; g = parsed.green * 255; b = parsed.blue * 255
                onColorChange(parsed)
            }
        },
        label = { Text("Code HEX") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CardBackground,
            unfocusedContainerColor = CardBackground,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent
        ),
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(16.dp))

    ColorSlider("R", r, Color(0xFFFF5252)) { updateFromRgb(it, g, b) }
    ColorSlider("G", g, Color(0xFF4CAF50)) { updateFromRgb(r, it, b) }
    ColorSlider("B", b, Color(0xFF2196F3)) { updateFromRgb(r, g, it) }
}

@Composable
private fun ColorSlider(label: String, value: Float, trackColor: Color, onValueChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, modifier = Modifier.width(20.dp))
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..255f,
            colors = SliderDefaults.colors(thumbColor = trackColor, activeTrackColor = trackColor),
            modifier = Modifier.weight(1f)
        )
        Text(value.toInt().toString(), color = TextPrimary, modifier = Modifier.width(36.dp))
    }
}

private fun colorToHex(color: Color): String {
    return String.format(
        "#%02X%02X%02X",
        (color.red * 255).toInt(),
        (color.green * 255).toInt(),
        (color.blue * 255).toInt()
    )
}

private fun Color.toArgbInt(): Int = android.graphics.Color.argb(
    (alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt()
)

@Composable
private fun ThemeSwatch(theme: ThemeOption, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.Start,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardBackground)
            .border(
                width = if (selected) 2.dp else 0.dp,
                color = if (selected) theme.color else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    Brush.horizontalGradient(listOf(theme.color.copy(alpha = 0.5f), theme.color))
                )
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(theme.name, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
            if (selected) {
                Spacer(modifier = Modifier.width(4.dp))
                Icon(Icons.Filled.Check, contentDescription = null, tint = theme.color, modifier = Modifier.size(16.dp))
            }
        }
    }
}
