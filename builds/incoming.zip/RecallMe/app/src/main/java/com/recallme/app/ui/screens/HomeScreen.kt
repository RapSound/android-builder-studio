package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.data.Reminder
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.components.ReminderCard
import com.recallme.app.ui.theme.BackgroundPrimary
import com.recallme.app.ui.theme.TextDisabled
import com.recallme.app.ui.theme.TextPrimary
import com.recallme.app.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onCreateReminder: () -> Unit,
    onOpenReminder: (Long) -> Unit
) {
    val reminders by viewModel.activeReminders.collectAsState()
    val categories by viewModel.categories.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0 = Aujourd'hui, 1 = A venir
    var searchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val now = remember { Calendar.getInstance() }
    val todayReminders = reminders.filter { isSameDay(it.dateTimeMillis, now.timeInMillis) }
    val upcomingReminders = reminders.filter { !isSameDay(it.dateTimeMillis, now.timeInMillis) && it.dateTimeMillis > now.timeInMillis }
    val baseDisplayed = if (selectedTab == 0) todayReminders else upcomingReminders
    val displayed = if (searchActive && searchQuery.isNotBlank()) {
        reminders.filter { it.title.contains(searchQuery, ignoreCase = true) || it.message.contains(searchQuery, ignoreCase = true) }
    } else baseDisplayed

    Scaffold(
        containerColor = BackgroundPrimary,
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateReminder,
                containerColor = accentColor,
                shape = CircleShape,
                modifier = Modifier.size(64.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Créer un rappel", tint = Color.White)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundPrimary)
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Notifications, contentDescription = null, tint = accentColor)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("RecallMe", color = TextPrimary, style = MaterialTheme.typography.headlineMedium)
                }
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Rechercher",
                    tint = if (searchActive) accentColor else TextPrimary,
                    modifier = Modifier.clickable {
                        searchActive = !searchActive
                        if (!searchActive) searchQuery = ""
                    }
                )
            }

            if (searchActive) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher un rappel...", color = TextDisabled) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF1D1D1D),
                        unfocusedContainerColor = Color(0xFF1D1D1D),
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Onglets Aujourd'hui / A venir
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF1D1D1D))
                    .padding(4.dp)
            ) {
                TabPill("Aujourd'hui", selectedTab == 0, accentColor, Modifier.weight(1f)) { selectedTab = 0 }
                TabPill("À venir", selectedTab == 1, accentColor, Modifier.weight(1f)) { selectedTab = 1 }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        if (searchActive && searchQuery.isNotBlank()) "Résultats" else if (selectedTab == 0) "Aujourd'hui" else "À venir",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        SimpleDateFormat("EEEE d MMMM", Locale.FRENCH).format(Date()),
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Icon(Icons.Filled.Tune, contentDescription = "Filtrer", tint = TextSecondary)
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (displayed.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                    Text("Aucun rappel pour le moment", color = TextSecondary)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(displayed, key = { it.id }) { reminder ->
                        val category = categories.find { it.id == reminder.categoryId }
                        ReminderCard(
                            reminder = reminder,
                            category = category,
                            accentColor = accentColor,
                            onClick = { onOpenReminder(reminder.id) },
                            onToggleComplete = { viewModel.toggleCompleted(reminder) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(text: String, selected: Boolean, accentColor: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) accentColor else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else TextSecondary,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

private fun isSameDay(millis1: Long, millis2: Long): Boolean {
    val cal1 = Calendar.getInstance().apply { timeInMillis = millis1 }
    val cal2 = Calendar.getInstance().apply { timeInMillis = millis2 }
    return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
            cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
}
