package com.recallme.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Roue chromatique HSV (teinte + saturation) — section 8 "Personnalisation"
 * : roue chromatique complète en plus du HEX/RVB.
 */
@Composable
fun ColorWheel(
    color: Color,
    onColorChange: (Color) -> Unit,
    size: Dp = 220.dp
) {
    val hsv = remember(color) {
        val arr = FloatArray(3)
        android.graphics.Color.colorToHSV(
            android.graphics.Color.rgb((color.red * 255).toInt(), (color.green * 255).toInt(), (color.blue * 255).toInt()),
            arr
        )
        arr
    }
    var hue by remember(color) { mutableStateOf(hsv[0]) }
    var saturation by remember(color) { mutableStateOf(hsv[1]) }
    val value = if (hsv[2] <= 0f) 1f else hsv[2]

    fun emit() {
        onColorChange(Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, value))))
    }

    Box(
        modifier = Modifier
            .size(size)
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    val center = Offset(this.size.width / 2f, this.size.height / 2f)
                    val radius = min(this.size.width, this.size.height) / 2f
                    val dx = change.position.x - center.x
                    val dy = change.position.y - center.y
                    val distance = sqrt(dx * dx + dy * dy).coerceAtMost(radius)
                    saturation = (distance / radius).coerceIn(0f, 1f)
                    var angle = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
                    if (angle < 0) angle += 360f
                    hue = angle
                    emit()
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val center = Offset(this.size.width / 2f, this.size.height / 2f)
                    val radius = min(this.size.width, this.size.height) / 2f
                    val dx = offset.x - center.x
                    val dy = offset.y - center.y
                    val distance = sqrt(dx * dx + dy * dy).coerceAtMost(radius)
                    saturation = (distance / radius).coerceIn(0f, 1f)
                    var angle = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
                    if (angle < 0) angle += 360f
                    hue = angle
                    emit()
                }
            }
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val radius = min(this.size.width, this.size.height) / 2f
            val center = Offset(this.size.width / 2f, this.size.height / 2f)

            val hueColors = (0..360 step 10).map { deg ->
                Color(android.graphics.Color.HSVToColor(floatArrayOf(deg.toFloat(), 1f, 1f)))
            }
            drawCircle(
                brush = Brush.sweepGradient(hueColors, center),
                radius = radius,
                center = center
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White, Color.White.copy(alpha = 0f)),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            val angleRad = Math.toRadians(hue.toDouble())
            val cursorRadius = saturation * radius
            val cursorX = center.x + (cursorRadius * cos(angleRad)).toFloat()
            val cursorY = center.y + (cursorRadius * sin(angleRad)).toFloat()
            drawCircle(Color.White, radius = 10f, center = Offset(cursorX, cursorY), style = Stroke(3f))
            drawCircle(
                color = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, value))),
                radius = 7f,
                center = Offset(cursorX, cursorY)
            )
        }
    }
}
