package com.recallme.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.recallme.app.data.GeoLocation
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.components.GeoMapView
import com.recallme.app.ui.theme.*
import org.osmdroid.util.GeoPoint

@Composable
fun GeoRemindersScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val locations by viewModel.geoLocations.collectAsState()
    var mapMode by remember { mutableStateOf(true) }
    var radius by remember { mutableStateOf(150f) }
    var showAddDialog by remember { mutableStateOf(false) }
    var pendingPoint by remember { mutableStateOf<GeoPoint?>(null) }
    var mapCenter by remember { mutableStateOf(GeoPoint(48.8566, 2.3522)) } // Paris par defaut

    // Recupere la position actuelle si la permission est deja accordee, pour centrer la carte
    LaunchedEffect(Unit) {
        val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            runCatching {
                LocationServices.getFusedLocationProviderClient(context).lastLocation
                    .addOnSuccessListener { loc ->
                        if (loc != null) mapCenter = GeoPoint(loc.latitude, loc.longitude)
                    }
            }
        }
    }

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.ArrowBack,
                    contentDescription = "Retour",
                    tint = TextPrimary,
                    modifier = Modifier.clickable { onBack() }
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text("Rappels géolocalisés", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(BackgroundSecondary)
                    .padding(4.dp)
            ) {
                ModeTab("Carte", mapMode, accentColor, Modifier.weight(1f)) { mapMode = true }
                ModeTab("Liste", !mapMode, accentColor, Modifier.weight(1f)) { mapMode = false }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (mapMode) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(24.dp))
                ) {
                    GeoMapView(
                        locations = locations,
                        center = pendingPoint ?: mapCenter,
                        modifier = Modifier.fillMaxSize(),
                        onMapLongPress = { point ->
                            pendingPoint = point
                            showAddDialog = true
                        }
                    )
                    Icon(
                        Icons.Filled.MyLocation,
                        contentDescription = "Ma position",
                        tint = TextPrimary,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .clip(CircleShape)
                            .background(CardBackground)
                            .padding(8.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Appui long sur la carte pour ajouter un lieu",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Rayon : ${radius.toInt()} m", color = TextPrimary, fontWeight = FontWeight.Medium)
                Slider(
                    value = radius,
                    onValueChange = { radius = it },
                    valueRange = 50f..1000f,
                    colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                locations.forEach { location ->
                    LocationRow(location, accentColor) { active ->
                        viewModel.updateLocation(location.copy(isActive = active))
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { pendingPoint = mapCenter; showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).padding(bottom = 24.dp)
            ) {
                Text("Ajouter un lieu", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showAddDialog) {
        AddLocationDialog(
            onDismiss = { showAddDialog = false; pendingPoint = null },
            onConfirm = { name ->
                val point = pendingPoint ?: mapCenter
                viewModel.addLocation(
                    GeoLocation(
                        name = name,
                        latitude = point.latitude,
                        longitude = point.longitude,
                        radiusMeters = radius.toInt()
                    )
                )
                showAddDialog = false
                pendingPoint = null
            }
        )
    }
}

@Composable
private fun ModeTab(text: String, selected: Boolean, accentColor: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) accentColor else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.White else TextSecondary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LocationRow(location: GeoLocation, accentColor: Color, onToggle: (Boolean) -> Unit) {
    Surface(color = CardBackground, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.LocationOn, contentDescription = null, tint = accentColor)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(location.name, color = TextPrimary, fontWeight = FontWeight.Medium)
                Text(if (location.isActive) "Actif" else "Inactif", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
            Switch(
                checked = location.isActive,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = accentColor)
            )
        }
    }
}

@Composable
private fun AddLocationDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau lieu") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                placeholder = { Text("Ex : Maison, Université...") }
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onConfirm(name) }) { Text("Ajouter") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
