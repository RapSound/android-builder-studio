package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DoNotDisturbScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    val enabled by viewModel.dndEnabled.collectAsState()
    val startMinutes by viewModel.dndStartMinutes.collectAsState()
    val endMinutes by viewModel.dndEndMinutes.collectAsState()

    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().background(BackgroundPrimary).padding(20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Retour", tint = TextPrimary, modifier = Modifier.clickable { onBack() })
            Spacer(modifier = Modifier.width(16.dp))
            Text("Ne pas déranger", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Pendant cette plage horaire, tes rappels s'affichent toujours mais sans son ni vibration.",
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Surface(color = CardBackground, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Activer", color = TextPrimary, fontWeight = FontWeight.Medium)
                Switch(
                    checked = enabled,
                    onCheckedChange = { viewModel.setDndEnabled(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = accentColor)
                )
            }
        }

        if (enabled) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TimeCard("Début", startMinutes, accentColor, Modifier.weight(1f)) { showStartPicker = true }
                TimeCard("Fin", endMinutes, accentColor, Modifier.weight(1f)) { showEndPicker = true }
            }
        }
    }

    if (showStartPicker) {
        TimePickerDialogSimple(
            initialMinutes = startMinutes,
            onDismiss = { showStartPicker = false },
            onConfirm = { minutes -> viewModel.setDndRange(minutes, endMinutes); showStartPicker = false }
        )
    }
    if (showEndPicker) {
        TimePickerDialogSimple(
            initialMinutes = endMinutes,
            onDismiss = { showEndPicker = false },
            onConfirm = { minutes -> viewModel.setDndRange(startMinutes, minutes); showEndPicker = false }
        )
    }
}

@Composable
private fun TimeCard(label: String, minutes: Int, accentColor: Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(color = CardBackground, shape = RoundedCornerShape(16.dp), modifier = modifier.clickable { onClick() }) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(formatMinutes(minutes), color = accentColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }
    }
}

private fun formatMinutes(totalMinutes: Int): String {
    val h = totalMinutes / 60
    val m = totalMinutes % 60
    return "%02d:%02d".format(h, m)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialogSimple(initialMinutes: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val state = rememberTimePickerState(
        initialHour = initialMinutes / 60,
        initialMinute = initialMinutes % 60
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) { Text("OK") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        },
        text = { TimePicker(state = state) }
    )
}
