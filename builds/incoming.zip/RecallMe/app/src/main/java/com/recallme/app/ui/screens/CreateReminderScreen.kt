package com.recallme.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.recallme.app.data.Category
import com.recallme.app.data.Reminder
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateReminderScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    val categories by viewModel.categories.collectAsState()

    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<Category?>(null) }
    var repeatRule by remember { mutableStateOf("NONE") }
    var imageUri by remember { mutableStateOf<String?>(null) }
    var subTasks by remember { mutableStateOf(listOf<String>()) }
    var newSubTask by remember { mutableStateOf("") }
    val context = LocalContext.current

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            imageUri = uri.toString()
        }
    }
    val calendar = remember { Calendar.getInstance() }
    var dateLabel by remember {
        mutableStateOf(SimpleDateFormat("d MMMM yyyy", Locale.FRENCH).format(calendar.time))
    }
    var timeLabel by remember {
        mutableStateOf(SimpleDateFormat("HH:mm", Locale.getDefault()).format(calendar.time))
    }

    val dateDialogState = remember { mutableStateOf(false) }
    val timeDialogState = remember { mutableStateOf(false) }

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.ArrowBack,
                    contentDescription = "Retour",
                    tint = TextPrimary,
                    modifier = Modifier.clickable { onBack() }
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text("Créer un rappel", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
            }

            Spacer(modifier = Modifier.height(24.dp))

            FieldLabel("Titre")
            RecallTextField(value = title, onValueChange = { title = it }, placeholder = "Ex : Réviser le contrôle")

            Spacer(modifier = Modifier.height(20.dp))

            FieldLabel("Message (optionnel)")
            RecallTextField(value = message, onValueChange = { message = it }, placeholder = "Ajoutez un message...", singleLine = false)

            Spacer(modifier = Modifier.height(20.dp))

            FieldLabel("Date & Heure")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PickerChip(dateLabel, Modifier.weight(1f)) { dateDialogState.value = true }
                PickerChip(timeLabel, Modifier.weight(1f)) { timeDialogState.value = true }
            }

            Spacer(modifier = Modifier.height(20.dp))

            FieldLabel("Répétition")
            RepeatSelector(selected = repeatRule, accentColor = accentColor) { repeatRule = it }

            Spacer(modifier = Modifier.height(20.dp))

            FieldLabel("Catégorie")
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                categories.take(3).forEach { cat ->
                    CategoryChip(cat, selectedCategory?.id == cat.id, Modifier.weight(1f)) {
                        selectedCategory = cat
                    }
                }
            }
            if (categories.size > 3) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    categories.drop(3).forEach { cat ->
                        CategoryChip(cat, selectedCategory?.id == cat.id, Modifier.weight(1f)) {
                            selectedCategory = cat
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            FieldLabel("Image (optionnel)")
            if (imageUri == null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CardBackground)
                        .clickable { imagePicker.launch("image/*") },
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Image, contentDescription = null, tint = TextSecondary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Ajouter une image", color = TextSecondary)
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(14.dp))
                ) {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = "Image du rappel",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().clickable { imagePicker.launch("image/*") }
                    )
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Retirer l'image",
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.5f))
                            .clickable { imageUri = null }
                            .padding(4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            FieldLabel("Sous-tâches (optionnel)")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                subTasks.forEachIndexed { index, task ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBackground)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(task, color = TextPrimary, modifier = Modifier.weight(1f))
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Retirer",
                            tint = TextSecondary,
                            modifier = Modifier.clickable {
                                subTasks = subTasks.toMutableList().apply { removeAt(index) }
                            }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newSubTask,
                        onValueChange = { newSubTask = it },
                        placeholder = { Text("Ajouter une étape...", color = TextDisabled) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CardBackground,
                            unfocusedContainerColor = CardBackground,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        Icons.Filled.Add,
                        contentDescription = "Ajouter",
                        tint = accentColor,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBackground)
                            .clickable {
                                if (newSubTask.isNotBlank()) {
                                    subTasks = subTasks + newSubTask.trim()
                                    newSubTask = ""
                                }
                            }
                            .padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val millis = buildMillis(dateLabel, timeLabel)
                        viewModel.createReminder(
                            Reminder(
                                title = title,
                                message = message,
                                dateTimeMillis = millis,
                                categoryId = selectedCategory?.id,
                                repeatRule = repeatRule,
                                imageUri = imageUri
                            ),
                            subTaskTitles = subTasks
                        )
                        onBack()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .padding(bottom = 24.dp)
            ) {
                Text("Enregistrer", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (dateDialogState.value) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = calendar.timeInMillis)
        DatePickerDialog(
            onDismissRequest = { dateDialogState.value = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let {
                        calendar.timeInMillis = it
                        dateLabel = SimpleDateFormat("d MMMM yyyy", Locale.FRENCH).format(calendar.time)
                    }
                    dateDialogState.value = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { dateDialogState.value = false }) { Text("Annuler") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (timeDialogState.value) {
        val timePickerState = rememberTimePickerState(
            initialHour = calendar.get(Calendar.HOUR_OF_DAY),
            initialMinute = calendar.get(Calendar.MINUTE)
        )
        AlertDialog(
            onDismissRequest = { timeDialogState.value = false },
            confirmButton = {
                TextButton(onClick = {
                    calendar.set(Calendar.HOUR_OF_DAY, timePickerState.hour)
                    calendar.set(Calendar.MINUTE, timePickerState.minute)
                    timeLabel = SimpleDateFormat("HH:mm", Locale.getDefault()).format(calendar.time)
                    timeDialogState.value = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { timeDialogState.value = false }) { Text("Annuler") }
            },
            text = { TimePicker(state = timePickerState) }
        )
    }
}

private fun buildMillis(dateLabel: String, timeLabel: String): Long {
    return try {
        val format = SimpleDateFormat("d MMMM yyyy HH:mm", Locale.FRENCH)
        format.parse("$dateLabel $timeLabel")?.time ?: System.currentTimeMillis()
    } catch (e: Exception) {
        System.currentTimeMillis()
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, color = TextSecondary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    Spacer(modifier = Modifier.height(8.dp))
}

@Composable
private fun RecallTextField(value: String, onValueChange: (String) -> Unit, placeholder: String, singleLine: Boolean = true) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = TextDisabled) },
        singleLine = singleLine,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CardBackground,
            unfocusedContainerColor = CardBackground,
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PickerChip(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(CardBackground)
            .clickable { onClick() }
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = TextPrimary)
    }
}

@Composable
private fun RepeatSelector(selected: String, accentColor: Color, onSelect: (String) -> Unit) {
    val options = listOf(
        "NONE" to "Aucune",
        "DAILY" to "Quotidien",
        "WEEKLY" to "Hebdomadaire",
        "MONTHLY" to "Mensuel",
        "YEARLY" to "Annuel"
    )
    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(options) { (value, label) ->
            val isSelected = selected == value
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isSelected) accentColor else CardBackground)
                    .clickable { onSelect(value) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (isSelected) Color.White else TextSecondary, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun CategoryChip(category: Category, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color = runCatching { Color(android.graphics.Color.parseColor(category.colorHex)) }.getOrDefault(RedPrimary)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) color else CardBackground)
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(category.name, color = if (selected) Color.White else TextSecondary, fontWeight = FontWeight.Medium)
    }
}
