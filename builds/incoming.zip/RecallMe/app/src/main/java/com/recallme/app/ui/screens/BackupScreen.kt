package com.recallme.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun BackupScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            viewModel.exportBackup(uri)
            statusMessage = "Sauvegarde exportée avec succès."
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importBackup(uri) { success, error ->
                statusMessage = if (success) "Sauvegarde restaurée avec succès." else (error ?: "Échec de la restauration.")
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(BackgroundPrimary).padding(20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Retour", tint = TextPrimary, modifier = Modifier.clickable { onBack() })
            Spacer(modifier = Modifier.width(16.dp))
            Text("Sauvegarde locale", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Tes rappels, catégories et lieux restent uniquement sur cet appareil. " +
                "Tu choisis toi-même où enregistrer ou récupérer ton fichier de sauvegarde.",
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(28.dp))

        BackupActionCard(
            icon = Icons.Filled.CloudUpload,
            title = "Exporter une sauvegarde",
            subtitle = "Créer un fichier .json avec toutes tes données",
            accentColor = accentColor
        ) {
            val filename = "recallme_backup_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.json"
            exportLauncher.launch(filename)
        }

        Spacer(modifier = Modifier.height(16.dp))

        BackupActionCard(
            icon = Icons.Filled.CloudDownload,
            title = "Restaurer une sauvegarde",
            subtitle = "Importer un fichier .json existant",
            accentColor = accentColor
        ) {
            importLauncher.launch(arrayOf("application/json"))
        }

        statusMessage?.let {
            Spacer(modifier = Modifier.height(20.dp))
            Text(it, color = accentColor, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun BackupActionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(color = CardBackground, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.clickable { onClick() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
