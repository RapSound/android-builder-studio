package com.recallme.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.ui.theme.BackgroundPrimary
import com.recallme.app.ui.theme.CardBackground
import com.recallme.app.ui.theme.TextPrimary
import com.recallme.app.ui.theme.TextSecondary
import kotlinx.coroutines.delay

/**
 * Ecran affiche au lancement quand le verrouillage PIN/biometrie est actif
 * (section 187 "Securite" : acces refuse tant que l'authentification n'a pas reussi).
 */
@Composable
fun LockScreen(
    accentColor: Color,
    biometricEnabled: Boolean,
    onVerifyPin: suspend (String) -> Boolean,
    onUnlocked: () -> Unit,
    onRequestBiometric: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    LaunchedEffect(biometricEnabled) {
        if (biometricEnabled) onRequestBiometric()
    }

    LaunchedEffect(pin) {
        if (pin.length == 4) {
            checking = true
            val ok = onVerifyPin(pin)
            if (ok) {
                onUnlocked()
            } else {
                error = true
                delay(400)
                pin = ""
                error = false
            }
            checking = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundPrimary)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = accentColor, modifier = Modifier.size(48.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("RecallMe verrouillé", color = TextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Saisissez votre code pour continuer", color = TextSecondary)

        Spacer(modifier = Modifier.height(32.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            repeat(4) { index ->
                val filled = index < pin.length
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                error -> MaterialTheme.colorScheme.error
                                filled -> accentColor
                                else -> CardBackground
                            }
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", if (biometricEnabled) "bio" else "", "0", "back")
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            keys.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    row.forEach { key ->
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(CardBackground)
                                .clickable(enabled = key.isNotEmpty() && !checking) {
                                    when (key) {
                                        "back" -> pin = pin.dropLast(1)
                                        "bio" -> onRequestBiometric()
                                        else -> if (pin.length < 4) pin += key
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            when (key) {
                                "back" -> Icon(Icons.Filled.Backspace, contentDescription = "Effacer", tint = TextPrimary)
                                "bio" -> Icon(Icons.Filled.Fingerprint, contentDescription = "Empreinte", tint = accentColor)
                                "" -> {}
                                else -> Text(key, color = TextPrimary, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}
