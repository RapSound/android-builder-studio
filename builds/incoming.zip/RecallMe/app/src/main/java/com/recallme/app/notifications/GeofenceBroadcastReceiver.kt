package com.recallme.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import com.recallme.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GeofenceBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return

        val isEnter = event.geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER
        val isExit = event.geofenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT
        if (!isEnter && !isExit) return

        val triggeredIds = event.triggeringGeofences?.map { it.requestId } ?: return
        if (triggeredIds.isEmpty()) return

        NotificationHelper.createChannel(context)

        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getInstance(context).geoLocationDao()
            val allLocations = dao.getActive()
            triggeredIds.forEach { requestId ->
                val location = allLocations.find { it.id.toString() == requestId } ?: return@forEach
                val message = if (isEnter) "Tu es arrivé à ${location.name}" else "Tu as quitté ${location.name}"
                NotificationHelper.showGeofenceNotification(
                    context,
                    location.name,
                    message,
                    notificationId = 20000 + location.id.toInt()
                )
            }
        }
    }
}
