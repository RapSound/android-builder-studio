package com.recallme.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

/**
 * Verrouillage local de l'application (section 187 "Securite").
 * Le PIN n'est jamais stocke en clair : seule son empreinte SHA-256 est conservee,
 * localement, sans jamais quitter l'appareil.
 */
class LockRepository(private val context: Context) {

    companion object {
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val LOCK_ENABLED = booleanPreferencesKey("lock_enabled")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
    }

    val isLockEnabled: Flow<Boolean> = context.dataStore.data.map { it[LOCK_ENABLED] ?: false }
    val isBiometricEnabled: Flow<Boolean> = context.dataStore.data.map { it[BIOMETRIC_ENABLED] ?: false }
    val hasPin: Flow<Boolean> = context.dataStore.data.map { !it[PIN_HASH].isNullOrBlank() }

    suspend fun setPin(pin: String) {
        context.dataStore.edit {
            it[PIN_HASH] = hash(pin)
            it[LOCK_ENABLED] = true
        }
    }

    suspend fun clearPin() {
        context.dataStore.edit {
            it.remove(PIN_HASH)
            it[LOCK_ENABLED] = false
            it[BIOMETRIC_ENABLED] = false
        }
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.dataStore.edit { it[BIOMETRIC_ENABLED] = enabled }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val storedHash = context.dataStore.data.map { it[PIN_HASH] }.first()
        return storedHash != null && storedHash == hash(pin)
    }

    private fun hash(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
