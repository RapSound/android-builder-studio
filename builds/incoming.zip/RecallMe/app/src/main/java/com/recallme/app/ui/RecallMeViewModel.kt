package com.recallme.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.recallme.app.RecallMeApp
import com.recallme.app.data.BackupManager
import com.recallme.app.data.Category
import com.recallme.app.data.GeoLocation
import com.recallme.app.data.Reminder
import com.recallme.app.notifications.AlarmScheduler
import com.recallme.app.notifications.GeofenceManager
import com.recallme.app.widget.ReminderWidgetProvider
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RecallMeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RecallMeApp
    private val repository = app.repository
    private val settings = app.settingsRepository
    private val lock = app.lockRepository

    val activeReminders: StateFlow<List<Reminder>> = repository.activeReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<Reminder>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trash: StateFlow<List<Reminder>> = repository.trash
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val geoLocations: StateFlow<List<GeoLocation>> = repository.geoLocations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accentColor: StateFlow<String> = settings.accentColor
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "#D81F32")

    val themeName: StateFlow<String> = settings.themeName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Rouge")

    val onboardingDone: StateFlow<Boolean?> = settings.onboardingDone
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val dndEnabled: StateFlow<Boolean> = settings.dndEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val dndStartMinutes: StateFlow<Int> = settings.dndStartMinutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 22 * 60)

    val dndEndMinutes: StateFlow<Int> = settings.dndEndMinutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 7 * 60)

    val themeMode: StateFlow<String> = settings.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "dark")

    fun setThemeMode(mode: String) {
        viewModelScope.launch { settings.setThemeMode(mode) }
    }

    fun setDndEnabled(enabled: Boolean) {
        viewModelScope.launch { settings.setDndEnabled(enabled) }
    }

    fun setDndRange(startMinutes: Int, endMinutes: Int) {
        viewModelScope.launch { settings.setDndRange(startMinutes, endMinutes) }
    }

    fun setOnboardingDone() {
        viewModelScope.launch { settings.setOnboardingDone() }
    }

    val lockEnabled: StateFlow<Boolean> = lock.isLockEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val biometricEnabled: StateFlow<Boolean> = lock.isBiometricEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun setPin(pin: String) {
        viewModelScope.launch { lock.setPin(pin) }
    }

    fun disableLock() {
        viewModelScope.launch { lock.clearPin() }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch { lock.setBiometricEnabled(enabled) }
    }

    suspend fun verifyPin(pin: String): Boolean = lock.verifyPin(pin)

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            val json = BackupManager.buildBackupJson(
                activeReminders.value + history.value,
                categories.value,
                geoLocations.value
            )
            BackupManager.writeToUri(app, uri, json)
        }
    }

    fun importBackup(uri: Uri, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val json = BackupManager.readFromUri(app, uri)
            if (json == null) {
                onResult(false, "Impossible de lire le fichier.")
                return@launch
            }
            val parsed = BackupManager.parseBackupJson(json)
            parsed.onSuccess { backup ->
                backup.categories.forEach { repository.addCategory(it) }
                backup.locations.forEach { repository.addLocation(it) }
                backup.reminders.forEach { reminder ->
                    val id = repository.addReminder(reminder)
                    if (!reminder.isCompleted && reminder.dateTimeMillis > System.currentTimeMillis()) {
                        AlarmScheduler.schedule(app, reminder.copy(id = id))
                    }
                }
                onResult(true, null)
            }.onFailure { e ->
                onResult(false, e.message)
            }
        }
    }

    fun createReminder(reminder: Reminder, subTaskTitles: List<String> = emptyList()) {
        viewModelScope.launch {
            val id = repository.addReminder(reminder)
            AlarmScheduler.schedule(app, reminder.copy(id = id))
            com.recallme.app.widget.WidgetRefresher.refreshAll(app)
            subTaskTitles.forEachIndexed { index, title ->
                if (title.isNotBlank()) {
                    repository.addSubTask(com.recallme.app.data.SubTask(reminderId = id, title = title, position = index))
                }
            }
        }
    }

    fun subTasksFor(reminderId: Long) = repository.subTasksFor(reminderId)

    fun toggleSubTask(subTask: com.recallme.app.data.SubTask) {
        viewModelScope.launch {
            repository.updateSubTask(subTask.copy(isChecked = !subTask.isChecked))
        }
    }

    fun addSubTask(reminderId: Long, title: String) {
        viewModelScope.launch {
            repository.addSubTask(com.recallme.app.data.SubTask(reminderId = reminderId, title = title))
        }
    }

    fun deleteSubTask(subTask: com.recallme.app.data.SubTask) {
        viewModelScope.launch { repository.deleteSubTask(subTask) }
    }

    fun toggleCompleted(reminder: Reminder) {
        viewModelScope.launch {
            repository.toggleCompleted(reminder.id, !reminder.isCompleted)
            com.recallme.app.widget.WidgetRefresher.refreshAll(app)
        }
    }

    fun toggleFavorite(reminder: Reminder) {
        viewModelScope.launch {
            repository.toggleFavorite(reminder.id, !reminder.isFavorite)
        }
    }

    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
            AlarmScheduler.cancel(app, reminder.id)
            com.recallme.app.widget.WidgetRefresher.refreshAll(app)
        }
    }

    fun restoreReminder(reminder: Reminder) {
        viewModelScope.launch {
            repository.restoreReminder(reminder.id)
            if (reminder.dateTimeMillis > System.currentTimeMillis()) {
                AlarmScheduler.schedule(app, reminder)
            }
        }
    }

    fun deletePermanently(reminder: Reminder) {
        viewModelScope.launch {
            repository.deleteReminderPermanently(reminder.id)
            AlarmScheduler.cancel(app, reminder.id)
        }
    }

    fun emptyTrash() {
        viewModelScope.launch { repository.emptyTrash() }
    }

    fun addLocation(location: GeoLocation) {
        viewModelScope.launch {
            val id = repository.addLocation(location)
            GeofenceManager.registerGeofence(app, location.copy(id = id))
        }
    }

    fun updateLocation(location: GeoLocation) {
        viewModelScope.launch {
            repository.updateLocation(location)
            if (location.isActive) {
                GeofenceManager.registerGeofence(app, location)
            } else {
                GeofenceManager.unregisterGeofence(app, location.id)
            }
        }
    }

    fun deleteLocation(location: GeoLocation) {
        viewModelScope.launch {
            repository.deleteLocation(location)
            GeofenceManager.unregisterGeofence(app, location.id)
        }
    }

    fun setAccentColor(hex: String) {
        viewModelScope.launch { settings.setAccentColor(hex) }
    }

    fun setThemeName(name: String) {
        viewModelScope.launch { settings.setThemeName(name) }
    }
}
