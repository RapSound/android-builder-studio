package com.recallme.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Reminder::class, Category::class, GeoLocation::class, SubTask::class],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao
    abstract fun categoryDao(): CategoryDao
    abstract fun geoLocationDao(): GeoLocationDao
    abstract fun subTaskDao(): SubTaskDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `subtasks` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`reminderId` INTEGER NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`isChecked` INTEGER NOT NULL DEFAULT 0, " +
                        "`position` INTEGER NOT NULL DEFAULT 0)"
                )
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "recallme.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance

                // Categories par defaut (section "Categorie" de la maquette)
                CoroutineScope(Dispatchers.IO).launch {
                    val dao = instance.categoryDao()
                    if (dao.count() == 0) {
                        dao.insertAll(
                            listOf(
                                Category(name = "Personnel", colorHex = "#D81F32", icon = "person", isDefault = true),
                                Category(name = "Travail", colorHex = "#FF7A1A", icon = "work", isDefault = true),
                                Category(name = "Santé", colorHex = "#1FAA59", icon = "health", isDefault = true),
                                Category(name = "Étude", colorHex = "#2F6FED", icon = "school", isDefault = true),
                                Category(name = "Sport", colorHex = "#7C3AED", icon = "sport", isDefault = true)
                            )
                        )
                    }
                }
                instance
            }
        }
    }
}
