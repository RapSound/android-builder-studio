package com.recallme.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.recallme.app.data.StatisticsPdfExporter
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.theme.*

@Composable
fun StatisticsScreen(
    viewModel: RecallMeViewModel,
    accentColor: Color,
    onBack: () -> Unit
) {
    val active by viewModel.activeReminders.collectAsState()
    val history by viewModel.history.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val context = LocalContext.current

    val allReminders = active + history
    val totalCount = allReminders.size
    val completedCount = allReminders.count { it.isCompleted }
    val pendingCount = totalCount - completedCount
    val completionRate = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f

    val perCategory = categories.associateWith { cat -> allReminders.count { it.categoryId == cat.id } }
        .filter { it.value > 0 }
        .toList()
        .sortedByDescending { it.second }

    Scaffold(containerColor = BackgroundPrimary) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Retour", tint = TextPrimary, modifier = Modifier.clickable { onBack() })
                Spacer(modifier = Modifier.width(16.dp))
                Text("Statistiques", color = TextPrimary, style = MaterialTheme.typography.titleLarge)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Total", totalCount.toString(), accentColor, Modifier.weight(1f))
                StatCard("Terminés", completedCount.toString(), SuccessGreen, Modifier.weight(1f))
                StatCard("En cours", pendingCount.toString(), InfoBlue, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Taux de complétion", color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(12.dp))

            Surface(color = CardBackground, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    CompletionRing(completionRate, accentColor)
                    Spacer(modifier = Modifier.width(20.dp))
                    Column {
                        Text("${(completionRate * 100).toInt()}%", color = TextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium)
                        Text("des rappels sont terminés", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Répartition par catégorie", color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(12.dp))

            if (perCategory.isEmpty()) {
                Text("Pas encore de données", color = TextSecondary, modifier = Modifier.padding(vertical = 24.dp))
            } else {
                Surface(color = CardBackground, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        val maxValue = perCategory.maxOf { it.second }
                        perCategory.forEach { (category, count) ->
                            val color = runCatching { Color(android.graphics.Color.parseColor(category.colorHex)) }.getOrDefault(accentColor)
                            Column(modifier = Modifier.padding(bottom = 14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(category.name, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                                    Text(count.toString(), color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BackgroundSecondary)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(count.toFloat() / maxValue)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(color)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    val uri = StatisticsPdfExporter.export(
                        context, totalCount, completedCount, pendingCount, completionRate,
                        perCategory.map { it.first.name to it.second }
                    )
                    val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(android.content.Intent.createChooser(shareIntent, "Partager les statistiques"))
                },
                colors = ButtonDefaults.buttonColors(containerColor = CardBackground),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Filled.PictureAsPdf, contentDescription = null, tint = accentColor)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Exporter en PDF", color = TextPrimary, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, color: Color, modifier: Modifier) {
    Surface(color = CardBackground, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(value, color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun CompletionRing(rate: Float, color: Color) {
    Box(modifier = Modifier.size(72.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(72.dp)) {
            val strokeWidth = 8.dp.toPx()
            drawArc(
                color = BorderColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(strokeWidth),
                size = Size(size.width - strokeWidth, size.height - strokeWidth),
                topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * rate,
                useCenter = false,
                style = Stroke(strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
                size = Size(size.width - strokeWidth, size.height - strokeWidth),
                topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
            )
        }
    }
}
