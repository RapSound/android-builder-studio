package com.recallme.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Lieu utilise pour les rappels geolocalises (section "Rappels geolocalises").
 */
@Entity(tableName = "geo_locations")
data class GeoLocation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Int = 150,
    val isActive: Boolean = true,
    val triggerOnEnter: Boolean = true,
    val triggerOnExit: Boolean = false
)
