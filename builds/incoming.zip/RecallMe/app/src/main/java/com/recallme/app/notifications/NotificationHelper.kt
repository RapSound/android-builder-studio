package com.recallme.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.recallme.app.MainActivity
import com.recallme.app.R

/**
 * Fiabilite : une notification ne doit jamais etre oubliee (section "Fiabilite").
 * Fonctionne apres redemarrage, sans connexion internet, app fermee.
 * Inclut des actions rapides "Terminé" / "Reporter" (section "Notifications").
 */
object NotificationHelper {
    const val CHANNEL_ID = "recallme_reminders"
    const val GEOFENCE_CHANNEL_ID = "recallme_geofence"
    private const val CHANNEL_NAME = "Rappels RecallMe"
    private const val GEOFENCE_CHANNEL_NAME = "Rappels géolocalisés"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Notifications des rappels RecallMe"
                    enableVibration(true)
                }
            )
            manager.createNotificationChannel(
                NotificationChannel(GEOFENCE_CHANNEL_ID, GEOFENCE_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Rappels déclenchés par la localisation"
                    enableVibration(true)
                }
            )
        }
    }

    fun showReminderNotification(context: Context, reminderId: Long, title: String, message: String, silent: Boolean = false) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("reminder_id", reminderId)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context, reminderId.toInt(), openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val completeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_COMPLETE
            putExtra(NotificationActionReceiver.EXTRA_REMINDER_ID, reminderId)
        }
        val completePendingIntent = PendingIntent.getBroadcast(
            context, (reminderId.toInt() * 10) + 1, completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_SNOOZE
            putExtra(NotificationActionReceiver.EXTRA_REMINDER_ID, reminderId)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context, (reminderId.toInt() * 10) + 2, snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message.ifBlank { "Rappel RecallMe" })
            .setPriority(if (silent) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setSilent(silent)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "Terminé", completePendingIntent)
            .addAction(0, "Reporter 15 min", snoozePendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(reminderId.toInt(), notification)
    }

    fun showGeofenceNotification(context: Context, locationName: String, message: String, notificationId: Int) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, notificationId, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, GEOFENCE_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("📍 $locationName")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
}
