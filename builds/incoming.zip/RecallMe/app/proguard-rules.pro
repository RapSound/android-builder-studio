# RecallMe - regles ProGuard
-keep class com.recallme.app.data.** { *; }
