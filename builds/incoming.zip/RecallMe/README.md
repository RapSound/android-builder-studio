# RecallMe — Phase 9 (thème clair fonctionnel)

Projet Android natif **Kotlin + Jetpack Compose**.

## Nouveautés de cette Phase 9

- **Thème clair réellement fonctionnel**, activable depuis
  Paramètres → Apparence → Sombre / Clair / Système.
- Réalisé sans réécrire les ~20 écrans existants : les couleurs
  (`TextPrimary`, `CardBackground`, etc.) suivent désormais dynamiquement le
  thème actif via un état global observable, au lieu d'être figées. Solution
  choisie pour rester fiable même dans les zones dessinées à la main (ex :
  l'anneau de progression en Canvas des Statistiques).
- Le mode "Système" suit automatiquement le thème clair/sombre du téléphone.

## Contenu cumulé (Phase 1 → 9)

- Architecture Room (avec migrations) + DataStore + AlarmManager + Geofencing
- 5 écrans principaux + détail de rappel + sous-tâches
- Verrouillage PIN/biométrie, sauvegarde/restauration JSON
- Historique/Corbeille avec filtres, onboarding
- 3 widgets : prochain rappel, liste du jour, création rapide
- Carte interactive réelle (OSM), sélection d'image, recherche
- Notifications avec actions rapides, geofencing réel, statistiques + export PDF
- Mode Ne pas déranger, roue chromatique complète
- Tests unitaires (répétition, Ne pas déranger, sauvegarde JSON)
- **Thème clair / sombre / système**

## Comment générer l'APK

1. Ouvre le dossier `RecallMe` dans **Android Studio** (Koala/2024.1+).
2. Au premier "Sync", accepte la génération automatique du
   `gradle-wrapper.jar` manquant.
3. `Build > Build APK(s)` pour un test rapide, ou `Generate Signed Bundle/APK`
   pour la publication.
4. Pour tester les widgets : longue pression sur l'écran d'accueil du
   téléphone/émulateur → Widgets → RecallMe.
5. Pour tester le geofencing sur émulateur : Extended Controls → Location.

## Prochaines étapes proposées

- Rappels partagés / mode foyer (plusieurs profils sur le même appareil)
- Synchronisation optionnelle entre appareils (nécessiterait un backend)
- Support multilingue (nécessiterait d'extraire tous les textes en dur vers
  des ressources `strings.xml` — même travail d'extraction que le thème clair,
  mais pour le texte plutôt que la couleur)

Dis-moi par quoi tu veux continuer et je prépare le ZIP suivant.
