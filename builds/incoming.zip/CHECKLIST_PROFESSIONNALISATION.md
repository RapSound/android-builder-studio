# RapSound AI — Checklist "app professionnelle"

Organisé en trois niveaux : ce qui est **déjà fait**, ce qu'il faut **avant toute
utilisation sérieuse** (au-delà de toi en dev), et ce qu'il faut **avant une publication
publique** (Play Store ou distribution large). Chaque point dit pourquoi, pas juste quoi.

---

## ✅ Déjà en place

- **CI GitHub Actions** (`.github/workflows/android-build.yml`) — build automatique à
  chaque push, APK debug en artefact téléchargeable. C'est la pièce qui manquait pour ton
  workflow "je compile via GitHub".
- **`.gitignore`** — évite de committer `build/`, `local.properties`, des `.gguf` de
  plusieurs Go, ou un futur keystore par accident.
- **Tests unitaires réels** (`IdeaParser`, `StrategistParser`) — pas des tests bidons,
  ils vérifient le comportement de parsing (cas nominal, absence de format, tolérance au
  markdown). `gradle test` les fait tourner.
- **ProGuard/R8 préparé** (`app/proguard-rules.pro`) mais **pas encore activé**
  (`isMinifyEnabled = false`) — voir section suivante pour pourquoi.
- **Gestion d'erreurs visible** dans le chat (bannière + raccourci Paramètres), repli IA
  jamais silencieux, annulation de génération/téléchargement.
- **Architecture 100 % locale** (Room + DataStore + stockage interne) — pas de dépendance
  cloud à sécuriser, pas de backend à maintenir.
- **Export/import JSON** (Paramètres → Sauvegarde) — mémoire, projets et conversations
  peuvent être sauvegardés dans un fichier et restaurés (import additif, sans écraser
  les données existantes). Les images jointes ne sont pas incluses (fichier volontairement
  léger et portable).
- **Capture de crash locale** (Paramètres → Diagnostics) — aucun envoi automatique à un
  tiers, cohérent avec le positionnement 100% local ; le rapport reste sur l'appareil
  jusqu'à partage explicite par l'utilisateur.

## ⚠️ Avant toute utilisation sérieuse (au-delà de toi en dev)

1. **Gradle wrapper réel.** `gradle-wrapper.jar` n'a pas pu être généré ici (pas de
   Gradle ni de réseau dans mon environnement). Deux options :
   - Ouvre le projet dans Android Studio une fois — il régénère le wrapper tout seul.
   - Ou lance `gradle wrapper --gradle-version 8.4` toi-même si tu as Gradle installé.
   Le workflow CI n'en a pas besoin (il utilise `gradle` directement via
   `gradle/actions/setup-gradle`), mais toi en local avec `./gradlew`, si.

2. **Migrations Room réelles.** La base utilise `fallbackToDestructiveMigration()` — si
   tu changes le schéma (ajoutes une colonne, une table) sans écrire de `Migration`,
   **toutes les données existantes des utilisateurs sont effacées** au prochain
   lancement. Tant que c'est toi seul qui testes, ce n'est pas grave. Dès qu'un vrai
   utilisateur a des données dedans, chaque changement de schéma doit passer par une
   `Migration` explicite. (L'export JSON — voir ci-dessus — atténue le risque en
   attendant : exporte avant de tester un changement de schéma.)

3. **Licence des modèles.** Qwen 3 est sous licence Apache 2.0 (utilisation commerciale
   permise), mais **vérifie la licence exacte du dépôt GGUF précis que tu utilises**
   (`unsloth/Qwen3-*-GGUF`) avant toute distribution publique de l'app avec le modèle
   pré-embarqué — la vérification en un clic sur la page Hugging Face du modèle suffit.
   llama.cpp est MIT (aucune contrainte).

## 🚀 Avant une publication publique (Play Store ou distribution large)

5. **Signature de release.** Il n'y a aujourd'hui qu'un build debug (signé avec une clé
   de debug, invalide pour le Store). Il faut :
   - générer un keystore (`keytool -genkey -v -keystore release.jks ...`),
   - **ne jamais le committer** (déjà dans `.gitignore`),
   - le stocker en GitHub Secret si tu veux que la CI produise aussi un build signé,
   - ajouter un `signingConfigs { release { ... } }` dans `app/build.gradle.kts` qui lit
     les identifiants depuis des variables d'environnement/secrets, jamais en dur.

6. **Activer la minification** (`isMinifyEnabled = true` en release) une fois le
   `proguard-rules.pro` testé — R8 peut casser des choses (réflexion Room/OkHttp/Coil) si
   les règles de garde sont incomplètes ; à tester sur un vrai appareil avant de
   distribuer, pas juste "ça compile".

7. **Icône de lancement définitive.** Celle fournie est un placeholder vectoriel simple.
   Prévoir une vraie icône adaptive (foreground + background) respectant les gabarits
   Play Store (icône maskable, résolutions multiples si tu ne passes pas par le format
   adaptatif seul).

8. **Politique de confidentialité.** Obligatoire pour publier sur le Play Store dès que
   l'app fait des requêtes réseau optionnelles (Gemini/OpenRouter/Mistral/YouTube) même
   si elles sont désactivées par défaut. Doit couvrir : ce qui reste local (tout, par
   défaut), ce qui part vers un tiers si l'utilisateur active un fournisseur distant, et
   ce que fait l'API YouTube.

9. **Conformité YouTube API Terms of Service** si tu affiches des données YouTube
   (stats de chaîne) : attribution requise, restrictions sur la durée de cache des
   données, interdiction de certains usages. À relire une fois avant publication —
   ce n'est pas qu'une formalité, Google audite et peut révoquer l'accès API.

10. **Accessibilité.** La plupart des icônes ont déjà un `contentDescription`, mais un
    audit TalkBack complet (parcourir tout l'écran Chat, Paramètres, et les dialogues au
    clavier/lecteur d'écran) n'a pas été fait.

11. **Externalisation des chaînes.** Tous les textes UI sont actuellement en dur dans le
    code Compose (français uniquement, cohérent avec le positionnement RapSound). Les
    extraire vers `strings.xml` n'est utile que si tu envisages une traduction un jour —
    sinon ce n'est pas une priorité réelle pour cette app.

12. **Analyse statique.** Pas de ktlint/detekt configuré. Utile en équipe pour la
    cohérence de style ; moins critique en solo, mais peu coûteux à ajouter (`ktlint`
    tourne en quelques secondes) et évite les dérives au fil du temps.

13. ~~**Rapport de crash.**~~ Fait — `diagnostics/CrashLogger.kt` capture localement
    (aucun tiers), consultable/partageable/effaçable depuis Paramètres → Diagnostics.

## Notes de priorité

Si l'app reste "toi + quelques proches en test" : les points 1-4 suffisent.
Si tu vises une vraie diffusion (même en beta fermée hors Store, ex. APK partagé) :
ajoute 5-7 (signature + minification testée + icône).
Si tu vises le Play Store public : la liste complète, avec 8-9 non négociables
(Google refuse la publication sans politique de confidentialité dès qu'une permission
réseau optionnelle existe).
