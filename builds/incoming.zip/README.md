# RapSound AI — Application Android (Jetpack Compose)

Assistant IA stratégique pour la chaîne YouTube RapSound (rap français). App Android
native, **100 % de données locales** : aucun compte, aucun cloud, aucune configuration
serveur requise pour utiliser l'app.

```
Stockage
    ├── Room / SQLite       → mémoire, projets, conversations, messages, objectif
    ├── DataStore            → préférences, clés API, paramètres IA
    └── Stockage interne      → fichiers/images (pièces jointes)

IA (AiProvider, streaming)
    ├── LocalAiProvider    → Qwen 3 (GGUF, llama.cpp/JNI) — PAR DÉFAUT, 100 % hors-ligne
    ├── GeminiProvider     → optionnel, distant, choisi explicitement
    ├── OpenAiCompatibleProvider → OpenRouter, Mistral — optionnels, distants
    └── EchoAiProvider     → fournisseur de test, sans dépendance
```

Rien de tout cela n'est un placeholder à moitié fait : c'est l'architecture réelle du
code. Les deux limites honnêtes sont documentées plus bas (§ "Ce qu'il reste à faire").

## Lancer le projet

1. Ouvre le dossier `RapSoundAI/` avec Android Studio (Hedgehog ou plus récent).
2. Laisse Android Studio synchroniser Gradle (régénère le wrapper manquant au besoin).
3. Lance sur un émulateur ou un appareil (minSdk 26 / Android 8.0+).

**Aucune étape de configuration cloud n'est nécessaire.** L'app fonctionne dès le premier
lancement : mémoire pré-remplie, projets par défaut, chat utilisable (avec le fournisseur
Écho tant que l'IA locale ou une clé distante n'est pas configurée).

## IA locale (Qwen 3 via llama.cpp) — une étape manuelle requise

**RapSound AI utilise une vraie IA locale par défaut**, pas une API distante déguisée.
Tout le pont JNI, le build CMake, la gestion des modèles (téléchargement/vérification/
suppression), le streaming et l'annulation sont déjà écrits et branchés. La seule pièce
manquante est **le code source de llama.cpp lui-même** (dépôt C++ tiers volumineux) :

```bash
git submodule add https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
git submodule update --init --recursive
```

Voir `app/src/main/cpp/README.md` pour le détail complet (pourquoi cette étape ne pouvait
pas être automatisée ici, comment épingler une version qui compile, etc.).

**Sans cette étape**, l'app compile et tourne normalement quand même — le build natif ne
se déclenche que si le sous-module est présent (`llamaCppPresent` dans
`app/build.gradle.kts`) ; `LocalAiProvider` signale juste au runtime que le modèle local
est indisponible, et Gemini/OpenRouter/Mistral/Écho restent utilisables.

**Une fois le sous-module ajouté et l'app recompilée :**
1. Paramètres → IA locale → télécharger un modèle (Qwen 3 1.7B pour un téléphone modeste,
   8B si la RAM le permet — recommandation automatique selon la RAM détectée).
2. Le fichier GGUF (source : dépôts publics Hugging Face `unsloth/Qwen3-*-GGUF`) est
   vérifié (signature GGUF) puis stocké dans `files/models/` (stockage privé).
3. À partir de là, discuter avec RapSound AI ne fait plus **aucune requête réseau** —
   testable Wi-Fi/données mobiles coupés.

Le repli vers Gemini n'est **jamais silencieux** : désactivé par défaut, et quand activé
dans Paramètres, une bannière explicite apparaît dans le chat ("🧠 Modèle local non
installé → repli vers ☁️ Gemini — ce message est envoyé à Google").

## Fonctionnalités

- **Conversation** : messages persistés en local (Room), streaming token par token,
  annulation en cours de génération, pièces jointes image (copiées dans le stockage
  interne, affichées en bulle), les 10 fonctions rapides du §23, bannière d'erreur avec
  raccourci vers Paramètres en cas d'échec du fournisseur IA.
- **Historique** : recherche, favoris, renommer/archiver/supprimer, classement par
  projet — suppression en cascade des messages gérée nativement par SQLite.
- **Mémoire RapSound** : pré-remplie au premier lancement avec ~29 faits extraits du
  cahier des charges (identité, objectifs, formats, artistes, stratégie, outils,
  workflow, préférences, projets). Filtrage par catégorie, ajout/suppression explicite.
- **Projets** : arborescence des projets RapSound, pré-remplie au premier lancement.
  Détail éditable (description/statut) + liste des conversations liées.
- **Analyses** : objectif abonnés (792/1000 par défaut), bascule sur les vraies données
  YouTube (abonnés/vues/vidéos) dès qu'une clé API + un ID de chaîne sont renseignés.
- **Paramètres** : sélecteur de fournisseur IA (local en priorité), gestion des modèles
  Qwen 3, paramètres de génération (température/tokens/contexte/streaming/mode
  réflexion), repli Gemini explicite, clés API (Gemini/OpenRouter/Mistral/YouTube,
  jamais en dur — stockées en local via DataStore), mode RapSound Strategist.

### Réponses structurées dans le chat
- **Mode RapSound Strategist** (§24) : réponses en 5 sections (Diagnostic/Problèmes/
  Opportunités/Priorités/Plan d'action), rendues en cartes si le modèle suit le format.
- **Idée virale** (§27) : quick action qui demande un format `Label: valeur`, rendu en
  fiche structurée (titre, format, artiste, hook, déroulement, CTA, durée, potentiel).

Les deux se dégradent silencieusement vers du texte brut si le modèle ne suit pas le
format — aucun risque de rendu cassé.

## Architecture des données (100 % locale)

```
Room / SQLite (data/local/)
├── memory_entries      → MemoryEntry        (§17-18)
├── projects            → RapProject          (§19)
├── goals                → SubscriberGoal      (§25-26)
├── conversations          → ConversationSummary (§21)
└── messages                 → ChatMessageDoc (FK conversationId, ON DELETE CASCADE)

DataStore (data/settings/ApiKeyStore.kt)
└── clés API, préférences IA, mode Strategist, streaming, etc.

Stockage interne (files/)
├── attachments/{conversationId}/  → pièces jointes image (§22)
└── models/                          → modèles GGUF téléchargés (IA locale)
```

Pas de migrations formelles pour l'instant (`fallbackToDestructiveMigration()`) — à
remplacer par de vraies `Migration()` Room dès que le schéma doit évoluer sans perdre les
données existantes des utilisateurs.

## Couche IA (§33) et clés (§35)

```
data/ai/
├── AiMessage.kt                 (rôle + contenu + images optionnelles)
├── AiProvider.kt                  (interface commune, streaming)
├── EchoAiProvider.kt                (fournisseur de test, gratuit, sans clé — §34)
├── GeminiProvider.kt                  (Google Gemini, REST + SSE, multimodal)
├── OpenAiCompatibleProvider.kt          (OpenRouter + Mistral, même format de requête)
├── AiProviderRegistry.kt                  (liste des fournisseurs + sélection active)
├── SystemPromptBuilder.kt                   (identité + mémoire + objectif + Strategist)
└── local/
    ├── ModelCatalog.kt      (catalogue Qwen 3 8B/4B/1.7B, sources Hugging Face)
    ├── DeviceCapabilities.kt (détection RAM → modèle recommandé)
    ├── ModelManager.kt        (téléchargement/vérification/suppression GGUF)
    ├── LlamaBridge.kt           (déclarations JNI vers llama.cpp)
    └── LocalAiProvider.kt         (orchestration : prompt Qwen, streaming, cache modèle)

data/settings/ApiKeyStore.kt   (DataStore local : clés API + préférences IA)
```

## Structure du code

```
app/src/main/java/com/rapsound/ai/
├── MainActivity.kt
├── RapSoundApplication.kt   (bootstrap Room + registre IA, gestion RAM du modèle local)
├── data/ai/                  (couche AI Provider, voir ci-dessus)
├── data/local/                 (Room : entités, DAOs, base de données)
├── data/settings/                (ApiKeyStore)
├── data/model/                     (MemoryEntry, RapProject, SubscriberGoal, ConversationSummary, ChatMessageDoc)
├── data/repository/                  (MemoryRepository, ProjectRepository, ConversationRepository,
│                                       GoalRepository, AttachmentRepository, YouTubeRepository)
├── navigation/                         (Screen.kt, NavGraph.kt)
├── ui/theme/                            (Color.kt, Type.kt, Theme.kt)
├── ui/components/                         (Scaffold + tiroir, ChatBubble, QuickActionChip,
│                                            StrategistCard/Parser, IdeaCard/Parser)
└── ui/screens/                             (chat, history, memory, projects, analytics, settings)
    each screen has a matching *ViewModel.kt

app/src/main/cpp/          (pont JNI llama.cpp — voir app/src/main/cpp/README.md)
```

## Compiler via GitHub (CI)

`.github/workflows/android-build.yml` build un APK debug à chaque push/PR sur `main`
(et à la demande via l'onglet Actions → "Run workflow"), le publie en artefact
téléchargeable. Il utilise `gradle` directement plutôt que `./gradlew` — voir le
commentaire en tête du fichier pour pourquoi (le wrapper binaire n'a pas pu être généré
dans l'environnement où ce projet a été préparé, aucun impact sur toi si tu passes par
Actions).

## Aller plus loin : checklist "app professionnelle"

`CHECKLIST_PROFESSIONNALISATION.md` couvre ce qu'il reste pour dépasser le stade
"skeleton fonctionnel" : signature de release, migrations Room réelles, export de
données, conformité YouTube API, politique de confidentialité, etc. — organisé par
priorité (usage perso / diffusion restreinte / Play Store public).

## Ce qu'il reste à faire

- **Ajouter le sous-module llama.cpp** (voir plus haut) — seule étape bloquant l'IA locale.
- **Coller les clés distantes** (Gemini/OpenRouter/Mistral, YouTube) si tu veux les
  utiliser — entièrement optionnelles, l'app fonctionne sans.
- YouTube Analytics (rétention, likes) nécessite OAuth (au-delà d'une simple clé API) —
  ces métriques restent des placeholders "—" pour l'instant.
- Vraies migrations Room dès que le schéma doit évoluer en préservant les données.
- Icône de lancement définitive (celle fournie est un placeholder vectoriel).
- Étendre le format structuré (§27) à d'autres quick actions que "Idée virale" si utile.
- Backend GPU pour llama.cpp (Vulkan/OpenCL) si la vitesse CPU s'avère insuffisante sur
  certains appareils — le pont JNI est actuellement CPU uniquement (le plus portable).
- Si un jour un sync multi-appareils est voulu, une couche cloud optionnelle (Firestore
  ou autre) pourrait se greffer par-dessus Room sans le remplacer — pas fait ici, puisque
  la donnée doit rester locale par défaut.
