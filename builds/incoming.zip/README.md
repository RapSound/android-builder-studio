# Android Builder Studio WebView APK

Projet Android complet pour emballer cette URL dans une application WebView :

https://rapsound.github.io/android-builder-studio/

## Fichiers importants inclus

- `AndroidManifest.xml` à la racine du ZIP, pour vérification rapide
- `app/src/main/AndroidManifest.xml`, emplacement Android officiel utilisé au build
- `settings.gradle`
- `build.gradle`
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`
- dossier `app/` complet

## Build APK

Ouvrir ce dossier dans Android Studio, puis :

```bash
./gradlew assembleDebug
```

APK généré : `app/build/outputs/apk/debug/app-debug.apk`
