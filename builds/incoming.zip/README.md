# RecallMe — Phase 7 (widgets supplémentaires, export PDF)

Projet Android natif **Kotlin + Jetpack Compose**.

## Nouveautés de cette Phase 7

- **Widget "Liste du jour"** : affiche tous les rappels du jour (pas
  seulement le prochain), sous forme de liste déroulante sur l'écran d'accueil
  du téléphone.
- **Widget "Nouveau rappel"** : raccourci 1x1 qui ouvre directement l'écran de
  création d'un rappel, sans passer par l'app.
- **Export PDF des statistiques** : bouton "Exporter en PDF" sur l'écran
  Statistiques, génère un document propre (totaux, taux de complétion,
  répartition par catégorie) et ouvre le sélecteur de partage natif Android.

## Contenu cumulé (Phase 1 → 7)

- Architecture Room (avec migrations) + DataStore + AlarmManager + Geofencing
- 5 écrans principaux + détail de rappel + sous-tâches
- Verrouillage PIN/biométrie, sauvegarde/restauration JSON
- Historique/Corbeille avec filtres, onboarding
- **3 widgets** : prochain rappel, liste du jour, création rapide
- Carte interactive réelle (OSM), sélection d'image, recherche
- Notifications avec actions rapides, geofencing réel, statistiques + export PDF
- Mode Ne pas déranger, roue chromatique complète

## Comment générer l'APK

1. Ouvre le dossier `RecallMe` dans **Android Studio** (Koala/2024.1+).
2. Au premier "Sync", accepte la génération automatique du
   `gradle-wrapper.jar` manquant.
3. `Build > Build APK(s)` pour un test rapide, ou `Generate Signed Bundle/APK`
   pour la publication.
4. Pour tester les widgets : longue pression sur l'écran d'accueil du
   téléphone/émulateur → Widgets → RecallMe (3 widgets disponibles).
5. Pour tester le geofencing sur émulateur : Extended Controls → Location.

## Prochaines étapes proposées

- Rappels partagés / mode foyer (plusieurs profils sur le même appareil) —
  cohérent avec ton usage "foyer-quest" évoqué dans nos autres échanges
- Synchronisation optionnelle entre appareils (nécessiterait un backend —
  à discuter si tu veux aller jusque-là)
- Support multilingue (EN/ES) au-delà du français
- Thème clair en complément du thème sombre actuel
- Tests unitaires sur la logique de répétition et le geofencing

Dis-moi par quoi tu veux continuer et je prépare le ZIP suivant.
