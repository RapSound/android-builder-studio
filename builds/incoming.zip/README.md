# YT-Trend-Pulse — État du projet

Ce ZIP contient une application **fonctionnelle de bout en bout** (Kotlin +
Jetpack Compose, Material 3, thème Premium Dark) : les 6 menus du cahier des
charges sont branchés sur Firestore et l'API YouTube, avec un pipeline
Artiste → détection des morceaux → score → podium qui tourne réellement.
Les fonctions restantes (notifications, Graphique+) sont détaillées
en section 3.

## 1. Étapes pour ouvrir le projet

✅ **Projet Android complet** : `gradlew`, `gradlew.bat`,
`gradle/wrapper/gradle-wrapper.jar`, `settings.gradle`, les fichiers
`build.gradle`, le module `app/` et le manifeste standard sont inclus.
Une copie de `AndroidManifest.xml` est aussi placée à la racine pour le rendre
immédiatement visible ; Android utilise la version située dans
`app/src/main/AndroidManifest.xml`.

1. Ouvrir le dossier avec **Android Studio** (Koala ou plus récent).
2. Copier `local.properties.example` → `local.properties`, puis renseigner :
   - `sdk.dir` (chemin vers ton Android SDK)
   - `YOUTUBE_API_KEY` (ta clé API YouTube Data v3)
3. Remplacer `app/google-services.json.example` par ton **vrai**
   `app/google-services.json` téléchargé depuis la console Firebase.
4. Laisser Gradle synchroniser (Android Studio le proposera automatiquement).
5. Dans la console Firebase :
   - **Authentication** → activer le fournisseur **Email/Mot de passe**
     (Build > Authentication > Sign-in method).
   - **Firestore Database** → créer la base (mode production).
   - Déployer `firestore.rules` (racine du projet) : soit en collant son
     contenu dans Firestore Database > Règles côté console, soit via la
     Firebase CLI (`firebase deploy --only firestore:rules`).
6. Au premier lancement de l'app, créer un compte depuis l'écran de
   connexion ("Créer un compte"). Toutes les données (artistes, morceaux,
   journal d'audit) sont ensuite scopées à ce compte, sous
   `users/{uid}/...` dans Firestore.

Aucun fichier de clé n'est versionné (voir `.gitignore`).

## 2. Ce qui est réellement fonctionnel

- **Refonte visuelle** (`ui/components/ScoreBadge.kt`, `FilterPillRow.kt`,
  `TrackCard.kt`) : badges de score circulaires, halo lumineux rouge sur les
  morceaux "chauds" (🔥), podium avec couronne + halo sur la 1ère place,
  toggles en pill (Charts, Artistes), grille 2 colonnes pour Figés, dialog
  d'ajout d'artiste + FAB. Inspiré d'une maquette fournie, pas copié.
- **Moteur de prédiction v2, adaptatif par morceau**
  (`domain/PredictionEngine.kt`) : teste 3 formes de courbe (linéaire,
  exponentiel amorti, logarithmique/plateau) sur l'historique réel de CHAQUE
  morceau et garde celle qui colle le mieux (R² le plus haut) — au lieu
  d'imposer une seule régression linéaire à tous les morceaux comme la v1.
  Le modèle choisi est affiché sur la page de détail ("modèle exponentiel
  amorti", etc.).
- **Authentification par vrai compte (email/mot de passe)** : écran de
  connexion/inscription affiché tant qu'aucun compte n'est connecté
  (`AuthViewModel` + `FirebaseAuthRepository`). Une fois connecté, **toutes
  les données Firestore sont scopées sous `users/{uid}/...`** — chaque
  compte a ses propres artistes/morceaux/journal d'audit, jamais partagés
  (voir `data/CurrentUser.kt` et `firestore.rules`). Déconnexion possible
  depuis Paramètres.
- **Injection de dépendances (Koin)** : tous les repositories et ViewModels
  sont câblés dans `di/AppModule.kt`, démarrés dans `YTTrendPulseApp`.
- **Journal d'audit (12.9 §1)** : accessible depuis Paramètres. Trace les
  actions manuelles de l'utilisateur (ajout/suppression d'artiste, figer/
  défiger, activer/désactiver Graphique+, synchro manuelle) avec date et
  détails. Les actions automatiques du worker ne sont volontairement pas
  journalisées ici (trop volumineux pour rester lisible).
- **Écran de santé du moteur (12.9 §2)** : accessible depuis Paramètres.
  État de la dernière synchronisation (lu en direct depuis WorkManager),
  nombre d'artistes suivis, nombre de morceaux actifs, versions des moteurs
  de score et de prédiction.
- **Graphique+ (2.12)** : suivi renforcé activable par morceau (15/30/60 min)
  depuis la page de détail. `GraphPlusScheduler` planifie/annule une tâche
  WorkManager périodique dédiée (`EnhancedTrackWorker`), qui rafraîchit ce
  morceau et déclenche les mêmes notifications que la synchro quotidienne.
  ⚠️ **Limite technique honnête** : WorkManager n'autorise pas d'intervalle
  périodique inférieur à 15 min (contrainte système Android, pas un choix
  produit) — c'est pour ça que 15 min est la valeur la plus rapprochée
  proposée.
- **Notifications locales (`notifications/NotificationHelper.kt`)** :
  déclenchées par `DailySyncWorker` sur deux événements — pic de score
  (≥ 20 points en une synchro) ou palier de vues franchi (100K, 500K, 1M,
  5M, 10M, 50M, 100M). Tap sur la notification → ouvre directement la page
  de détail du morceau concerné. Permission Android 13+ demandée au premier
  lancement. ⚠️ Ce sont des notifications **locales** (déclenchées sur
  l'appareil en tâche de fond), pas des pushs serveur — l'app n'a pas de
  backend Firebase Cloud Messaging.
- **Menu Artistes (2.9)** : ajout / suppression / liste en temps réel,
  entièrement branché sur Firestore (`FirestoreArtistRepository` +
  `ArtistesViewModel` + `ArtistesScreen`).
- **Podium (2.5)** : classement top 10 en temps réel par score, avec le
  contour 🔥 piloté par le seuil "récent" configurable (`SettingsRepository`,
  DataStore).
- **Viral Score (`domain/ViralScoreEngine.kt`)** : moteur de calcul complet
  et versionné (volume log-compressé + vélocité + fraîcheur).
- **`DailySyncWorker` (1.5, 1.9)** : orchestration complète et fonctionnelle —
  pour chaque artiste suivi, détecte les vidéos publiées depuis moins de 25
  jours via l'API YouTube, crée les morceaux manquants, puis rafraîchit les
  statistiques de tous les morceaux actifs, historise (`tracks/{id}/history`)
  et recalcule le score. Tourne une fois par nuit (planifié dans
  `YTTrendPulseApp`), et la même logique alimente `refreshTrack()` (bouton
  Actualiser sur la page de détail).
- **Menu Figés (2.6)** : liste temps réel des morceaux épinglés
  (`FigesViewModel` -> `TrackRepository.observePinnedTracks()`), même contour
  🔥 que le Podium (logique partagée dans `domain/TrackRecency.kt`), tap sur
  une carte -> page de détail. Le "Défiger" se fait depuis cette page.
- **Menu Analyse (2.7)** : recherche en direct sur YouTube (titre obligatoire,
  artiste facultatif), affichage des résultats (miniature, chaîne, vues), et
  "Voir plus" qui ajoute le morceau en base s'il n'y est pas déjà, puis ouvre
  sa page de détail (`AnalyseViewModel` -> `YouTubeApiService` +
  `TrackRepository`).
- **Menu Paramètres (1.8)** : seuil "récent" (🔥, slider 1-30 jours) et
  horizon de prédiction par défaut (3/7/15/30 j) persistés via DataStore
  (`SettingsRepository`), + bouton de synchronisation manuelle qui déclenche
  immédiatement `DailySyncWorker` via WorkManager (pratique pour tester sans
  attendre minuit).
- **Menu Charts (2.8)** : Top 20 / Top 100 via l'endpoint officiel
  `videos.list?chart=mostPopular` de YouTube (region=FR, catégorie Musique),
  ajout automatique des morceaux absents en base. ⚠️ **Limite documentée** :
  YouTube ne propose pas de chart par genre — c'est une approximation
  ("Top Musique France"), pas un chart "Rap Français" strict. Aucun scraping
  n'est utilisé (fragile et hors conditions d'utilisation de YouTube).
- **Page de détail d'un morceau (2.10-2.11)** : bandeau, stats, bouton Figer/
  Défiger, bouton Actualiser, **3 graphiques réels** (Vues/Likes/Commentaires)
  via MPAndroidChart, **et prédiction fonctionnelle** : sélecteur d'horizon
  (3/7/15/30 j), tracé pointillé automatique, indice de confiance affiché
  ("Prédiction fiable à X %"). Le moteur (`domain/PredictionEngine.kt`) fait
  une régression linéaire simple sur les 14 derniers points réels — approche
  transparente et versionnée, à affiner avec plus de recul sur les données
  réelles collectées par `DailySyncWorker`.

## 3. Ce qui reste en squelette (TODO explicites dans le code)

Les **6 menus sont maintenant tous fonctionnels**, avec journal d'audit et
écran de santé en plus. Ce qui reste concerne des affinages, pas des
fonctionnalités manquantes :

- **Détection "entrée dans le Top 3 du Podium"** pour les notifications :
  demande de mémoriser le classement précédent (pas encore fait) — pour
  l'instant, seuls le pic de score et les paliers de vues déclenchent une
  notification.
- **Gestion du quota API YouTube** (3.x) : ni le worker ni les écrans ne
  suivent la consommation de quota — à surveiller si le nombre d'artistes/
  morceaux suivis grandit.
- **Chart "Rap Français" plus précis** (2.8) : actuellement une approximation
  ("Top Musique France" via l'API officielle). Pour un chart plus ciblé, il
  faudrait soit une liste d'artistes/labels de référence à croiser côté
  client, soit une source de données tierce — à discuter ensemble.


## 4. Structure des dossiers

```
YT-Trend-Pulse/
├── firestore.rules              # règles de sécurité (données scopées par uid)
└── app/src/main/java/com/yttrendpulse/app/
    ├── MainActivity.kt           # AppRoot : LoginScreen ou app principale selon l'auth
    ├── YTTrendPulseApp.kt        # init Firebase + Koin + planification WorkManager
    ├── di/AppModule.kt           # tous les repositories/ViewModels injectés
    ├── domain/                   # ViralScoreEngine, PredictionEngine, TrackRecency, NotificationRules
    ├── navigation/                # Screen.kt, NavGraph.kt
    ├── notifications/             # NotificationHelper
    ├── ui/theme/                  # Color.kt, Type.kt, Theme.kt
    ├── ui/components/             # TopBar, BottomNavBar, TrackCard, HistoryLineChart
    ├── ui/screens/auth/           # connexion/inscription (vrai compte)
    ├── ui/screens/{podium,figes,analyse,charts,artistes,parametres}/
    ├── ui/screens/trackdetail/    # temps réel + graphiques + prédiction + Graphique+
    ├── ui/screens/auditlog/       # journal d'audit (12.9 §1)
    ├── ui/screens/health/         # santé du moteur (12.9 §2)
    ├── data/CurrentUser.kt        # uid courant, utilisé pour scoper Firestore
    ├── data/model/                # Artist, Track, HistoryEntry, Prediction, AuditLogEntry
    ├── data/repository/           # interfaces + implémentations (Firestore scopé par uid, YouTube charts)
    ├── data/remote/               # YouTubeApiService, YouTubeParsing, NetworkModule
    ├── data/local/SettingsRepository.kt  # DataStore (seuil 🔥, horizon prédiction)
    └── sync/                      # DailySyncWorker, EnhancedTrackWorker, GraphPlusScheduler
```

