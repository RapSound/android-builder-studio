# Mon application

Projet Android généré par Android Builder Studio.

## Compilation

`./gradlew assembleDebug`

L’APK est produit dans `app/build/outputs/apk/debug/app-debug.apk`.
