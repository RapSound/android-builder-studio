Application Android simple pour Keryan.

Contenu important :
- AndroidManifest.xml est présent à la racine du projet
- AndroidManifest.xml est aussi présent au chemin Android standard : app/src/main/AndroidManifest.xml
- gradlew et gradlew.bat sont présents à la racine

Ouverture recommandée : Android Studio > File > Open > dossier keryan-app.
