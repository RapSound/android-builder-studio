# Règles ProGuard/R8 spécifiques au projet.
# Rien de spécifique pour l'instant : à compléter si des classes sont
# supprimées/renommées par erreur en build release (ex: modèles Firestore).
