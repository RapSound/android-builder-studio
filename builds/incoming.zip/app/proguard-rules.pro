# Règles ProGuard/R8 — prêtes pour quand isMinifyEnabled passera à true (voir
# CHECKLIST_PROFESSIONNALISATION.md, section "Build de release"). Pas encore actives
# tant que le build de release n'est pas configuré (signature, tests sur build minifié).

# Room : les entités sont accédées par réflexion par le compilateur Room (KSP génère déjà
# le code d'accès, mais on garde les classes pour éviter toute surprise avec les
# TypeConverters si on en ajoute plus tard).
-keep class com.rapsound.ai.data.local.** { *; }

# Modèles de domaine sérialisés/désérialisés indirectement (pas de Gson/Moshi ici, mais
# on les garde lisibles en cas de futur besoin de debug/logs).
-keep class com.rapsound.ai.data.model.** { *; }

# OkHttp / okio — règles standard recommandées par la documentation OkHttp.
-dontwarn okhttp3.**
-dontwarn okio.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# Coil charge des images dynamiquement ; évite de supprimer ses fetchers/decoders.
-keep class coil.** { *; }
-dontwarn coil.**

# org.json est utilisé pour parser les réponses des fournisseurs IA / YouTube — classes
# système Android, ne devrait pas être touché, mais on le garde explicite.
-dontwarn org.json.**
