package com.rapsound.ai.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StrategistParserTest {

    @Test
    fun `parses all five sections with multi-line content`() {
        val response = """
            Diagnostic
            La chaîne progresse bien sur les Blind Tests.
            La rétention est correcte.

            Problèmes
            La fréquence de publication est trop faible.

            Opportunités
            Le format Top 3 n'est pas encore lancé.

            Priorités
            1. Lancer Top 3
            2. Automatiser la préparation YouTube

            Plan d'action
            Semaine 1 : préparer 3 épisodes Top 3.
        """.trimIndent()

        val sections = StrategistParser.parse(response)

        assertTrue(sections!!.isStructured)
        assertTrue(sections.diagnostic!!.contains("Blind Tests"))
        assertTrue(sections.priorites!!.contains("Top 3"))
        assertTrue(sections.planAction!!.contains("Semaine 1"))
    }

    @Test
    fun `returns null when the model ignores the requested format`() {
        val response = "Je pense que RapSound devrait publier plus souvent, voilà mon avis."
        assertNull(StrategistParser.parse(response))
    }

    @Test
    fun `handles the apostrophe in Plan d'action`() {
        val response = """
            Diagnostic
            OK

            Plan d'action
            Fais ceci.
        """.trimIndent()

        val sections = StrategistParser.parse(response)

        assertEquals("Fais ceci.", sections?.planAction)
    }
}
