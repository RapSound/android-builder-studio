package com.rapsound.ai.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IdeaParserTest {

    @Test
    fun `parses a well-formed structured response`() {
        val response = """
            Titre: Gims sans autotune
            Format: Blind Test
            Artiste: Gims
            Hook: Reconnais le son en 3 secondes
            Déroulement: Extrait, indice, réponse, révélation
            CTA: Commente ton score
            Durée: 45s
            Potentiel: Élevé
            Justification: Format déjà performant sur la chaîne
        """.trimIndent()

        val idea = IdeaParser.parse(response)

        assertTrue(idea!!.isStructured)
        assertEquals("Gims sans autotune", idea.titre)
        assertEquals("Blind Test", idea.format)
        assertEquals("Commente ton score", idea.cta)
    }

    @Test
    fun `returns null for free-form prose without labels`() {
        val response = "Je pense que tu devrais faire un blind test sur le rap des années 2000."
        assertNull(IdeaParser.parse(response))
    }

    @Test
    fun `is tolerant to markdown bullets and asterisks before the label`() {
        val response = """
            - Titre: Test
            * Format: Dilemme
        """.trimIndent()

        val idea = IdeaParser.parse(response)

        assertEquals("Test", idea?.titre)
        assertEquals("Dilemme", idea?.format)
    }

    @Test
    fun `requires at least two recognized labels to count as structured`() {
        val response = "Titre: Solo"
        assertNull(IdeaParser.parse(response))
    }
}
