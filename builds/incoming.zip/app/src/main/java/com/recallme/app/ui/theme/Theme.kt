package com.recallme.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Couleur d'accent active, personnalisable par l'utilisateur (section 8 du cahier des charges).
 * Par defaut : rouge profond (#D81F32).
 */
val LocalAccentColor = compositionLocalOf { RedPrimary }

@Composable
fun RecallMeTheme(
    accentColor: Color = RedPrimary,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = accentColor,
        secondary = RedSecondary,
        tertiary = RedAccent,
        background = BackgroundPrimary,
        surface = CardBackground,
        surfaceVariant = BackgroundSecondary,
        onPrimary = TextPrimary,
        onBackground = TextPrimary,
        onSurface = TextPrimary,
        outline = BorderColor,
        error = CriticalRed
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        val activity = view.context as? android.app.Activity
        activity?.window?.let { window ->
            window.statusBarColor = BackgroundPrimary.toArgb()
            window.navigationBarColor = BackgroundPrimary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    CompositionLocalProvider(LocalAccentColor provides accentColor) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = RecallMeTypography,
            content = content
        )
    }
}
