package com.recallme.app.ui.theme

import androidx.compose.ui.graphics.Color

// Couleur principale — Rouge profond
val RedPrimary = Color(0xFFD81F32)

// Couleur secondaire — Rouge clair (degrades, halos)
val RedSecondary = Color(0xFFFF4D5A)

// Couleur d'accentuation — Rouge lumineux (bouton +, confirmations)
val RedAccent = Color(0xFFFF5A5F)

// Fond principal — Gris tres fonce
val BackgroundPrimary = Color(0xFF121212)

// Fond secondaire — Gris anthracite
val BackgroundSecondary = Color(0xFF1D1D1D)

// Cartes
val CardBackground = Color(0xFF242424)

// Bordures
val BorderColor = Color(0xFF323232)

// Textes
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB3B3B3)
val TextDisabled = Color(0xFF6E6E6E)

// Etats
val SuccessGreen = Color(0xFF34C759)
val InfoBlue = Color(0xFF3B82F6)
val WarningOrange = Color(0xFFFF9500)
val CriticalRed = Color(0xFFFF3B30)

// Themes predefinis (apercu dans Personnalisation)
val ThemeBlue = Color(0xFF2F6FED)
val ThemeGreen = Color(0xFF1FAA59)
val ThemeViolet = Color(0xFF7C3AED)
val ThemePink = Color(0xFFEC4899)
val ThemeOrange = Color(0xFFFF7A1A)

// Categories predefinies
val CategoryPersonnel = Color(0xFFD81F32)
val CategoryTravail = Color(0xFFFF7A1A)
val CategorySante = Color(0xFF1FAA59)
val CategoryEtude = Color(0xFF2F6FED)
val CategorySport = Color(0xFF7C3AED)
