package com.recallme.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.recallme.app.navigation.RecallMeNavHost
import com.recallme.app.ui.RecallMeViewModel
import com.recallme.app.ui.screens.LockScreen
import com.recallme.app.ui.screens.OnboardingScreen
import com.recallme.app.ui.theme.RecallMeTheme

class MainActivity : ComponentActivity() {

    private val viewModel: RecallMeViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val fineGranted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true
        if (fineGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Sur Android 10+, la permission d'arriere-plan doit etre demandee separement,
            // apres que la permission de premier plan ait ete accordee (contrainte systeme).
            backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
    }

    private val backgroundLocationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* geofencing fonctionnera en premier plan uniquement si refusee */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()

        setContent {
            val accentHex by viewModel.accentColor.collectAsState()
            val accentColor = runCatching { Color(android.graphics.Color.parseColor(accentHex)) }
                .getOrDefault(com.recallme.app.ui.theme.RedPrimary)

            val lockEnabled by viewModel.lockEnabled.collectAsState()
            val biometricEnabled by viewModel.biometricEnabled.collectAsState()
            val onboardingDone by viewModel.onboardingDone.collectAsState()
            var unlocked by remember { mutableStateOf(false) }

            RecallMeTheme(accentColor = accentColor) {
                when {
                    onboardingDone == null -> { /* chargement des preferences, on n'affiche rien */ }
                    onboardingDone == false -> {
                        OnboardingScreen(accentColor = accentColor, onFinish = { viewModel.setOnboardingDone() })
                    }
                    lockEnabled && !unlocked -> {
                        LockScreen(
                            accentColor = accentColor,
                            biometricEnabled = biometricEnabled,
                            onVerifyPin = { pin -> viewModel.verifyPin(pin) },
                            onUnlocked = { unlocked = true },
                            onRequestBiometric = { showBiometricPrompt { unlocked = true } }
                        )
                    }
                    else -> {
                        RecallMeNavHost(
                            viewModel = viewModel,
                            accentColor = accentColor,
                            startAtCreate = intent.getBooleanExtra("open_create", false)
                        )
                    }
                }
            }
        }
    }

    private fun showBiometricPrompt(onSuccess: () -> Unit) {
        val canAuthenticate = BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) return

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Déverrouiller RecallMe")
            .setSubtitle("Utilise ton empreinte ou ta reconnaissance faciale")
            .setNegativeButtonText("Utiliser le code PIN")
            .build()
        prompt.authenticate(info)
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        permissionLauncher.launch(permissions.toTypedArray())
    }
}
