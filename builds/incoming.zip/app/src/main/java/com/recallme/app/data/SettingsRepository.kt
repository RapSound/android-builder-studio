package com.recallme.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "recallme_settings")

/**
 * Gere la personnalisation complete (section 8 du cahier des charges) :
 * theme predefini, couleur d'accent personnalisee, langue.
 * Tout est stocke localement, aucune synchronisation obligatoire.
 */
class SettingsRepository(private val context: Context) {

    companion object {
        val ACCENT_COLOR = stringPreferencesKey("accent_color")
        val THEME_NAME = stringPreferencesKey("theme_name")
        val LANGUAGE = stringPreferencesKey("language")
        val LAST_BACKUP = longPreferencesKey("last_backup")
        val ALLOW_SELF_VALIDATION = stringPreferencesKey("allow_self_validation")
        val ONBOARDING_DONE = androidx.datastore.preferences.core.booleanPreferencesKey("onboarding_done")
        val DND_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("dnd_enabled")
        val DND_START_MINUTES = androidx.datastore.preferences.core.intPreferencesKey("dnd_start_minutes")
        val DND_END_MINUTES = androidx.datastore.preferences.core.intPreferencesKey("dnd_end_minutes")
    }

    val accentColor: Flow<String> = context.dataStore.data.map { it[ACCENT_COLOR] ?: "#D81F32" }
    val themeName: Flow<String> = context.dataStore.data.map { it[THEME_NAME] ?: "Rouge" }
    val language: Flow<String> = context.dataStore.data.map { it[LANGUAGE] ?: "Français" }
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[ONBOARDING_DONE] ?: false }
    val dndEnabled: Flow<Boolean> = context.dataStore.data.map { it[DND_ENABLED] ?: false }
    val dndStartMinutes: Flow<Int> = context.dataStore.data.map { it[DND_START_MINUTES] ?: (22 * 60) }
    val dndEndMinutes: Flow<Int> = context.dataStore.data.map { it[DND_END_MINUTES] ?: (7 * 60) }

    suspend fun setDndEnabled(enabled: Boolean) {
        context.dataStore.edit { it[DND_ENABLED] = enabled }
    }

    suspend fun setDndRange(startMinutes: Int, endMinutes: Int) {
        context.dataStore.edit {
            it[DND_START_MINUTES] = startMinutes
            it[DND_END_MINUTES] = endMinutes
        }
    }

    /**
     * Verifie si l'heure actuelle tombe dans la plage "Ne pas deranger"
     * (section "Mode Ne pas déranger"). Gere le passage a minuit (ex: 22h -> 7h).
     */
    suspend fun isWithinDnd(): Boolean {
        val enabled = context.dataStore.data.map { it[DND_ENABLED] ?: false }.first()
        if (!enabled) return false
        val start = context.dataStore.data.map { it[DND_START_MINUTES] ?: (22 * 60) }.first()
        val end = context.dataStore.data.map { it[DND_END_MINUTES] ?: (7 * 60) }.first()
        val now = java.util.Calendar.getInstance()
        val nowMinutes = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
        return if (start <= end) {
            nowMinutes in start until end
        } else {
            nowMinutes >= start || nowMinutes < end
        }
    }

    suspend fun setOnboardingDone() {
        context.dataStore.edit { it[ONBOARDING_DONE] = true }
    }

    suspend fun setAccentColor(hex: String) {
        context.dataStore.edit { it[ACCENT_COLOR] = hex }
    }

    suspend fun setThemeName(name: String) {
        context.dataStore.edit { it[THEME_NAME] = name }
    }

    suspend fun setLanguage(lang: String) {
        context.dataStore.edit { it[LANGUAGE] = lang }
    }
}
