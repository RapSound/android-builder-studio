package com.yttrendpulse.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.ui.graphics.vector.ImageVector
import com.yttrendpulse.app.R

/**
 * Les 6 menus principaux de l'application (1.8, 2.4).
 * L'ordre de cette liste correspond à l'ordre affiché dans la barre de navigation.
 */
sealed class Screen(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector,
) {
    data object Podium : Screen("podium", R.string.menu_podium, Icons.Filled.EmojiEvents)
    data object Figes : Screen("figes", R.string.menu_figes, Icons.Filled.Lock)
    data object Analyse : Screen("analyse", R.string.menu_analyse, Icons.Filled.Search)
    data object Charts : Screen("charts", R.string.menu_charts, Icons.Filled.ShowChart)
    data object Artistes : Screen("artistes", R.string.menu_artistes, Icons.Filled.Person)
    data object Parametres : Screen("parametres", R.string.menu_parametres, Icons.Filled.Settings)

    companion object {
        val bottomNavItems = listOf(Podium, Figes, Analyse, Charts, Artistes, Parametres)
    }
}
