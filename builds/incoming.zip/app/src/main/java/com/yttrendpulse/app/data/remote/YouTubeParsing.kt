package com.yttrendpulse.app.data.remote

import java.time.Duration
import java.time.Instant
import java.time.temporal.ChronoUnit

/**
 * Parsing des formats renvoyés par YouTube Data v3.
 * Utilise java.time nativement (disponible sans desugaring car minSdk = 26).
 */
object YouTubeParsing {

    /** "2026-05-01T12:34:56Z" -> timestamp en millisecondes. */
    fun parsePublishedAt(value: String): Long =
        runCatching { Instant.parse(value).toEpochMilli() }.getOrDefault(0L)

    /** "PT3M45S" -> 225 (secondes). */
    fun parseDurationSeconds(value: String): Int =
        runCatching { Duration.parse(value).seconds.toInt() }.getOrDefault(0)

    /** Timestamp RFC3339 correspondant à "il y a [days] jours", pour le paramètre publishedAfter. */
    fun publishedAfterDaysAgo(days: Long): String =
        Instant.now().minus(days, ChronoUnit.DAYS).toString()
}
