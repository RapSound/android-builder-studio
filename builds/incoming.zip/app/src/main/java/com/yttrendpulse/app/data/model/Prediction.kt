package com.yttrendpulse.app.data.model

/**
 * Résultat du moteur de prédiction pour un morceau (2.11).
 * Le moteur est versionné (recommandation 12.9 §5).
 */
data class Prediction(
    val trackId: String = "",
    val generatedAt: Long = 0L,
    val engineVersion: String = "1.0", // ex: "Prediction Engine v1.0"

    val horizonDays: Int = 7, // 3 / 7 / 15 / 30 jours, configurable (2.11)
    val confidencePercent: Double = 0.0, // ex: 93.0 -> "Prédiction fiable à 93 %"

    val predictedViews: List<PredictedPoint> = emptyList(),
    val predictedLikes: List<PredictedPoint> = emptyList(),
    val predictedComments: List<PredictedPoint> = emptyList(),
)

data class PredictedPoint(
    val date: Long,
    val value: Double,
)
