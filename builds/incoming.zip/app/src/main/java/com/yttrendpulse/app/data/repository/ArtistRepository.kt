package com.yttrendpulse.app.data.repository

import com.yttrendpulse.app.data.model.Artist
import kotlinx.coroutines.flow.Flow

/**
 * Contrat d'accès aux données Artistes (Firestore).
 * TODO: implémenter FirestoreArtistRepository (CRUD + écoute temps réel).
 */
interface ArtistRepository {
    fun observeArtists(): Flow<List<Artist>>
    suspend fun addArtist(name: String, youtubeChannelId: String): Result<Artist>
    suspend fun removeArtist(artistId: String): Result<Unit>
    suspend fun refreshArtistTracks(artistId: String): Result<Unit>
}
