package com.yttrendpulse.app.sync

import android.content.Context
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Planifie/annule le suivi renforcé d'un morceau (Graphique+, 2.12).
 *
 * ⚠️ Limite technique honnête : WorkManager n'autorise pas d'intervalle
 * périodique inférieur à 15 minutes, quel que soit l'intervalle demandé par
 * l'utilisateur — c'est une contrainte système Android, pas un choix produit.
 * Les valeurs proposées dans l'UI (Paramètres / page de détail) sont donc
 * bornées à 15 min minimum.
 */
object GraphPlusScheduler {
    const val MIN_INTERVAL_MINUTES = 15L

    fun schedule(context: Context, trackId: String, intervalMinutes: Int) {
        val safeInterval = maxOf(intervalMinutes.toLong(), MIN_INTERVAL_MINUTES)

        val request = PeriodicWorkRequestBuilder<EnhancedTrackWorker>(safeInterval, TimeUnit.MINUTES)
            .setInputData(Data.Builder().putString(EnhancedTrackWorker.KEY_TRACK_ID, trackId).build())
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            EnhancedTrackWorker.uniqueWorkName(trackId),
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }

    fun cancel(context: Context, trackId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(EnhancedTrackWorker.uniqueWorkName(trackId))
    }
}
