package com.yttrendpulse.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yttrendpulse.app.ui.theme.CardSurfaceElevated
import com.yttrendpulse.app.ui.theme.NegativeRed
import com.yttrendpulse.app.ui.theme.PositiveGreen
import com.yttrendpulse.app.ui.theme.TextGreyLight
import com.yttrendpulse.app.ui.theme.TextWhite
import com.yttrendpulse.app.ui.theme.YouTubeRed

/**
 * Badge circulaire affichant un score sur 100, avec un anneau de couleur
 * proportionnel (rouge YouTube). Utilisé sur les cartes de morceau.
 */
@Composable
fun ScoreBadge(score: Int, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 44.dp) {
    Box(
        modifier = modifier
            .size(size)
            .background(CardSurfaceElevated, CircleShape)
            .border(2.dp, YouTubeRed, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = score.coerceIn(0, 999).toString(),
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value / 3).sp,
        )
    }
}

/**
 * Petit indicateur de tendance (+X / -X) coloré, avec une flamme optionnelle
 * pour les morceaux "chauds" (récents, voir TrackRecency).
 */
@Composable
fun TrendChip(
    evolution: Double,
    isHot: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val isPositive = evolution >= 0
    val color = if (isPositive) PositiveGreen else NegativeRed

    Row(
        modifier = modifier
            .background(CardSurfaceElevated, RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (isHot) {
            Icon(
                Icons.Filled.LocalFireDepartment,
                contentDescription = "Tendance",
                tint = YouTubeRed,
                modifier = Modifier.size(14.dp),
            )
        }
        Icon(
            if (isPositive) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(14.dp),
        )
        Text(
            "${if (isPositive) "+" else ""}${evolution.toInt()}",
            color = color,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 2.dp),
        )
    }
}

/** Petit badge rond coloré, ex: rang numéroté (#4, #5...) dans une liste. */
@Composable
fun RankBadge(rank: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "$rank",
            color = TextGreyLight,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
        )
    }
}
