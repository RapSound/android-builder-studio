package com.yttrendpulse.app.ui.screens.auditlog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.model.AuditLogEntry
import com.yttrendpulse.app.data.repository.AuditLogRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuditLogUiState(
    val entries: List<AuditLogEntry> = emptyList(),
    val isLoading: Boolean = true,
)

class AuditLogViewModel(
    private val auditLogRepository: AuditLogRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuditLogUiState())
    val uiState: StateFlow<AuditLogUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            auditLogRepository.observeRecent().collect { entries ->
                _uiState.value = AuditLogUiState(entries = entries, isLoading = false)
            }
        }
    }
}
