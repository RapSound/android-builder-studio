package com.yttrendpulse.app.ui.screens.charts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yttrendpulse.app.data.repository.ChartType
import com.yttrendpulse.app.ui.components.FilterPillRow
import com.yttrendpulse.app.ui.components.TrackCard
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.theme.TextGreyLight
import org.koin.androidx.compose.koinViewModel

/**
 * Menu Charts (2.8) : Top Musique France via l'API officielle YouTube.
 * Note affichée à l'utilisateur : YouTube ne fournissant pas de chart par
 * genre, ceci est une approximation (pas un chart "Rap Français" strict).
 */
@Composable
fun ChartsScreen(
    onTrackClick: (trackId: String) -> Unit = {},
    viewModel: ChartsViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    LaunchedEffect(uiState.selectedType) {
        viewModel.load()
    }

    Scaffold(
        topBar = { YTTopBar(title = "📊 Charts", onRefresh = { viewModel.load() }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            FilterPillRow(
                options = listOf(
                    ChartType.TOP_20_RECENT to "Top 20",
                    ChartType.TOP_100_LONG_TERME to "Top 100",
                ),
                selected = uiState.selectedType,
                onSelect = { viewModel.selectType(it) },
            )

            Text(
                "Top Musique France (approximation : YouTube ne propose pas de " +
                    "chart \"Rap Français\" officiel)",
                color = TextGreyLight,
                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp),
            )

            when {
                uiState.isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                !uiState.hasLoaded -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                uiState.tracks.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Aucun résultat", color = TextGreyLight)
                    }
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.padding(top = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(items = uiState.tracks.withIndex().toList(), key = { it.value.id }) { (index, track) ->
                            TrackCard(
                                track = track,
                                isRecent = viewModel.isRecent(track),
                                rank = index + 1,
                                onClick = { onTrackClick(track.id) },
                            )
                        }
                    }
                }
            }
        }
    }
}
