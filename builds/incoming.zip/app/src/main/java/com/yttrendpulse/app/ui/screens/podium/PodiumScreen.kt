package com.yttrendpulse.app.ui.screens.podium

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yttrendpulse.app.ui.components.PodiumTop3
import com.yttrendpulse.app.ui.components.TrackCard
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.theme.TextGreyLight
import org.koin.androidx.compose.koinViewModel

/**
 * Écran principal : podium visuel (top 3, couronne + halo sur la 1ère place)
 * + classement top 4-10 (2.5). Branché sur PodiumViewModel -> TrackRepository
 * (Firestore) + SettingsRepository (seuil 🔥).
 * TODO: animations d'apparition/compteur de score (2.13) ; pour l'instant,
 * l'affichage est statique mais entièrement piloté par les données réelles.
 */
@Composable
fun PodiumScreen(
    onTrackClick: (trackId: String) -> Unit = {},
    viewModel: PodiumViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { YTTopBar(title = "🏆 Podium", onRefresh = { viewModel.refresh() }, onMenu = {}) },
    ) { padding ->
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (uiState.topThree.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Aucun morceau suivi pour le moment", color = TextGreyLight)
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                PodiumTop3(
                    tracks = uiState.topThree,
                    isRecent = { viewModel.isRecent(it, uiState) },
                    onTrackClick = { onTrackClick(it.id) },
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }

            if (uiState.rankFourToTen.isNotEmpty()) {
                item {
                    Text("Classement", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 4.dp))
                }
            }

            items(items = uiState.rankFourToTen.withIndex().toList(), key = { it.value.id }) { (index, track) ->
                TrackCard(
                    track = track,
                    isRecent = viewModel.isRecent(track, uiState),
                    rank = index + 4,
                    onClick = { onTrackClick(track.id) },
                )
            }
        }
    }
}
