package com.yttrendpulse.app.ui.screens.charts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.local.SettingsRepository
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.repository.ChartType
import com.yttrendpulse.app.data.repository.ChartsRepository
import com.yttrendpulse.app.domain.TrackRecency
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChartsUiState(
    val tracks: List<Track> = emptyList(),
    val selectedType: ChartType = ChartType.TOP_20_RECENT,
    val recentThresholdDays: Int = SettingsRepository.DEFAULT_RECENT_THRESHOLD_DAYS,
    val isLoading: Boolean = false,
    val hasLoaded: Boolean = false,
    val errorMessage: String? = null,
)

/**
 * Alimente le menu Charts (2.8) : Top Musique France (approximation du chart
 * "Rap Français", cf. limite documentée dans YouTubeChartsRepository),
 * via l'API officielle YouTube (pas de scraping).
 */
class ChartsViewModel(
    private val chartsRepository: ChartsRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChartsUiState())
    val uiState: StateFlow<ChartsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.recentThresholdDays.collect { days ->
                _uiState.value = _uiState.value.copy(recentThresholdDays = days)
            }
        }
    }

    fun selectType(type: ChartType) {
        _uiState.value = _uiState.value.copy(selectedType = type)
    }

    fun load() {
        val type = _uiState.value.selectedType
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            chartsRepository.loadChart(type)
                .onSuccess { tracks ->
                    _uiState.value = _uiState.value.copy(tracks = tracks, isLoading = false, hasLoaded = true)
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "Erreur lors du chargement des charts.",
                    )
                }
        }
    }

    fun isRecent(track: Track): Boolean = TrackRecency.isRecent(track, _uiState.value.recentThresholdDays)

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
