package com.yttrendpulse.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

// L'application fonctionne uniquement en mode sombre (voir cahier des charges 2.2).
// Un mode clair pourra être ajouté plus tard sans changer la structure ci-dessous.
private val YTDarkColorScheme = darkColorScheme(
    primary = YouTubeRed,
    secondary = LightRed,
    background = BackgroundBlack,
    surface = CardDarkGrey,
    onPrimary = TextWhite,
    onSecondary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextWhite,
    error = NegativeRed,
)

@Composable
fun YTTrendPulseTheme(
    // Paramètre conservé pour une future option de mode clair (2.2)
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = YTDarkColorScheme,
        typography = YTTypography,
        content = content
    )
}
