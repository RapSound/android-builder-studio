package com.yttrendpulse.app.data.repository

import com.yttrendpulse.app.data.model.AuditLogEntry
import kotlinx.coroutines.flow.Flow

/**
 * Journal d'audit des modifications manuelles (recommandation 12.9 §1).
 * Les actions automatiques du DailySyncWorker ne sont volontairement pas
 * journalisées ici (trop volumineux) : seules les actions manuelles de
 * l'utilisateur le sont, pour rester lisible.
 */
interface AuditLogRepository {
    suspend fun log(action: String, targetId: String, details: String = "")
    fun observeRecent(limit: Int = 50): Flow<List<AuditLogEntry>>
}
