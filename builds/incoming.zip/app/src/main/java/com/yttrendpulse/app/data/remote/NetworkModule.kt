package com.yttrendpulse.app.data.remote

import com.yttrendpulse.app.BuildConfig
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Construit le client Retrofit pour l'API YouTube Data v3.
 * La clé API vient de BuildConfig.YOUTUBE_API_KEY (définie via local.properties, jamais en dur).
 */
object NetworkModule {

    private const val BASE_URL = "https://www.googleapis.com/youtube/v3/"

    private val apiKeyInterceptor = Interceptor { chain ->
        val original = chain.request()
        val newUrl = original.url.newBuilder()
            .addQueryParameter("key", BuildConfig.YOUTUBE_API_KEY)
            .build()
        chain.proceed(original.newBuilder().url(newUrl).build())
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.BASIC
        } else {
            HttpLoggingInterceptor.Level.NONE
        }
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(apiKeyInterceptor)
        .addInterceptor(loggingInterceptor)
        .build()

    val youTubeApiService: YouTubeApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL.toHttpUrl())
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(YouTubeApiService::class.java)
    }
}
