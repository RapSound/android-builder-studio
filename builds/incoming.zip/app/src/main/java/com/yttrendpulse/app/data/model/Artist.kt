package com.yttrendpulse.app.data.model

/**
 * Représente un artiste suivi par l'application (menu Artistes, 2.9).
 * L'identifiant [id] doit être unique et stable (recommandation 12.9 §4).
 */
data class Artist(
    val id: String = "",
    val name: String = "",
    val youtubeChannelId: String = "",
    val channelLogoUrl: String = "",
    val recentTracksCount: Int = 0, // morceaux de moins de 25 jours (1.9)
    val createdAt: Long = 0L,
)
