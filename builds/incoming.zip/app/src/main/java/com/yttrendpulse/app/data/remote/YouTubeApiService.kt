package com.yttrendpulse.app.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Endpoints YouTube Data v3 utilisés par l'app (1.4).
 * La clé API est injectée automatiquement via un Interceptor (voir NetworkModule, à créer).
 * Doc officielle : https://developers.google.com/youtube/v3/docs
 */
interface YouTubeApiService {

    @GET("search")
    suspend fun searchVideos(
        @Query("q") query: String? = null,
        @Query("channelId") channelId: String? = null,
        @Query("order") order: String? = null, // "date" pour les plus récentes d'abord (1.9)
        @Query("publishedAfter") publishedAfter: String? = null, // RFC 3339, ex: 2026-06-28T00:00:00Z
        @Query("part") part: String = "snippet",
        @Query("type") type: String = "video",
        @Query("maxResults") maxResults: Int = 25,
    ): YouTubeSearchResponse

    @GET("videos")
    suspend fun getVideoStatistics(
        @Query("id") videoIds: String, // séparés par des virgules
        @Query("part") part: String = "snippet,statistics,contentDetails",
    ): YouTubeVideosResponse

    /**
     * Endpoint officiel "chart" de YouTube Data v3 (2.8).
     * YouTube ne propose pas de chart par genre (pas de "Rap Français" officiel) :
     * on utilise le chart "mostPopular" filtré par région + catégorie Musique (10),
     * seule approche à la fois légale et stable (pas de scraping).
     */
    @GET("videos")
    suspend fun getMostPopularVideos(
        @Query("chart") chart: String = "mostPopular",
        @Query("regionCode") regionCode: String = "FR",
        @Query("videoCategoryId") videoCategoryId: String = "10", // Musique
        @Query("part") part: String = "snippet,statistics,contentDetails",
        @Query("maxResults") maxResults: Int = 50,
        @Query("pageToken") pageToken: String? = null,
    ): YouTubeVideosResponse

    @GET("channels")
    suspend fun getChannelInfo(
        @Query("id") channelId: String,
        @Query("part") part: String = "snippet",
    ): YouTubeChannelResponse
}

// --- DTOs minimaux (à compléter selon les champs réellement consommés) ---

data class YouTubeSearchResponse(val items: List<YouTubeSearchItem> = emptyList())
data class YouTubeSearchItem(val id: YouTubeIdWrapper, val snippet: YouTubeSnippet)
data class YouTubeIdWrapper(val videoId: String?)

data class YouTubeVideosResponse(
    val items: List<YouTubeVideoItem> = emptyList(),
    val nextPageToken: String? = null,
)
data class YouTubeVideoItem(
    val id: String,
    val snippet: YouTubeSnippet,
    val statistics: YouTubeStatistics,
    val contentDetails: YouTubeContentDetails,
)

data class YouTubeSnippet(
    val title: String,
    val channelTitle: String,
    val publishedAt: String,
    val thumbnails: YouTubeThumbnails,
)

data class YouTubeThumbnails(val high: YouTubeThumbnail?)
data class YouTubeThumbnail(val url: String)

data class YouTubeStatistics(
    val viewCount: String?,
    val likeCount: String?,
    val commentCount: String?,
)

data class YouTubeContentDetails(val duration: String)

data class YouTubeChannelResponse(val items: List<YouTubeChannelItem> = emptyList())
data class YouTubeChannelItem(val id: String, val snippet: YouTubeSnippet)
