package com.yttrendpulse.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.ui.theme.BronzeMedal
import com.yttrendpulse.app.ui.theme.CardDarkGrey
import com.yttrendpulse.app.ui.theme.GoldMedal
import com.yttrendpulse.app.ui.theme.SilverMedal
import com.yttrendpulse.app.ui.theme.TextGreyLight
import com.yttrendpulse.app.ui.theme.YouTubeRed

/**
 * Carte standard pour un morceau (Podium 2.5, Figés 2.6, Charts 2.8, Analyse 2.7).
 * [isRecent] ajoute un halo rouge lumineux (contour 🔥 décrit en 2.5).
 * [rank] optionnel : affiche un numéro de classement à gauche (Charts, suite du Podium).
 */
@Composable
fun TrackCard(
    track: Track,
    isRecent: Boolean,
    modifier: Modifier = Modifier,
    rank: Int? = null,
    onClick: () -> Unit = {},
) {
    val evolution = track.currentScore - track.previousScore

    Card(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (isRecent) {
                    Modifier.shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = YouTubeRed,
                        spotColor = YouTubeRed,
                    )
                } else {
                    Modifier
                },
            ),
        colors = CardDefaults.cardColors(containerColor = CardDarkGrey),
        border = if (isRecent) BorderStroke(1.5.dp, YouTubeRed) else null,
        shape = RoundedCornerShape(16.dp),
        onClick = onClick,
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (rank != null) {
                RankBadge(rank, modifier = Modifier.width(28.dp))
            }

            Box {
                AsyncImage(
                    model = track.thumbnailUrl,
                    contentDescription = track.title,
                    modifier = Modifier.size(60.dp).clip(RoundedCornerShape(12.dp)),
                )
                if (isRecent) {
                    Box(
                        modifier = Modifier
                            .padding(2.dp)
                            .size(18.dp)
                            .background(YouTubeRed, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("🔥")
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artistName, color = TextGreyLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                ScoreBadge(score = track.currentScore.toInt(), size = 40.dp)
                Spacer(modifier = Modifier.padding(top = 4.dp))
                TrendChip(evolution = evolution, isHot = isRecent)
            }
        }
    }
}

/**
 * Carte compacte pour affichage en grille 2 colonnes (Figés, 2.6) : image en
 * haut avec badges superposés (🔥 et score), titre/artiste en dessous.
 */
@Composable
fun TrackGridCard(
    track: Track,
    isRecent: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
) {
    val evolution = track.currentScore - track.previousScore

    Card(
        modifier = modifier
            .then(
                if (isRecent) {
                    Modifier.shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = YouTubeRed,
                        spotColor = YouTubeRed,
                    )
                } else {
                    Modifier
                },
            ),
        colors = CardDefaults.cardColors(containerColor = CardDarkGrey),
        border = if (isRecent) BorderStroke(1.5.dp, YouTubeRed) else null,
        shape = RoundedCornerShape(16.dp),
        onClick = onClick,
    ) {
        Column {
            Box {
                AsyncImage(
                    model = track.thumbnailUrl,
                    contentDescription = track.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .size(110.dp)
                        .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                )
                if (isRecent) {
                    Box(
                        modifier = Modifier
                            .padding(6.dp)
                            .size(22.dp)
                            .background(YouTubeRed, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("🔥")
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artistName, color = TextGreyLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ScoreBadge(score = track.currentScore.toInt(), size = 36.dp)
                    TrendChip(evolution = evolution, isHot = isRecent)
                }
            }
        }
    }
}

private val Int.medalColor: androidx.compose.ui.graphics.Color
    get() = when (this) {
        1 -> GoldMedal
        2 -> SilverMedal
        else -> BronzeMedal
    }

/**
 * Une place du podium (top 3), avec anneau coloré selon la médaille et halo
 * lumineux + couronne pour la 1ère place. Voir [PodiumTop3] pour l'agencement.
 */
@Composable
fun PodiumSpot(
    rank: Int,
    track: Track,
    isRecent: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
) {
    val isFirst = rank == 1
    val medalColor = rank.medalColor
    val avatarSize = if (isFirst) 88.dp else 64.dp

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (isFirst) {
            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = GoldMedal)
        }

        Box(
            modifier = Modifier
                .then(
                    if (isFirst) {
                        Modifier.shadow(16.dp, CircleShape, ambientColor = YouTubeRed, spotColor = YouTubeRed)
                    } else {
                        Modifier
                    },
                )
                .size(avatarSize)
                .border(3.dp, medalColor, CircleShape)
                .padding(3.dp)
                .clip(CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                contentDescription = track.title,
                modifier = Modifier.size(avatarSize - 8.dp).clip(CircleShape),
            )
        }

        Spacer(modifier = Modifier.padding(top = 6.dp))
        Text(
            track.title,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Text(
            track.artistName,
            color = TextGreyLight,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(modifier = Modifier.padding(top = 4.dp))
        ScoreBadge(score = track.currentScore.toInt(), size = if (isFirst) 48.dp else 40.dp)
    }
}

/**
 * Agencement classique du podium : #2 à gauche, #1 au centre (plus grand,
 * mis en avant), #3 à droite. [tracks] doit être trié par score décroissant.
 */
@Composable
fun PodiumTop3(
    tracks: List<Track>,
    isRecent: (Track) -> Boolean,
    onTrackClick: (Track) -> Unit,
    modifier: Modifier = Modifier,
) {
    val first = tracks.getOrNull(0)
    val second = tracks.getOrNull(1)
    val third = tracks.getOrNull(2)

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom,
    ) {
        second?.let {
            PodiumSpot(2, it, isRecent(it), modifier = Modifier.weight(1f), onClick = { onTrackClick(it) })
        }
        first?.let {
            PodiumSpot(1, it, isRecent(it), modifier = Modifier.weight(1.15f), onClick = { onTrackClick(it) })
        }
        third?.let {
            PodiumSpot(3, it, isRecent(it), modifier = Modifier.weight(1f), onClick = { onTrackClick(it) })
        }
    }
}
