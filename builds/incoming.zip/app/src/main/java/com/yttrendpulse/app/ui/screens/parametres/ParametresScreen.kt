package com.yttrendpulse.app.ui.screens.parametres

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.screens.auth.AuthViewModel
import org.koin.androidx.compose.koinViewModel

/**
 * Menu Paramètres (1.8) : compte connecté, seuil "récent" (contour 🔥),
 * horizon de prédiction par défaut, synchronisation manuelle, journal
 * d'audit, santé du moteur.
 */
@Composable
fun ParametresScreen(
    onNavigateToAuditLog: () -> Unit = {},
    onNavigateToHealth: () -> Unit = {},
    viewModel: ParametresViewModel = koinViewModel(),
    authViewModel: AuthViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val authState by authViewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = { YTTopBar(title = "Paramètres") },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            ListItem(
                headlineContent = { Text("Compte") },
                supportingContent = { Text(authState.user?.email ?: "") },
                trailingContent = {
                    TextButton(onClick = { authViewModel.signOut() }) {
                        Text("Déconnexion")
                    }
                },
            )

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Seuil \"récent\" (contour 🔥)") },
                supportingContent = {
                    Column {
                        Text("${uiState.recentThresholdDays} jour(s)")
                        Slider(
                            value = uiState.recentThresholdDays.toFloat(),
                            onValueChange = { viewModel.setRecentThresholdDays(it.toInt()) },
                            valueRange = 1f..30f,
                            steps = 28,
                        )
                    }
                },
            )

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Horizon de prédiction par défaut") },
                supportingContent = {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(3, 7, 15, 30).forEach { days ->
                            FilterChip(
                                selected = uiState.defaultPredictionHorizonDays == days,
                                onClick = { viewModel.setDefaultPredictionHorizonDays(days) },
                                label = { Text("$days j") },
                            )
                        }
                    }
                },
            )

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Synchronisation manuelle") },
                supportingContent = { Text("Force une synchro immédiate (sans attendre minuit)") },
                trailingContent = {
                    if (uiState.isSyncing) {
                        CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp))
                    } else {
                        Button(onClick = { viewModel.triggerManualSync() }) {
                            Text("Lancer")
                        }
                    }
                },
            )

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Journal d'audit") },
                supportingContent = { Text("Historique des actions manuelles") },
                trailingContent = { Icon(Icons.Filled.ChevronRight, contentDescription = null) },
                modifier = Modifier.clickable { onNavigateToAuditLog() },
            )

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Santé du moteur") },
                supportingContent = { Text("Volumes suivis, versions, état de la synchro") },
                trailingContent = { Icon(Icons.Filled.ChevronRight, contentDescription = null) },
                modifier = Modifier.clickable { onNavigateToHealth() },
            )

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("À propos") },
                supportingContent = { Text("YT-Trend-Pulse v1.0") },
            )
        }
    }
}
