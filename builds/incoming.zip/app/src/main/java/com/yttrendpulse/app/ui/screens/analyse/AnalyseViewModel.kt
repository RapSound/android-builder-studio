package com.yttrendpulse.app.ui.screens.analyse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.remote.YouTubeApiService
import com.yttrendpulse.app.data.remote.YouTubeParsing
import com.yttrendpulse.app.data.repository.TrackRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Résultat de recherche YouTube affiché avant tout ajout en base (2.7). */
data class AnalyseResult(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val thumbnailUrl: String,
    val publishedAt: Long,
    val viewCount: Long,
)

data class AnalyseUiState(
    val results: List<AnalyseResult> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val hasSearched: Boolean = false,
)

/**
 * Alimente le menu Analyse (2.7) : recherche en direct sur YouTube (titre
 * obligatoire, artiste facultatif), puis ajout du morceau choisi en base
 * (créé s'il n'existe pas encore) avant d'ouvrir sa page de détail.
 */
class AnalyseViewModel(
    private val youTubeApiService: YouTubeApiService,
    private val trackRepository: TrackRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AnalyseUiState())
    val uiState: StateFlow<AnalyseUiState> = _uiState.asStateFlow()

    fun search(title: String, artist: String) {
        if (title.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Le titre est obligatoire.")
            return
        }

        val query = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" ")

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null, hasSearched = true)
            try {
                val searchResponse = youTubeApiService.searchVideos(query = query, maxResults = 15)
                val videoIds = searchResponse.items.mapNotNull { it.id.videoId }

                if (videoIds.isEmpty()) {
                    _uiState.value = _uiState.value.copy(results = emptyList(), isLoading = false)
                    return@launch
                }

                val statsResponse = youTubeApiService.getVideoStatistics(videoIds = videoIds.joinToString(","))
                val results = statsResponse.items.map { item ->
                    AnalyseResult(
                        videoId = item.id,
                        title = item.snippet.title,
                        channelTitle = item.snippet.channelTitle,
                        thumbnailUrl = item.snippet.thumbnails.high?.url ?: "",
                        publishedAt = YouTubeParsing.parsePublishedAt(item.snippet.publishedAt),
                        viewCount = item.statistics.viewCount?.toLongOrNull() ?: 0L,
                    )
                }
                _uiState.value = _uiState.value.copy(results = results, isLoading = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message ?: "Erreur lors de la recherche YouTube.",
                )
            }
        }
    }

    /**
     * Ajoute [result] en base s'il n'y est pas déjà (comparaison sur youtubeVideoId),
     * puis renvoie l'id du morceau via [onReady] pour naviguer vers sa page de détail.
     * TODO: à terme, préférer une requête Firestore indexée sur youtubeVideoId plutôt
     * que de recharger tous les morceaux actifs (suffisant tant que le volume reste modeste).
     */
    fun trackAndOpen(result: AnalyseResult, onReady: (trackId: String) -> Unit) {
        viewModelScope.launch {
            val existing = trackRepository.getAllActiveTracks().getOrDefault(emptyList())
                .firstOrNull { it.youtubeVideoId == result.videoId }

            if (existing != null) {
                onReady(existing.id)
                return@launch
            }

            val track = Track(
                youtubeVideoId = result.videoId,
                title = result.title,
                artistName = result.channelTitle,
                thumbnailUrl = result.thumbnailUrl,
                publishedAt = result.publishedAt,
                viewCount = result.viewCount,
            )
            trackRepository.upsertTrack(track)
                .onSuccess { saved -> onReady(saved.id) }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(errorMessage = e.message ?: "Erreur lors de l'ajout.")
                }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
