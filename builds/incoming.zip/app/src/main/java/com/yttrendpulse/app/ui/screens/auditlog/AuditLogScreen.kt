package com.yttrendpulse.app.ui.screens.auditlog

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yttrendpulse.app.data.model.AuditLogEntry
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.theme.TextGreyLight
import org.koin.androidx.compose.koinViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val DATE_FORMAT = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)

private val ACTION_LABELS = mapOf(
    "ARTIST_ADDED" to "Artiste ajouté",
    "ARTIST_REMOVED" to "Artiste supprimé",
    "TRACK_PINNED" to "Morceau figé",
    "TRACK_UNPINNED" to "Morceau défigé",
    "GRAPH_PLUS_ENABLED" to "Graphique+ activé",
    "GRAPH_PLUS_DISABLED" to "Graphique+ désactivé",
    "MANUAL_SYNC" to "Synchronisation manuelle",
)

/** Journal d'audit des modifications manuelles (12.9 §1), accessible depuis Paramètres. */
@Composable
fun AuditLogScreen(
    onBack: () -> Unit,
    viewModel: AuditLogViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { YTTopBar(title = "Journal d'audit", onBack = onBack) },
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            uiState.entries.isEmpty() -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("Aucune action journalisée pour le moment", color = TextGreyLight)
                }
            }
            else -> {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
                    items(items = uiState.entries, key = { it.id }) { entry ->
                        AuditLogRow(entry)
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditLogRow(entry: AuditLogEntry) {
    ListItem(
        headlineContent = { Text(ACTION_LABELS[entry.action] ?: entry.action) },
        supportingContent = {
            Column {
                if (entry.details.isNotBlank()) Text(entry.details)
                Text(DATE_FORMAT.format(Date(entry.timestamp)), color = TextGreyLight)
            }
        },
    )
}
