package com.yttrendpulse.app.data.repository

import kotlinx.coroutines.flow.Flow

data class AuthUser(val uid: String, val email: String?)

/** Authentification par vrai compte (email/mot de passe), via Firebase Auth. */
interface AuthRepository {
    /** Émet l'utilisateur connecté (ou null) à chaque changement d'état d'authentification. */
    val currentUser: Flow<AuthUser?>

    suspend fun signIn(email: String, password: String): Result<Unit>
    suspend fun signUp(email: String, password: String): Result<Unit>
    fun signOut()
}
