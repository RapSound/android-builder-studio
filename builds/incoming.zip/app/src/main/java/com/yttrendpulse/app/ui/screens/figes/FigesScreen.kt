package com.yttrendpulse.app.ui.screens.figes

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yttrendpulse.app.ui.components.TrackGridCard
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.theme.TextGreyLight
import org.koin.androidx.compose.koinViewModel

/**
 * Menu Figés (2.6) : morceaux épinglés, en grille 2 colonnes, avec le même
 * halo 🔥 que le Podium. Branché sur FigesViewModel ->
 * TrackRepository.observePinnedTracks(). Le "Défiger" se fait depuis la
 * page de détail du morceau (bouton déjà présent).
 */
@Composable
fun FigesScreen(
    onTrackClick: (trackId: String) -> Unit = {},
    viewModel: FigesViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { YTTopBar(title = "🔒 Figés") },
    ) { padding ->
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (uiState.tracks.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Aucun morceau figé pour le moment", color = TextGreyLight)
            }
            return@Scaffold
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(items = uiState.tracks, key = { it.id }) { track ->
                TrackGridCard(
                    track = track,
                    isRecent = viewModel.isRecent(track),
                    onClick = { onTrackClick(track.id) },
                )
            }
        }
    }
}
