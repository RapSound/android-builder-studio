package com.yttrendpulse.app.ui.screens.artistes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.model.Artist
import com.yttrendpulse.app.data.repository.ArtistRepository
import com.yttrendpulse.app.data.repository.AuditLogRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ArtistesUiState(
    val artists: List<Artist> = emptyList(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
)

class ArtistesViewModel(
    private val repository: ArtistRepository,
    private val auditLogRepository: AuditLogRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ArtistesUiState())
    val uiState: StateFlow<ArtistesUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeArtists().collect { artists ->
                _uiState.value = _uiState.value.copy(artists = artists, isLoading = false)
            }
        }
    }

    fun addArtist(name: String, channelId: String) {
        if (name.isBlank() || channelId.isBlank()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Le nom et l'ID de chaîne YouTube sont obligatoires.",
            )
            return
        }
        viewModelScope.launch {
            repository.addArtist(name, channelId)
                .onSuccess { artist -> auditLogRepository.log("ARTIST_ADDED", artist.id, artist.name) }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(errorMessage = e.message ?: "Erreur lors de l'ajout.")
                }
        }
    }

    fun removeArtist(artistId: String) {
        viewModelScope.launch {
            repository.removeArtist(artistId)
                .onSuccess { auditLogRepository.log("ARTIST_REMOVED", artistId) }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(errorMessage = e.message ?: "Erreur lors de la suppression.")
                }
        }
    }

    fun refreshArtist(artistId: String) {
        viewModelScope.launch { repository.refreshArtistTracks(artistId) }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
