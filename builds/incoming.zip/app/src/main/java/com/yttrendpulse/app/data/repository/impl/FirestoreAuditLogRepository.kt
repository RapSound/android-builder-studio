package com.yttrendpulse.app.data.repository.impl

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.yttrendpulse.app.data.CurrentUser
import com.yttrendpulse.app.data.model.AuditLogEntry
import com.yttrendpulse.app.data.repository.AuditLogRepository
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirestoreAuditLogRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
) : AuditLogRepository {

    private val collection
        get() = firestore.collection("users").document(CurrentUser.requireUid()).collection("audit_log")

    override suspend fun log(action: String, targetId: String, details: String) {
        // Best-effort : un échec de journalisation ne doit jamais casser l'action réelle.
        runCatching {
            val docRef = collection.document()
            docRef.set(
                AuditLogEntry(
                    id = docRef.id,
                    timestamp = System.currentTimeMillis(),
                    action = action,
                    targetId = targetId,
                    details = details,
                ),
            ).await()
        }
    }

    override fun observeRecent(limit: Int): Flow<List<AuditLogEntry>> = callbackFlow {
        if (CurrentUser.uid == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        val registration = collection
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(limit.toLong())
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val entries = snapshot?.documents?.mapNotNull { it.toObject(AuditLogEntry::class.java) } ?: emptyList()
                trySend(entries)
            }
        awaitClose { registration.remove() }
    }
}
