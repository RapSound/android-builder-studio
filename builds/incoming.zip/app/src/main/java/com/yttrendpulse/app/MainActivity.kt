package com.yttrendpulse.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.rememberNavController
import com.yttrendpulse.app.navigation.YTNavGraph
import com.yttrendpulse.app.navigation.trackDetailRoute
import com.yttrendpulse.app.notifications.NotificationHelper
import com.yttrendpulse.app.ui.components.YTBottomNavBar
import com.yttrendpulse.app.ui.screens.auth.AuthViewModel
import com.yttrendpulse.app.ui.screens.auth.LoginScreen
import com.yttrendpulse.app.ui.theme.YTTrendPulseTheme
import org.koin.androidx.compose.koinViewModel

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op : voir NotificationHelper.notify() */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestNotificationPermissionIfNeeded()

        // Si l'app est ouverte depuis une notification (2.11/notifications), on
        // récupère le morceau concerné pour naviguer directement dessus.
        val initialTrackId = intent?.getStringExtra(NotificationHelper.EXTRA_TRACK_ID)

        setContent {
            YTTrendPulseTheme {
                AppRoot(initialTrackId = initialTrackId)
            }
        }
    }

    /** Android 13+ (API 33) exige une permission runtime pour poster des notifications. */
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // TODO: gérer onNewIntent() pour le cas où l'app est déjà ouverte quand on
    // tape sur une notification (actuellement seul le lancement à froid est géré).
}

/**
 * Racine de l'app : affiche l'écran de connexion tant qu'aucun compte n'est
 * connecté (vrai compte Firebase Auth), sinon l'app principale (6 menus).
 */
@Composable
private fun AppRoot(initialTrackId: String? = null) {
    val authViewModel: AuthViewModel = koinViewModel()
    val authState by authViewModel.uiState.collectAsStateWithLifecycle()

    when {
        authState.isCheckingSession -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        authState.user == null -> {
            LoginScreen(viewModel = authViewModel)
        }
        else -> {
            YTTrendPulseApp(initialTrackId = initialTrackId)
        }
    }
}

@Composable
private fun YTTrendPulseApp(initialTrackId: String? = null) {
    val navController = rememberNavController()

    LaunchedEffect(initialTrackId) {
        if (!initialTrackId.isNullOrBlank()) {
            navController.navigate(trackDetailRoute(initialTrackId))
        }
    }

    Scaffold(
        bottomBar = { YTBottomNavBar(navController) },
    ) { padding ->
        YTNavGraph(
            navController = navController,
            modifier = Modifier.padding(padding),
        )
    }
}
