package com.yttrendpulse.app.ui.screens.figes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.local.SettingsRepository
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.domain.TrackRecency
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class FigesUiState(
    val tracks: List<Track> = emptyList(),
    val recentThresholdDays: Int = SettingsRepository.DEFAULT_RECENT_THRESHOLD_DAYS,
    val isLoading: Boolean = true,
)

/**
 * Alimente le menu Figés (2.6) : morceaux épinglés, en temps réel, via
 * TrackRepository.observePinnedTracks(). Le contour 🔥 suit le même seuil
 * configurable que le Podium (SettingsRepository).
 */
class FigesViewModel(
    private val trackRepository: TrackRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(FigesUiState())
    val uiState: StateFlow<FigesUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                trackRepository.observePinnedTracks(),
                settingsRepository.recentThresholdDays,
            ) { tracks, thresholdDays ->
                FigesUiState(tracks = tracks, recentThresholdDays = thresholdDays, isLoading = false)
            }.collect { state -> _uiState.value = state }
        }
    }

    fun isRecent(track: Track): Boolean = TrackRecency.isRecent(track, _uiState.value.recentThresholdDays)
}
