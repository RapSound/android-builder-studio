package com.yttrendpulse.app.ui.components

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.yttrendpulse.app.data.model.HistoryEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Les 3 métriques disponibles sur la page de détail d'un morceau (2.10). */
enum class ChartMetric(val label: String) {
    VIEWS("Vues"),
    LIKES("Likes"),
    COMMENTS("Commentaires"),
}

/** Valeur brute de [metric] pour une entrée d'historique (réutilisé par PredictionEngine). */
fun HistoryEntry.valueFor(metric: ChartMetric): Long = when (metric) {
    ChartMetric.VIEWS -> viewCount
    ChartMetric.LIKES -> likeCount
    ChartMetric.COMMENTS -> commentCount
}

private const val REAL_LINE_COLOR = "#FF0000"      // YouTubeRed (2.2)
private const val PREDICTED_LINE_COLOR = "#FF4C4C" // LightRed (2.2)

/**
 * Graphique d'évolution d'une métrique à partir de l'historique réel (2.10).
 * Trait plein = données réelles (alimentées chaque nuit par DailySyncWorker),
 * pointillé = prédiction (2.11 — vide tant que le moteur de prédiction n'existe pas,
 * le rendu est déjà prêt à recevoir des HistoryEntry avec isPredicted = true).
 */
@Composable
fun HistoryLineChart(
    history: List<HistoryEntry>,
    metric: ChartMetric,
    modifier: Modifier = Modifier,
) {
    val sorted = remember(history) { history.sortedBy { it.date } }
    val dateFormatter = remember { SimpleDateFormat("dd/MM", Locale.FRANCE) }

    AndroidView(
        modifier = modifier.fillMaxWidth().height(220.dp),
        factory = { context -> LineChart(context).apply { configureAppearance() } },
        update = { chart -> chart.applyHistory(sorted, metric, dateFormatter) },
    )
}

private fun LineChart.configureAppearance() {
    description.isEnabled = false
    legend.isEnabled = false
    setTouchEnabled(true)
    setPinchZoom(true)
    setBackgroundColor(AndroidColor.TRANSPARENT)
    axisRight.isEnabled = false
    axisLeft.textColor = AndroidColor.LTGRAY
    axisLeft.setDrawGridLines(true)
    axisLeft.gridColor = AndroidColor.DKGRAY
    xAxis.textColor = AndroidColor.LTGRAY
    xAxis.position = XAxis.XAxisPosition.BOTTOM
    xAxis.setDrawGridLines(false)
    xAxis.granularity = 1f
}

private fun LineChart.applyHistory(
    sorted: List<HistoryEntry>,
    metric: ChartMetric,
    dateFormatter: SimpleDateFormat,
) {
    if (sorted.isEmpty()) {
        clear()
        invalidate()
        return
    }

    val realEntries = sorted.filterNot { it.isPredicted }
    val predictedEntries = sorted.filter { it.isPredicted }

    val realPoints = realEntries.mapIndexed { index, entry -> Entry(index.toFloat(), entry.valueFor(metric).toFloat()) }
    val realSet = LineDataSet(realPoints, "Réel").apply {
        color = AndroidColor.parseColor(REAL_LINE_COLOR)
        setCircleColor(AndroidColor.parseColor(REAL_LINE_COLOR))
        lineWidth = 2f
        circleRadius = 3f
        setDrawValues(false)
        mode = LineDataSet.Mode.LINEAR
    }

    val dataSets = mutableListOf<LineDataSet>(realSet)

    if (predictedEntries.isNotEmpty()) {
        val offset = realPoints.size
        val predictedPoints = predictedEntries.mapIndexed { index, entry ->
            Entry((offset + index).toFloat(), entry.valueFor(metric).toFloat())
        }
        val predictedSet = LineDataSet(predictedPoints, "Prédiction").apply {
            color = AndroidColor.parseColor(PREDICTED_LINE_COLOR)
            enableDashedLine(12f, 8f, 0f)
            setDrawCircles(false)
            setDrawValues(false)
            lineWidth = 2f
        }
        dataSets += predictedSet
    }

    data = LineData(dataSets.toList())

    val orderedDates = (realEntries + predictedEntries).map { it.date }
    xAxis.valueFormatter = object : ValueFormatter() {
        override fun getFormattedValue(value: Float): String {
            val date = orderedDates.getOrNull(value.toInt()) ?: return ""
            return dateFormatter.format(Date(date))
        }
    }

    invalidate()
}
