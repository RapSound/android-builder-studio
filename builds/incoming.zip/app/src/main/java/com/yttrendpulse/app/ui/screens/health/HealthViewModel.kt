package com.yttrendpulse.app.ui.screens.health

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.yttrendpulse.app.data.repository.ArtistRepository
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.domain.PredictionEngine
import com.yttrendpulse.app.domain.ViralScoreEngine
import com.yttrendpulse.app.sync.DailySyncWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class HealthUiState(
    val artistCount: Int = 0,
    val activeTrackCount: Int = 0,
    val lastSyncState: String = "Chargement…",
    val scoreEngineVersion: String = ViralScoreEngine.VERSION,
    val predictionEngineVersion: String = PredictionEngine.VERSION,
    val isLoading: Boolean = true,
)

/**
 * Écran de santé du moteur (recommandation 12.9 §2) : vue d'ensemble
 * technique — volumes suivis, versions des moteurs, état de la dernière
 * synchronisation (lu directement depuis WorkManager, pas de log dédié).
 */
class HealthViewModel(
    private val context: Context,
    private val artistRepository: ArtistRepository,
    private val trackRepository: TrackRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(HealthUiState())
    val uiState: StateFlow<HealthUiState> = _uiState.asStateFlow()

    init {
        refresh()
        observeSyncState()
    }

    fun refresh() {
        viewModelScope.launch {
            val artists = artistRepository.observeArtists().first()
            val tracks = trackRepository.getAllActiveTracks().getOrDefault(emptyList())
            _uiState.value = _uiState.value.copy(
                artistCount = artists.size,
                activeTrackCount = tracks.size,
                isLoading = false,
            )
        }
    }

    private fun observeSyncState() {
        viewModelScope.launch {
            WorkManager.getInstance(context)
                .getWorkInfosForUniqueWorkFlow(DailySyncWorker.UNIQUE_WORK_NAME)
                .collect { infos ->
                    val state = infos.firstOrNull()?.state?.let(::describeState) ?: "Pas encore planifiée"
                    _uiState.value = _uiState.value.copy(lastSyncState = state)
                }
        }
    }

    private fun describeState(state: WorkInfo.State): String = when (state) {
        WorkInfo.State.ENQUEUED -> "En attente (prochaine synchro planifiée)"
        WorkInfo.State.RUNNING -> "Synchronisation en cours…"
        WorkInfo.State.SUCCEEDED -> "Dernière synchronisation réussie"
        WorkInfo.State.FAILED -> "Dernière synchronisation échouée"
        WorkInfo.State.BLOCKED -> "Bloquée (en attente de connexion réseau)"
        WorkInfo.State.CANCELLED -> "Annulée"
    }
}
