package com.yttrendpulse.app.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.repository.AuthRepository
import com.yttrendpulse.app.data.repository.AuthUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val user: AuthUser? = null,
    val isCheckingSession: Boolean = true, // vrai le temps de savoir si une session existe déjà
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
)

/**
 * Gère l'état d'authentification global de l'app (vrai compte, email/mot de
 * passe). [AppRoot] observe [uiState].user pour savoir s'il faut afficher
 * l'écran de connexion ou l'app principale.
 */
class AuthViewModel(
    private val authRepository: AuthRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.value = _uiState.value.copy(user = user, isCheckingSession = false)
            }
        }
    }

    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Email et mot de passe requis.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSubmitting = true, errorMessage = null)
            authRepository.signIn(email, password)
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isSubmitting = false,
                        errorMessage = e.message ?: "Connexion impossible.",
                    )
                }
            // En cas de succès, isSubmitting repasse à false via le collect currentUser ci-dessus
            // n'étant pas garanti immédiat, on le force aussi ici :
            _uiState.value = _uiState.value.copy(isSubmitting = false)
        }
    }

    fun signUp(email: String, password: String) {
        if (email.isBlank() || password.length < 6) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Email requis, mot de passe d'au moins 6 caractères.",
            )
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSubmitting = true, errorMessage = null)
            authRepository.signUp(email, password)
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isSubmitting = false,
                        errorMessage = e.message ?: "Inscription impossible.",
                    )
                }
            _uiState.value = _uiState.value.copy(isSubmitting = false)
        }
    }

    fun signOut() {
        authRepository.signOut()
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
