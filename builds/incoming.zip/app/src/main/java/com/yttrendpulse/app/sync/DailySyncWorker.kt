package com.yttrendpulse.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.yttrendpulse.app.data.CurrentUser
import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.remote.YouTubeApiService
import com.yttrendpulse.app.data.remote.YouTubeParsing
import com.yttrendpulse.app.data.repository.ArtistRepository
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.domain.NotificationRules
import com.yttrendpulse.app.notifications.NotificationHelper
import kotlinx.coroutines.flow.first
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/**
 * Exécute la synchronisation quotidienne décrite en 1.5 et 1.9 :
 * 1. Pour chaque artiste suivi, récupère ses vidéos publiées depuis moins de
 *    [RECENT_WINDOW_DAYS] jours et crée les morceaux manquants en base.
 * 2. Pour tous les morceaux actifs, récupère les statistiques YouTube à jour,
 *    ajoute une entrée d'historique, recalcule le Viral Score (via
 *    [TrackRepository.recomputeAndSaveScore], qui utilise ViralScoreEngine),
 *    et déclenche une notification locale si un seuil notable est franchi
 *    (voir [NotificationRules]).
 *
 * Pour un suivi plus fréquent que le rythme quotidien sur un morceau précis,
 * voir [EnhancedTrackWorker] (Graphique+, 2.12).
 *
 * TODO (hors scope de cette étape) : détection "entrée dans le Top 3 du
 * Podium" (demande de mémoriser le classement précédent, pas encore fait),
 * sauvegarde du podium pré-calculé, gestion fine du quota API (3.x).
 */
class DailySyncWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params), KoinComponent {

    private val artistRepository: ArtistRepository by inject()
    private val trackRepository: TrackRepository by inject()
    private val youTubeApiService: YouTubeApiService by inject()

    companion object {
        const val UNIQUE_WORK_NAME = "daily_sync_work"
        private const val RECENT_WINDOW_DAYS = 25L // cf. 1.9 : morceaux suivis < 25 jours
        private const val STATS_BATCH_SIZE = 50 // limite raisonnable par appel à /videos
    }

    override suspend fun doWork(): Result {
        if (CurrentUser.uid == null) {
            // Personne n'est connecté : rien à synchroniser, on évite de boucler en retry.
            return Result.success()
        }
        return try {
            syncNewTracksFromArtists()
            refreshAllActiveTracksStats()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    /** Étape 1 : détecte et crée les nouveaux morceaux de chaque artiste suivi. */
    private suspend fun syncNewTracksFromArtists() {
        val artists = artistRepository.observeArtists().first()
        if (artists.isEmpty()) return

        val existingVideoIds = trackRepository.getAllActiveTracks()
            .getOrDefault(emptyList())
            .map { it.youtubeVideoId }
            .toSet()

        val publishedAfter = YouTubeParsing.publishedAfterDaysAgo(RECENT_WINDOW_DAYS)

        for (artist in artists) {
            if (artist.youtubeChannelId.isBlank()) continue

            val searchResult = runCatching {
                youTubeApiService.searchVideos(
                    channelId = artist.youtubeChannelId,
                    order = "date",
                    publishedAfter = publishedAfter,
                    maxResults = 15,
                )
            }.getOrNull() ?: continue

            val newVideoIds = searchResult.items
                .mapNotNull { it.id.videoId }
                .filterNot { it in existingVideoIds }

            if (newVideoIds.isEmpty()) continue

            val statsResponse = runCatching {
                youTubeApiService.getVideoStatistics(videoIds = newVideoIds.joinToString(","))
            }.getOrNull() ?: continue

            statsResponse.items.forEach { item ->
                val track = Track(
                    youtubeVideoId = item.id,
                    title = item.snippet.title,
                    artistId = artist.id,
                    artistName = artist.name,
                    thumbnailUrl = item.snippet.thumbnails.high?.url ?: "",
                    publishedAt = YouTubeParsing.parsePublishedAt(item.snippet.publishedAt),
                    durationSeconds = YouTubeParsing.parseDurationSeconds(item.contentDetails.duration),
                    viewCount = item.statistics.viewCount?.toLongOrNull() ?: 0L,
                    likeCount = item.statistics.likeCount?.toLongOrNull() ?: 0L,
                    commentCount = item.statistics.commentCount?.toLongOrNull() ?: 0L,
                )
                trackRepository.upsertTrack(track)
            }
        }
    }

    /** Étape 2 : rafraîchit les stats de tous les morceaux actifs, historise, recalcule le score. */
    private suspend fun refreshAllActiveTracksStats() {
        val tracks = trackRepository.getAllActiveTracks().getOrDefault(emptyList())
        if (tracks.isEmpty()) return

        tracks.chunked(STATS_BATCH_SIZE).forEach { chunk ->
            val ids = chunk.joinToString(",") { it.youtubeVideoId }
            val response = runCatching {
                youTubeApiService.getVideoStatistics(videoIds = ids)
            }.getOrNull() ?: return@forEach

            val statsByVideoId = response.items.associateBy { it.id }

            chunk.forEach { track ->
                val item = statsByVideoId[track.youtubeVideoId] ?: return@forEach

                val updated = track.copy(
                    viewCount = item.statistics.viewCount?.toLongOrNull() ?: track.viewCount,
                    likeCount = item.statistics.likeCount?.toLongOrNull() ?: track.likeCount,
                    commentCount = item.statistics.commentCount?.toLongOrNull() ?: track.commentCount,
                )

                trackRepository.addHistoryEntry(
                    track.id,
                    HistoryEntry(
                        trackId = track.id,
                        date = System.currentTimeMillis(),
                        viewCount = updated.viewCount,
                        likeCount = updated.likeCount,
                        commentCount = updated.commentCount,
                    ),
                )

                trackRepository.upsertTrack(updated)

                val newScore = trackRepository.recomputeAndSaveScore(updated).getOrNull()
                if (newScore != null) {
                    notifyIfNeeded(before = track, after = updated, newScore = newScore)
                }
            }
        }
    }

    /**
     * Compare l'état avant/après cette synchro et déclenche une notification
     * locale (voir [NotificationHelper]) si un seuil notable est franchi.
     */
    private fun notifyIfNeeded(before: Track, after: Track, newScore: Double) {
        val scoreJump = newScore - before.currentScore
        if (scoreJump >= NotificationRules.SCORE_JUMP_THRESHOLD) {
            NotificationHelper.notify(
                context = applicationContext,
                trackId = before.id,
                title = "📈 ${after.title} explose !",
                text = "+${scoreJump.toInt()} points de score aujourd'hui",
            )
        }

        NotificationRules.crossedMilestone(before.viewCount, after.viewCount)?.let { milestone ->
            NotificationHelper.notify(
                context = applicationContext,
                trackId = before.id,
                title = "🎉 ${after.title} franchit un cap !",
                text = "${NotificationRules.formatMilestone(milestone)} de vues atteintes",
            )
        }
    }
}
