package com.yttrendpulse.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yttrendpulse.app.ui.theme.CardSurfaceElevated
import com.yttrendpulse.app.ui.theme.TextGreyLight
import com.yttrendpulse.app.ui.theme.TextWhite
import com.yttrendpulse.app.ui.theme.YouTubeRed

/**
 * Toggle segmenté en forme de "pill" (ex: Top 20 / Top 100, Suivis / Découvrir).
 * L'option sélectionnée est en rouge YouTube plein, les autres en gris foncé.
 */
@Composable
fun <T> FilterPillRow(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .background(CardSurfaceElevated, RoundedCornerShape(50))
            .padding(4.dp),
    ) {
        options.forEach { (value, label) ->
            val isSelected = value == selected
            Row(
                modifier = Modifier
                    .clickable { onSelect(value) }
                    .background(
                        if (isSelected) YouTubeRed else androidx.compose.ui.graphics.Color.Transparent,
                        RoundedCornerShape(50),
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    label,
                    color = if (isSelected) TextWhite else TextGreyLight,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}
