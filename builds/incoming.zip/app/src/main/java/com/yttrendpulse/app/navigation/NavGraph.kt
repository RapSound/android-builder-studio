package com.yttrendpulse.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.yttrendpulse.app.ui.screens.analyse.AnalyseScreen
import com.yttrendpulse.app.ui.screens.artistes.ArtistesScreen
import com.yttrendpulse.app.ui.screens.auditlog.AuditLogScreen
import com.yttrendpulse.app.ui.screens.charts.ChartsScreen
import com.yttrendpulse.app.ui.screens.figes.FigesScreen
import com.yttrendpulse.app.ui.screens.health.HealthScreen
import com.yttrendpulse.app.ui.screens.parametres.ParametresScreen
import com.yttrendpulse.app.ui.screens.podium.PodiumScreen
import com.yttrendpulse.app.ui.screens.trackdetail.TrackDetailScreen

private const val TRACK_ID_ARG = "trackId"
private const val TRACK_DETAIL_ROUTE = "track"
private const val AUDIT_LOG_ROUTE = "audit_log"
private const val HEALTH_ROUTE = "health"

/** Construit la route vers la page de détail d'un morceau (2.10). */
fun trackDetailRoute(trackId: String) = "$TRACK_DETAIL_ROUTE/$trackId"

@Composable
fun YTNavGraph(
    navController: NavHostController,
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Podium.route, // écran principal (2.5)
        modifier = modifier,
    ) {
        composable(Screen.Podium.route) {
            PodiumScreen(onTrackClick = { trackId -> navController.navigate(trackDetailRoute(trackId)) })
        }
        composable(Screen.Figes.route) {
            FigesScreen(onTrackClick = { trackId -> navController.navigate(trackDetailRoute(trackId)) })
        }
        composable(Screen.Analyse.route) {
            AnalyseScreen(onTrackClick = { trackId -> navController.navigate(trackDetailRoute(trackId)) })
        }
        composable(Screen.Charts.route) {
            ChartsScreen(onTrackClick = { trackId -> navController.navigate(trackDetailRoute(trackId)) })
        }
        composable(Screen.Artistes.route) { ArtistesScreen() }
        composable(Screen.Parametres.route) {
            ParametresScreen(
                onNavigateToAuditLog = { navController.navigate(AUDIT_LOG_ROUTE) },
                onNavigateToHealth = { navController.navigate(HEALTH_ROUTE) },
            )
        }

        composable(
            route = "$TRACK_DETAIL_ROUTE/{$TRACK_ID_ARG}",
            arguments = listOf(navArgument(TRACK_ID_ARG) { type = NavType.StringType }),
        ) { backStackEntry ->
            val trackId = backStackEntry.arguments?.getString(TRACK_ID_ARG).orEmpty()
            TrackDetailScreen(trackId = trackId, onBack = { navController.popBackStack() })
        }

        composable(AUDIT_LOG_ROUTE) {
            AuditLogScreen(onBack = { navController.popBackStack() })
        }
        composable(HEALTH_ROUTE) {
            HealthScreen(onBack = { navController.popBackStack() })
        }
    }
}
