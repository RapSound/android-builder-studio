package com.yttrendpulse.app.ui.screens.trackdetail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.domain.PredictionEngine
import com.yttrendpulse.app.sync.GraphPlusScheduler
import com.yttrendpulse.app.ui.components.ChartMetric
import com.yttrendpulse.app.ui.components.HistoryLineChart
import com.yttrendpulse.app.ui.components.ScoreBadge
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.components.valueFor
import com.yttrendpulse.app.ui.theme.TextGreyLight
import org.koin.androidx.compose.koinViewModel
import org.koin.core.parameter.parametersOf

private val PREDICTION_HORIZONS = listOf(3, 7, 15, 30)
private val GRAPH_PLUS_INTERVALS = listOf(15, 30, 60) // minutes ; 15 = minimum WorkManager

/**
 * Page de détail d'un morceau (2.10) : miniature HD, infos, actions,
 * puis les 3 graphiques (vues/likes/commentaires) alimentés par l'historique
 * réel, avec prédiction (2.11) calculée à la volée par PredictionEngine et
 * fusionnée dans le graphique (tracé pointillé automatique).
 */
@Composable
fun TrackDetailScreen(
    trackId: String,
    onBack: () -> Unit = {},
    viewModel: TrackDetailViewModel = koinViewModel(parameters = { parametersOf(trackId) }),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            YTTopBar(
                title = uiState.track?.title ?: "Morceau",
                onBack = onBack,
                onRefresh = { viewModel.refresh() },
            )
        },
    ) { padding ->
        val track = uiState.track

        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (track == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Morceau introuvable")
            }
            return@Scaffold
        }

        var selectedMetric by remember { mutableStateOf(ChartMetric.VIEWS) }
        var selectedHorizon by remember { mutableStateOf<Int?>(null) }
        val effectiveHorizon = selectedHorizon ?: uiState.defaultPredictionHorizonDays

        // Recalculée à la volée (pas d'écriture Firestore) dès que l'historique,
        // la métrique ou l'horizon changent.
        val prediction = remember(uiState.history, selectedMetric, effectiveHorizon) {
            PredictionEngine.predict(
                history = uiState.history,
                horizonDays = effectiveHorizon,
            ) { entry -> entry.valueFor(selectedMetric) }
        }

        val chartHistory = remember(uiState.history, prediction, trackId) {
            val predictedEntries = prediction?.points.orEmpty().map { (date, value) ->
                HistoryEntry(
                    trackId = trackId,
                    date = date,
                    viewCount = if (selectedMetric == ChartMetric.VIEWS) value.toLong() else 0L,
                    likeCount = if (selectedMetric == ChartMetric.LIKES) value.toLong() else 0L,
                    commentCount = if (selectedMetric == ChartMetric.COMMENTS) value.toLong() else 0L,
                    isPredicted = true,
                )
            }
            uiState.history + predictedEntries
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                contentDescription = track.title,
                modifier = Modifier.fillMaxWidth().height(200.dp),
            )

            Text(track.title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            Text(track.artistName)

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                StatColumn(label = "Vues", value = track.viewCount.toString())
                StatColumn(label = "Likes", value = track.likeCount.toString())
                StatColumn(label = "Commentaires", value = track.commentCount.toString())
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    ScoreBadge(score = track.currentScore.toInt(), size = 40.dp)
                    Text("Score")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(onClick = { /* TODO: ouvrir l'URL YouTube via un Intent */ }) {
                    Icon(Icons.Filled.OpenInNew, contentDescription = null)
                    Text(" Ouvrir YouTube")
                }
                OutlinedButton(onClick = { viewModel.togglePin() }) {
                    Icon(if (track.isPinned) Icons.Filled.Lock else Icons.Filled.LockOpen, contentDescription = null)
                    Text(if (track.isPinned) " Défiger" else " Figer")
                }
                Button(onClick = { viewModel.refresh() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = null)
                    Text(" Actualiser")
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text("Évolution (${uiState.history.size} entrées)", fontWeight = FontWeight.SemiBold)

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ChartMetric.entries.forEach { metric ->
                    FilterChip(
                        selected = selectedMetric == metric,
                        onClick = { selectedMetric = metric },
                        label = { Text(metric.label) },
                    )
                }
            }

            if (uiState.history.isEmpty()) {
                Text(
                    "Pas encore d'historique : la première synchronisation nocturne (ou un " +
                        "appui sur Actualiser) créera le premier point.",
                )
            } else {
                HistoryLineChart(history = chartHistory, metric = selectedMetric)

                Text("Horizon de prédiction", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    PREDICTION_HORIZONS.forEach { days ->
                        FilterChip(
                            selected = effectiveHorizon == days,
                            onClick = { selectedHorizon = days },
                            label = { Text("$days j") },
                        )
                    }
                }

                if (prediction != null) {
                    Text(
                        "Prédiction fiable à ${prediction.confidencePercent.toInt()} % " +
                            "· modèle ${prediction.model.label} (${PredictionEngine.VERSION})",
                        color = TextGreyLight,
                    )
                } else {
                    Text(
                        "Pas assez d'historique réel pour une prédiction fiable sur cette métrique.",
                        color = TextGreyLight,
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text("Graphique+ (suivi renforcé)", fontWeight = FontWeight.SemiBold)
            Text(
                "Rafraîchit ce morceau plus souvent qu'une fois par jour. Intervalle mini : " +
                    "${GraphPlusScheduler.MIN_INTERVAL_MINUTES} min (limite technique WorkManager).",
                color = TextGreyLight,
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = track.enhancedTrackingIntervalMinutes == null,
                    onClick = { viewModel.setEnhancedTracking(null) },
                    label = { Text("Désactivé") },
                )
                GRAPH_PLUS_INTERVALS.forEach { minutes ->
                    FilterChip(
                        selected = track.enhancedTrackingIntervalMinutes == minutes,
                        onClick = { viewModel.setEnhancedTracking(minutes) },
                        label = { Text("$minutes min") },
                    )
                }
            }
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold)
        Text(label)
    }
}
