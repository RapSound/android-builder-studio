package com.yttrendpulse.app.data.repository

import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.data.model.Track
import kotlinx.coroutines.flow.Flow

/**
 * Contrat d'accès aux données Morceaux + historique (Firestore).
 * TODO: implémenter FirestoreTrackRepository.
 */
interface TrackRepository {
    fun observePodium(): Flow<List<Track>>          // classement par score (2.5)
    fun observePinnedTracks(): Flow<List<Track>>     // morceaux "Figés" (2.6)
    fun observeTrack(trackId: String): Flow<Track?>  // page de détail d'un morceau (2.10)
    fun observeHistory(trackId: String): Flow<List<HistoryEntry>>

    suspend fun searchTrack(title: String, artist: String?): Result<List<Track>> // menu Analyse (2.7)
    suspend fun togglePin(trackId: String): Result<Unit>
    suspend fun refreshTrack(trackId: String): Result<Unit>
    suspend fun setEnhancedTracking(trackId: String, intervalMinutes: Int?): Result<Unit> // Graphique+ (2.12)

    // --- Utilisés par DailySyncWorker (1.5, 1.9) ---
    suspend fun getAllActiveTracks(): Result<List<Track>>
    suspend fun upsertTrack(track: Track): Result<Track> // crée si track.id vide, sinon écrase
    suspend fun addHistoryEntry(trackId: String, entry: HistoryEntry): Result<Unit>
    suspend fun recomputeAndSaveScore(track: Track): Result<Double>
}
