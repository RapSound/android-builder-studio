package com.yttrendpulse.app.ui.screens.parametres

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.yttrendpulse.app.data.local.SettingsRepository
import com.yttrendpulse.app.data.repository.AuditLogRepository
import com.yttrendpulse.app.sync.DailySyncWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ParametresUiState(
    val recentThresholdDays: Int = SettingsRepository.DEFAULT_RECENT_THRESHOLD_DAYS,
    val defaultPredictionHorizonDays: Int = SettingsRepository.DEFAULT_PREDICTION_HORIZON_DAYS,
    val isSyncing: Boolean = false,
    val message: String? = null,
)

/**
 * Alimente le menu Paramètres (1.8) : seuil "récent" (contour 🔥, 2.5/2.6),
 * horizon de prédiction par défaut (2.11), et synchronisation manuelle
 * (déclenche DailySyncWorker en tâche unique via WorkManager).
 */
class ParametresViewModel(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val auditLogRepository: AuditLogRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ParametresUiState())
    val uiState: StateFlow<ParametresUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                settingsRepository.recentThresholdDays,
                settingsRepository.defaultPredictionHorizonDays,
            ) { threshold, horizon ->
                threshold to horizon
            }.collect { (threshold, horizon) ->
                _uiState.value = _uiState.value.copy(
                    recentThresholdDays = threshold,
                    defaultPredictionHorizonDays = horizon,
                )
            }
        }
    }

    fun setRecentThresholdDays(days: Int) {
        viewModelScope.launch { settingsRepository.setRecentThresholdDays(days) }
    }

    fun setDefaultPredictionHorizonDays(days: Int) {
        viewModelScope.launch { settingsRepository.setDefaultPredictionHorizonDays(days) }
    }

    /**
     * Lance une synchronisation immédiate (utile pour tester sans attendre minuit).
     * TODO: suivre l'état réel du WorkInfo plutôt qu'un délai fixe pour le spinner.
     */
    fun triggerManualSync() {
        _uiState.value = _uiState.value.copy(isSyncing = true, message = "Synchronisation lancée…")

        WorkManager.getInstance(context).enqueueUniqueWork(
            "manual_sync_work",
            ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<DailySyncWorker>().build(),
        )

        viewModelScope.launch {
            auditLogRepository.log("MANUAL_SYNC", "")
            delay(1500)
            _uiState.value = _uiState.value.copy(isSyncing = false)
        }
    }

    fun clearMessage() {
        _uiState.value = _uiState.value.copy(message = null)
    }
}
