package com.yttrendpulse.app.domain

import com.yttrendpulse.app.data.model.HistoryEntry
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Moteur de prédiction (2.11), versionné (recommandation 12.9 §5).
 *
 * v2 — adaptatif par morceau : au lieu d'imposer une seule forme de courbe
 * à tous les morceaux (v1 = régression linéaire unique), ce moteur teste
 * 3 modèles candidats sur l'historique réel de CE morceau précis et choisit
 * celui qui colle le mieux (meilleur R² en comparant sur l'échelle réelle,
 * pas dans un espace transformé) :
 *
 *  - LINEAR              : croissance stable / régulière
 *  - EXPONENTIAL_DAMPED   : montée virale rapide. Amortie progressivement
 *    sur l'horizon de prédiction (aucune vidéo ne double indéfiniment tous
 *    les jours — sans amortissement, un ajustement exponentiel sur 30 jours
 *    donnerait des chiffres absurdes).
 *  - LOGARITHMIC          : plateau / ralentissement après un pic.
 *
 * ⚠️ Reste une approche heuristique et transparente (régressions classiques),
 * pas un modèle de machine learning entraîné — mais réellement adaptée à la
 * forme de CHAQUE morceau plutôt qu'une formule unique appliquée à tous.
 */
object PredictionEngine {
    const val VERSION = "2.0-adaptive"
    private const val MIN_POINTS = 4
    private const val LOOKBACK_POINTS = 14
    private const val DAMPING_RATE = 0.06 // amortissement quotidien du taux de croissance exponentiel

    enum class ModelType(val label: String) {
        LINEAR("linéaire"),
        EXPONENTIAL_DAMPED("exponentiel amorti"),
        LOGARITHMIC("plateau"),
    }

    data class PredictedSeries(
        val points: List<Pair<Long, Double>>,
        val confidencePercent: Double,
        val model: ModelType,
    )

    fun predict(
        history: List<HistoryEntry>,
        horizonDays: Int,
        valueSelector: (HistoryEntry) -> Long,
    ): PredictedSeries? {
        val real = history.filterNot { it.isPredicted }.sortedBy { it.date }
        val recent = real.takeLast(LOOKBACK_POINTS)
        if (recent.size < MIN_POINTS || horizonDays <= 0) return null

        val t0 = recent.first().date
        val dayMillis = 1000.0 * 60 * 60 * 24
        val xs = recent.map { (it.date - t0) / dayMillis }
        val ys = recent.map { valueSelector(it).toDouble() }

        // On ajuste les 3 modèles candidats et on garde celui dont le R²
        // (calculé sur l'échelle réelle, donc comparable entre modèles) est le plus haut.
        val best = listOfNotNull(fitLinear(xs, ys), fitExponential(xs, ys), fitLogarithmic(xs, ys))
            .maxByOrNull { it.rSquared }
            ?: return null

        val lastX = xs.last()
        val lastDate = recent.last().date

        val points = (1..horizonDays).map { dayOffset ->
            val x = lastX + dayOffset
            val predictedY = max(0.0, best.predict(x, dayOffset))
            val date = lastDate + (dayOffset * dayMillis).toLong()
            date to predictedY
        }

        // Confiance = qualité de l'ajustement (R²), légèrement pénalisée si peu de points réels.
        val dataQuality = (recent.size.toDouble() / LOOKBACK_POINTS).coerceIn(0.5, 1.0)
        val confidence = (best.rSquared * 100 * dataQuality).coerceIn(10.0, 95.0)

        return PredictedSeries(points, confidence, best.type)
    }

    // --- Modèles candidats ---

    private class FitResult(
        val type: ModelType,
        val rSquared: Double,
        val predict: (x: Double, dayOffset: Int) -> Double,
    )

    private fun fitLinear(xs: List<Double>, ys: List<Double>): FitResult? {
        val (slope, intercept) = leastSquaresParams(xs, ys) ?: return null
        val predictFn: (Double, Int) -> Double = { x, _ -> intercept + slope * x }
        return FitResult(ModelType.LINEAR, computeR2(xs, ys, predictFn), predictFn)
    }

    /** y = a·e^(b·x), ajusté par régression linéaire sur ln(y), puis amorti dans le futur. */
    private fun fitExponential(xs: List<Double>, ys: List<Double>): FitResult? {
        if (ys.any { it <= 0.0 }) return null // ln(0) indéfini : morceau sans vues, modèle non pertinent
        val (slope, lnIntercept) = leastSquaresParams(xs, ys.map { ln(it) }) ?: return null
        val a = exp(lnIntercept)
        val predictFn: (Double, Int) -> Double = { x, dayOffset ->
            // Amortissement progressif du taux de croissance à mesure qu'on projette
            // loin dans le futur : évite l'explosion irréaliste d'un ajustement exponentiel.
            val dampedSlope = slope * exp(-DAMPING_RATE * dayOffset)
            a * exp(dampedSlope * x)
        }
        return FitResult(ModelType.EXPONENTIAL_DAMPED, computeR2(xs, ys, predictFn), predictFn)
    }

    /** y = a + b·ln(x+1) : modélise un ralentissement / plateau après un pic. */
    private fun fitLogarithmic(xs: List<Double>, ys: List<Double>): FitResult? {
        val transformedXs = xs.map { ln(it + 1.0) }
        val (slope, intercept) = leastSquaresParams(transformedXs, ys) ?: return null
        val predictFn: (Double, Int) -> Double = { x, _ -> intercept + slope * ln(x + 1.0) }
        return FitResult(ModelType.LOGARITHMIC, computeR2(xs, ys, predictFn), predictFn)
    }

    /** Régression linéaire (moindres carrés) : retourne (pente, ordonnée à l'origine). */
    private fun leastSquaresParams(xs: List<Double>, ys: List<Double>): Pair<Double, Double>? {
        val n = xs.size
        if (n < 2) return null

        val meanX = xs.average()
        val meanY = ys.average()

        var numerator = 0.0
        var denominator = 0.0
        for (i in 0 until n) {
            numerator += (xs[i] - meanX) * (ys[i] - meanY)
            denominator += (xs[i] - meanX) * (xs[i] - meanX)
        }
        if (denominator == 0.0) return null

        val slope = numerator / denominator
        val intercept = meanY - slope * meanX
        return slope to intercept
    }

    /** R² calculé sur l'échelle réelle (pas dans un espace transformé) : comparable entre modèles. */
    private fun computeR2(xs: List<Double>, ys: List<Double>, predictFn: (Double, Int) -> Double): Double {
        val meanY = ys.average()
        var ssTot = 0.0
        var ssRes = 0.0
        for (i in xs.indices) {
            val predicted = predictFn(xs[i], 0) // dayOffset=0 : pas d'amortissement sur les données réelles
            ssRes += (ys[i] - predicted) * (ys[i] - predicted)
            ssTot += (ys[i] - meanY) * (ys[i] - meanY)
        }
        return if (ssTot == 0.0) 1.0 else max(0.0, min(1.0, 1 - ssRes / ssTot))
    }
}
