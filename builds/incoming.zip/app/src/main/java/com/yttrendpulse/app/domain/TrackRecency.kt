package com.yttrendpulse.app.domain

import com.yttrendpulse.app.data.model.Track

/**
 * Détermine si un morceau est "récent" (contour 🔥 sur Podium 2.5 et Figés 2.6),
 * selon le seuil configurable par l'utilisateur (Paramètres, défaut 5 jours).
 */
object TrackRecency {
    fun isRecent(track: Track, thresholdDays: Int): Boolean {
        if (track.publishedAt <= 0L) return false
        val ageDays = (System.currentTimeMillis() - track.publishedAt) / (1000.0 * 60 * 60 * 24)
        return ageDays < thresholdDays
    }
}
