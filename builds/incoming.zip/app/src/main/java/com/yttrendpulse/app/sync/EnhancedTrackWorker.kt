package com.yttrendpulse.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.yttrendpulse.app.data.CurrentUser
import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.data.remote.YouTubeApiService
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.domain.NotificationRules
import com.yttrendpulse.app.notifications.NotificationHelper
import kotlinx.coroutines.flow.first
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/**
 * Fonction Graphique+ (2.12) : suivi renforcé d'UN morceau précis, à un
 * intervalle plus rapproché que la synchronisation quotidienne (planifié
 * par [GraphPlusScheduler]). Même logique de notification que
 * [DailySyncWorker] (via [NotificationRules]), appliquée à un seul morceau.
 */
class EnhancedTrackWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params), KoinComponent {

    private val trackRepository: TrackRepository by inject()
    private val youTubeApiService: YouTubeApiService by inject()

    companion object {
        const val KEY_TRACK_ID = "track_id"
        fun uniqueWorkName(trackId: String) = "enhanced_track_$trackId"
    }

    override suspend fun doWork(): Result {
        val trackId = inputData.getString(KEY_TRACK_ID) ?: return Result.failure()
        if (CurrentUser.uid == null) return Result.success() // personne connecté, rien à faire
        return try {
            refreshOne(trackId)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private suspend fun refreshOne(trackId: String) {
        val track = trackRepository.observeTrack(trackId).first() ?: return

        // Sécurité : si Graphique+ a été désactivé entre-temps (ex: WorkManager
        // relance une tâche en attente avant que l'annulation ait pris effet).
        if (track.enhancedTrackingIntervalMinutes == null) return

        val response = runCatching {
            youTubeApiService.getVideoStatistics(videoIds = track.youtubeVideoId)
        }.getOrNull() ?: return
        val item = response.items.firstOrNull() ?: return

        val updated = track.copy(
            viewCount = item.statistics.viewCount?.toLongOrNull() ?: track.viewCount,
            likeCount = item.statistics.likeCount?.toLongOrNull() ?: track.likeCount,
            commentCount = item.statistics.commentCount?.toLongOrNull() ?: track.commentCount,
        )

        trackRepository.addHistoryEntry(
            trackId,
            HistoryEntry(
                trackId = trackId,
                date = System.currentTimeMillis(),
                viewCount = updated.viewCount,
                likeCount = updated.likeCount,
                commentCount = updated.commentCount,
            ),
        )
        trackRepository.upsertTrack(updated)

        val newScore = trackRepository.recomputeAndSaveScore(updated).getOrNull() ?: return

        val scoreJump = newScore - track.currentScore
        if (scoreJump >= NotificationRules.SCORE_JUMP_THRESHOLD) {
            NotificationHelper.notify(
                context = applicationContext,
                trackId = trackId,
                title = "📈 ${updated.title} explose !",
                text = "+${scoreJump.toInt()} points de score",
            )
        }

        NotificationRules.crossedMilestone(track.viewCount, updated.viewCount)?.let { milestone ->
            NotificationHelper.notify(
                context = applicationContext,
                trackId = trackId,
                title = "🎉 ${updated.title} franchit un cap !",
                text = "${NotificationRules.formatMilestone(milestone)} de vues atteintes",
            )
        }
    }
}
