package com.yttrendpulse.app.data.repository.impl

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.yttrendpulse.app.data.CurrentUser
import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.model.TrackStatus
import com.yttrendpulse.app.data.remote.YouTubeApiService
import com.yttrendpulse.app.data.remote.YouTubeParsing
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.domain.ViralScoreEngine
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Implémentation Firestore de [TrackRepository], scopée par compte :
 *  - "users/{uid}/tracks"                 : un document par morceau suivi (voir [Track])
 *  - "users/{uid}/tracks/{id}/history"    : sous-collection d'entrées quotidiennes (voir [HistoryEntry])
 *
 * Identifiants Firestore = id métier (recommandation 12.9 §4 : identifiants uniques et stables).
 */
class FirestoreTrackRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val youTubeApiService: YouTubeApiService,
) : TrackRepository {

    private val tracksCollection
        get() = firestore.collection("users").document(CurrentUser.requireUid()).collection("tracks")

    private fun historyCollection(trackId: String) =
        tracksCollection.document(trackId).collection("history")

    override fun observePodium(): Flow<List<Track>> = callbackFlow {
        if (CurrentUser.uid == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        val registration = tracksCollection
            .orderBy("currentScore", Query.Direction.DESCENDING)
            .limit(10) // Top 10 affiché sur le Podium (2.5)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val tracks = snapshot?.documents?.mapNotNull { it.toObject(Track::class.java) } ?: emptyList()
                trySend(tracks)
            }
        awaitClose { registration.remove() }
    }

    override fun observePinnedTracks(): Flow<List<Track>> = callbackFlow {
        if (CurrentUser.uid == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        val registration = tracksCollection
            .whereEqualTo("isPinned", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val tracks = snapshot?.documents?.mapNotNull { it.toObject(Track::class.java) } ?: emptyList()
                trySend(tracks)
            }
        awaitClose { registration.remove() }
    }

    override fun observeTrack(trackId: String): Flow<Track?> = callbackFlow {
        if (CurrentUser.uid == null) {
            trySend(null)
            awaitClose { }
            return@callbackFlow
        }
        val registration = tracksCollection.document(trackId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.toObject(Track::class.java))
            }
        awaitClose { registration.remove() }
    }

    override fun observeHistory(trackId: String): Flow<List<HistoryEntry>> = callbackFlow {
        if (CurrentUser.uid == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        val registration = historyCollection(trackId)
            .orderBy("date", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val entries = snapshot?.documents?.mapNotNull { it.toObject(HistoryEntry::class.java) } ?: emptyList()
                trySend(entries)
            }
        awaitClose { registration.remove() }
    }

    override suspend fun searchTrack(title: String, artist: String?): Result<List<Track>> = runCatching {
        // Recherche simple sur les morceaux déjà en base (préfixe de titre).
        // TODO: brancher aussi la recherche live via YouTubeApiService.searchVideos
        // pour trouver des morceaux qui ne sont pas encore dans Firestore (2.7).
        var query: Query = tracksCollection
            .orderBy("title")
            .startAt(title)
            .endAt(title + "\uf8ff")

        if (!artist.isNullOrBlank()) {
            query = query.whereEqualTo("artistName", artist)
        }

        query.get().await().documents.mapNotNull { it.toObject(Track::class.java) }
    }

    override suspend fun togglePin(trackId: String): Result<Unit> = runCatching {
        val doc = tracksCollection.document(trackId).get().await()
        val current = doc.getBoolean("isPinned") ?: false
        tracksCollection.document(trackId).update("isPinned", !current).await()
    }

    override suspend fun refreshTrack(trackId: String): Result<Unit> = runCatching {
        val doc = tracksCollection.document(trackId).get().await()
        val track = doc.toObject(Track::class.java) ?: return@runCatching

        val response = youTubeApiService.getVideoStatistics(videoIds = track.youtubeVideoId)
        val item = response.items.firstOrNull() ?: return@runCatching

        val updated = track.copy(
            viewCount = item.statistics.viewCount?.toLongOrNull() ?: track.viewCount,
            likeCount = item.statistics.likeCount?.toLongOrNull() ?: track.likeCount,
            commentCount = item.statistics.commentCount?.toLongOrNull() ?: track.commentCount,
        )

        addHistoryEntry(
            trackId,
            HistoryEntry(
                trackId = trackId,
                date = System.currentTimeMillis(),
                viewCount = updated.viewCount,
                likeCount = updated.likeCount,
                commentCount = updated.commentCount,
            ),
        )

        tracksCollection.document(trackId).set(updated).await()
        recomputeAndSaveScore(updated)
        Unit
    }

    override suspend fun setEnhancedTracking(trackId: String, intervalMinutes: Int?): Result<Unit> = runCatching {
        tracksCollection.document(trackId)
            .update("enhancedTrackingIntervalMinutes", intervalMinutes)
            .await()
        // TODO: planifier/annuler le WorkManager périodique dédié à ce morceau (Graphique+, 2.12).
    }

    override suspend fun getAllActiveTracks(): Result<List<Track>> = runCatching {
        tracksCollection.whereEqualTo("status", TrackStatus.ACTIVE.name).get().await()
            .documents.mapNotNull { it.toObject(Track::class.java) }
    }

    override suspend fun upsertTrack(track: Track): Result<Track> = runCatching {
        val docRef = if (track.id.isBlank()) tracksCollection.document() else tracksCollection.document(track.id)
        val finalTrack = if (track.id.isBlank()) track.copy(id = docRef.id) else track
        docRef.set(finalTrack).await()
        finalTrack
    }

    override suspend fun addHistoryEntry(trackId: String, entry: HistoryEntry): Result<Unit> = runCatching {
        val docRef = historyCollection(trackId).document()
        docRef.set(entry.copy(id = docRef.id, trackId = trackId)).await()
    }

    /**
     * Calcule et persiste un nouveau score pour [track], à partir de son historique complet.
     * Utilisé par DailySyncWorker et par refreshTrack().
     */
    override suspend fun recomputeAndSaveScore(track: Track): Result<Double> = runCatching {
        val history = historyCollection(track.id)
            .orderBy("date", Query.Direction.ASCENDING)
            .get().await()
            .documents.mapNotNull { it.toObject(HistoryEntry::class.java) }

        val newScore = ViralScoreEngine.computeScore(track, history)

        tracksCollection.document(track.id).update(
            mapOf(
                "previousScore" to track.currentScore,
                "currentScore" to newScore,
                "scoreEngineVersion" to ViralScoreEngine.VERSION,
            ),
        ).await()

        newScore
    }
}
