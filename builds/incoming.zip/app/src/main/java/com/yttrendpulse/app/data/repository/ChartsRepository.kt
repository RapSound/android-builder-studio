package com.yttrendpulse.app.data.repository

import com.yttrendpulse.app.data.model.Track

enum class ChartType { TOP_20_RECENT, TOP_100_LONG_TERME }

/**
 * Contrat d'accès aux charts YouTube Music Rap Français (2.8).
 * TODO: implémenter le scraping/l'appel réel + ajout automatique des morceaux manquants.
 */
interface ChartsRepository {
    suspend fun loadChart(type: ChartType): Result<List<Track>>
}
