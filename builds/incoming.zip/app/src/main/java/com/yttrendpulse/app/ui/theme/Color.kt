package com.yttrendpulse.app.ui.theme

import androidx.compose.ui.graphics.Color

// Palette définie dans le cahier des charges, partie 2.2

val BackgroundBlack = Color(0xFF0F0F0F)   // Fond principal : Noir profond
val CardDarkGrey = Color(0xFF1A1A1A)      // Cartes : Gris très foncé
val YouTubeRed = Color(0xFFFF0000)        // Rouge YouTube
val LightRed = Color(0xFFFF4C4C)          // Rouge clair : éléments importants
val TextWhite = Color(0xFFFFFFFF)         // Textes
val TextGreyLight = Color(0xFFB3B3B3)     // Textes secondaires
val PositiveGreen = Color(0xFF2ECC71)     // Progression positive
val WarningOrange = Color(0xFFFF9800)     // Attention
val NegativeRed = Color(0xFFE53935)       // Baisse importante

// Ajouts pour la refonte visuelle (composants réutilisables : badges, podium, pills)
val CardSurfaceElevated = Color(0xFF232323) // léger cran au-dessus de CardDarkGrey (chips, éléments imbriqués)
val GoldMedal = Color(0xFFFFC94A)
val SilverMedal = Color(0xFFD5D8DC)
val BronzeMedal = Color(0xFFCE8946)
