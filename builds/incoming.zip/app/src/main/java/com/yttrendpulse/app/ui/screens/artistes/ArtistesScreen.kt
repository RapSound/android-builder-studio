package com.yttrendpulse.app.ui.screens.artistes

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.yttrendpulse.app.data.model.Artist
import com.yttrendpulse.app.ui.components.FilterPillRow
import com.yttrendpulse.app.ui.components.YTTopBar
import com.yttrendpulse.app.ui.theme.CardDarkGrey
import com.yttrendpulse.app.ui.theme.TextGreyLight
import com.yttrendpulse.app.ui.theme.YouTubeRed
import org.koin.androidx.compose.koinViewModel

private enum class ArtistesTab { SUIVIS, DECOUVRIR }

/**
 * Menu Artistes (2.9) : ajout / suppression / actualisation des artistes suivis.
 * Branché sur ArtistesViewModel -> ArtistRepository (Firestore, temps réel).
 * L'onglet "Découvrir" est un emplacement réservé (pas de fonctionnalité de
 * découverte d'artistes implémentée pour l'instant — honnêtement affiché
 * comme "à venir" plutôt que simulé).
 */
@Composable
fun ArtistesScreen(
    viewModel: ArtistesViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var tab by remember { mutableStateOf(ArtistesTab.SUIVIS) }
    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    if (showAddDialog) {
        AddArtistDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, channelId ->
                viewModel.addArtist(name, channelId)
                showAddDialog = false
            },
        )
    }

    Scaffold(
        topBar = { YTTopBar(title = "🎤 Artistes") },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = YouTubeRed,
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Ajouter un artiste")
            }
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            FilterPillRow(
                options = listOf(
                    ArtistesTab.SUIVIS to "Suivis (${uiState.artists.size})",
                    ArtistesTab.DECOUVRIR to "Découvrir",
                ),
                selected = tab,
                onSelect = { tab = it },
            )

            Spacer(modifier = Modifier.padding(top = 12.dp))

            when {
                tab == ArtistesTab.DECOUVRIR -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Découverte d'artistes à venir", color = TextGreyLight)
                    }
                }
                uiState.isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                uiState.artists.isEmpty() -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Aucun artiste suivi pour le moment", color = TextGreyLight)
                    }
                }
                else -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(items = uiState.artists, key = { it.id }) { artist ->
                            ArtistRow(
                                artist = artist,
                                onDelete = { viewModel.removeArtist(artist.id) },
                                onRefresh = { viewModel.refreshArtist(artist.id) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddArtistDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, channelId: String) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var channelId by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajouter un artiste") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nom de l'artiste") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.padding(top = 8.dp))
                OutlinedTextField(
                    value = channelId,
                    onValueChange = { channelId = it },
                    label = { Text("ID de chaîne YouTube") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name, channelId) }) { Text("Ajouter") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        },
    )
}

@Composable
private fun ArtistRow(
    artist: Artist,
    onDelete: () -> Unit,
    onRefresh: () -> Unit,
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardDarkGrey),
        shape = RoundedCornerShape(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (artist.channelLogoUrl.isNotBlank()) {
                AsyncImage(
                    model = artist.channelLogoUrl,
                    contentDescription = artist.name,
                    modifier = Modifier.size(52.dp).clip(CircleShape),
                )
            } else {
                Box(
                    modifier = Modifier.size(52.dp).clip(CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(artist.name, fontWeight = FontWeight.SemiBold)
                Text(
                    "${artist.recentTracksCount} morceau(x) récent(s) suivi(s)",
                    color = TextGreyLight,
                )
            }

            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Options")
                }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Actualiser") },
                        leadingIcon = { Icon(Icons.Filled.Refresh, contentDescription = null) },
                        onClick = { showMenu = false; onRefresh() },
                    )
                    DropdownMenuItem(
                        text = { Text("Supprimer") },
                        leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                        onClick = { showMenu = false; onDelete() },
                    )
                }
            }
        }
    }
}
