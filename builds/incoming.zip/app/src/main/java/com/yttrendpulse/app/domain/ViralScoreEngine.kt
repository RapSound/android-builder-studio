package com.yttrendpulse.app.domain

import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.data.model.Track
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Moteur de calcul du "Viral Score" (score intelligent sur 100).
 *
 * Le score combine :
 *  - le volume brut (vues/likes/commentaires, pondérés et compressés en log
 *    pour éviter qu'une grosse tête n'écrase tout) ;
 *  - la vitesse de progression récente (delta vues/likes/commentaires sur les
 *    dernières entrées d'historique disponibles) ;
 *  - un bonus de fraîcheur pour les morceaux récents, qui favorise la
 *    détection précoce de tendance (1.1 : "avant qu'elles ne deviennent populaires").
 *
 * Versionné explicitement (recommandation 12.9 §5) : toute évolution de la
 * formule doit incrémenter [VERSION], afin que chaque score en base reste
 * traçable jusqu'à l'algorithme qui l'a produit.
 */
object ViralScoreEngine {

    const val VERSION = "1.0"

    // Poids relatifs des composantes du score (somme = 1.0)
    private const val WEIGHT_VOLUME = 0.45
    private const val WEIGHT_VELOCITY = 0.40
    private const val WEIGHT_FRESHNESS = 0.15

    /**
     * Calcule le score sur 100 pour [track], à partir de son historique récent [history]
     * (trié du plus ancien au plus récent ; peut être vide pour un tout nouveau morceau).
     */
    fun computeScore(track: Track, history: List<HistoryEntry>): Double {
        val volumeScore = computeVolumeScore(track)
        val velocityScore = computeVelocityScore(history)
        val freshnessScore = computeFreshnessScore(track)

        val raw = volumeScore * WEIGHT_VOLUME +
            velocityScore * WEIGHT_VELOCITY +
            freshnessScore * WEIGHT_FRESHNESS

        return raw.coerceIn(0.0, 100.0)
    }

    /** Volume brut compressé en échelle logarithmique (0-100). */
    private fun computeVolumeScore(track: Track): Double {
        // log10(vues) plafonné à 8 (100M vues) -> ramené sur 100
        val viewsComponent = logScale(track.viewCount.toDouble(), maxExponent = 8.0)
        val likesComponent = logScale(track.likeCount.toDouble(), maxExponent = 6.5)
        val commentsComponent = logScale(track.commentCount.toDouble(), maxExponent = 5.0)

        return (viewsComponent * 0.6 + likesComponent * 0.25 + commentsComponent * 0.15) * 100.0
    }

    /** Vitesse de progression récente (0-100), basée sur les dernières entrées d'historique. */
    private fun computeVelocityScore(history: List<HistoryEntry>): Double {
        if (history.size < 2) return 0.0

        val previous = history[history.size - 2]
        val latest = history.last()

        val viewsGrowth = growthRatio(previous.viewCount, latest.viewCount)
        val likesGrowth = growthRatio(previous.likeCount, latest.likeCount)
        val commentsGrowth = growthRatio(previous.commentCount, latest.commentCount)

        val combined = viewsGrowth * 0.6 + likesGrowth * 0.25 + commentsGrowth * 0.15
        // Une croissance de +50% ou plus entre deux mesures = score de vélocité maximal
        return min(combined / 0.5, 1.0) * 100.0
    }

    /** Bonus pour les morceaux très récents (détection précoce, 1.1). */
    private fun computeFreshnessScore(track: Track): Double {
        val ageDays = ageInDays(track.publishedAt)
        if (ageDays >= 25) return 0.0 // au-delà, plus suivi comme "nouveauté" (1.9)
        // Décroissance linéaire : 100 à J0, 0 à J25
        return max(0.0, 100.0 * (1 - ageDays / 25.0))
    }

    private fun logScale(value: Double, maxExponent: Double): Double {
        if (value <= 0.0) return 0.0
        val exponent = ln(value) / ln(10.0)
        return (exponent / maxExponent).coerceIn(0.0, 1.0)
    }

    private fun growthRatio(previous: Long, current: Long): Double {
        if (previous <= 0L) return if (current > 0L) 1.0 else 0.0
        return ((current - previous).toDouble() / previous.toDouble()).coerceIn(0.0, 5.0)
    }

    private fun ageInDays(publishedAtMillis: Long): Double {
        if (publishedAtMillis <= 0L) return Double.MAX_VALUE
        val now = System.currentTimeMillis()
        return ((now - publishedAtMillis).toDouble() / (1000.0 * 60 * 60 * 24)).coerceAtLeast(0.0)
    }
}
