package com.yttrendpulse.app.ui.screens.health

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yttrendpulse.app.ui.components.YTTopBar
import org.koin.androidx.compose.koinViewModel

/**
 * Écran de santé du moteur (recommandation 12.9 §2), accessible depuis
 * Paramètres : volumes suivis, versions des moteurs, état de la synchro.
 */
@Composable
fun HealthScreen(
    onBack: () -> Unit,
    viewModel: HealthViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { YTTopBar(title = "Santé du moteur", onBack = onBack, onRefresh = { viewModel.refresh() }) },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ListItem(
                headlineContent = { Text("Synchronisation quotidienne") },
                supportingContent = { Text(uiState.lastSyncState) },
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Artistes suivis") },
                supportingContent = { Text("${uiState.artistCount}") },
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Morceaux actifs") },
                supportingContent = { Text("${uiState.activeTrackCount}") },
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Moteur de score") },
                supportingContent = { Text(uiState.scoreEngineVersion) },
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Moteur de prédiction") },
                supportingContent = { Text(uiState.predictionEngineVersion) },
            )
        }
    }
}
