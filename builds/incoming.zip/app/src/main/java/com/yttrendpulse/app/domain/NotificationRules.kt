package com.yttrendpulse.app.domain

/**
 * Règles de déclenchement des notifications "intelligentes", partagées entre
 * [com.yttrendpulse.app.sync.DailySyncWorker] et
 * [com.yttrendpulse.app.sync.EnhancedTrackWorker] (Graphique+, 2.12).
 */
object NotificationRules {
    const val SCORE_JUMP_THRESHOLD = 20.0 // points de score gagnés en une synchro

    private val VIEW_MILESTONES = listOf(
        100_000L, 500_000L, 1_000_000L, 5_000_000L,
        10_000_000L, 50_000_000L, 100_000_000L,
    )

    /** Renvoie le palier le plus élevé franchi entre [before] et [after] (exclus/inclus), ou null. */
    fun crossedMilestone(before: Long, after: Long): Long? =
        VIEW_MILESTONES.lastOrNull { it in (before + 1)..after }

    fun formatMilestone(value: Long): String = when {
        value >= 1_000_000L -> "${value / 1_000_000L} M"
        value >= 1_000L -> "${value / 1_000L} K"
        else -> value.toString()
    }
}
