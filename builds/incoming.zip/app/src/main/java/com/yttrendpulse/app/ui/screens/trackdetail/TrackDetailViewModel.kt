package com.yttrendpulse.app.ui.screens.trackdetail

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.local.SettingsRepository
import com.yttrendpulse.app.data.model.HistoryEntry
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.repository.AuditLogRepository
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.sync.GraphPlusScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class TrackDetailUiState(
    val track: Track? = null,
    val history: List<HistoryEntry> = emptyList(),
    val defaultPredictionHorizonDays: Int = SettingsRepository.DEFAULT_PREDICTION_HORIZON_DAYS,
    val isLoading: Boolean = true,
)

/**
 * Alimente la page de détail d'un morceau (2.10) : bandeau, stats actuelles,
 * historique (graphiques, 2.10), horizon de prédiction par défaut (2.11) et
 * contrôle du suivi renforcé Graphique+ (2.12). La prédiction elle-même
 * (PredictionEngine) est calculée côté écran, à la volée, sans écriture
 * Firestore.
 */
class TrackDetailViewModel(
    private val trackId: String,
    private val trackRepository: TrackRepository,
    private val settingsRepository: SettingsRepository,
    private val auditLogRepository: AuditLogRepository,
    private val context: Context,
) : ViewModel() {

    private val _uiState = MutableStateFlow(TrackDetailUiState())
    val uiState: StateFlow<TrackDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                trackRepository.observeTrack(trackId),
                trackRepository.observeHistory(trackId),
                settingsRepository.defaultPredictionHorizonDays,
            ) { track, history, horizon ->
                TrackDetailUiState(
                    track = track,
                    history = history,
                    defaultPredictionHorizonDays = horizon,
                    isLoading = false,
                )
            }.collect { state -> _uiState.value = state }
        }
    }

    fun togglePin() {
        val wasPinned = _uiState.value.track?.isPinned ?: false
        viewModelScope.launch {
            trackRepository.togglePin(trackId).onSuccess {
                auditLogRepository.log(if (wasPinned) "TRACK_UNPINNED" else "TRACK_PINNED", trackId)
            }
        }
    }

    fun refresh() {
        viewModelScope.launch { trackRepository.refreshTrack(trackId) }
    }

    /**
     * Active (avec [intervalMinutes], borné à 15 min mini par WorkManager) ou
     * désactive (null) le suivi renforcé Graphique+ pour ce morceau (2.12).
     */
    fun setEnhancedTracking(intervalMinutes: Int?) {
        viewModelScope.launch {
            trackRepository.setEnhancedTracking(trackId, intervalMinutes).onSuccess {
                val action = if (intervalMinutes != null) "GRAPH_PLUS_ENABLED" else "GRAPH_PLUS_DISABLED"
                auditLogRepository.log(action, trackId, intervalMinutes?.let { "$it min" } ?: "")
            }
        }
        if (intervalMinutes != null) {
            GraphPlusScheduler.schedule(context, trackId, intervalMinutes)
        } else {
            GraphPlusScheduler.cancel(context, trackId)
        }
    }
}
