package com.yttrendpulse.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.yttrendpulse.app.MainActivity
import com.yttrendpulse.app.R

/**
 * Notifications "intelligentes" (1.8, section notifications du cahier des charges).
 *
 * ⚠️ Précision technique : ce sont des notifications **locales**, déclenchées
 * sur l'appareil par [com.yttrendpulse.app.sync.DailySyncWorker] pendant la
 * synchronisation en tâche de fond — pas des pushs envoyées par un serveur
 * (l'app n'a pas de backend). Le résultat visible est le même pour
 * l'utilisateur (notification dans le centre de notifications, app fermée
 * ou non), mais il n'y a pas de Firebase Cloud Messaging derrière.
 */
object NotificationHelper {
    private const val CHANNEL_ID = "yt_trend_pulse_alerts"
    const val EXTRA_TRACK_ID = "extra_track_id"

    /** À appeler une fois au démarrage de l'app (Android 8+ exige un channel). */
    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Alertes morceaux",
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply {
            description = "Pics de score et paliers de vues franchis"
        }
        context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    /**
     * Affiche une notification pointant vers la page de détail de [trackId].
     * Échoue silencieusement si la permission POST_NOTIFICATIONS (Android 13+)
     * n'a pas été accordée, plutôt que de crasher le worker en tâche de fond.
     */
    fun notify(context: Context, trackId: String, title: String, text: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_TRACK_ID, trackId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            trackId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(trackId.hashCode(), notification)
        }
    }
}
