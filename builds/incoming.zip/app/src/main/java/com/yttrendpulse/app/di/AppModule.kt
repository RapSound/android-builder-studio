package com.yttrendpulse.app.di

import com.yttrendpulse.app.data.local.SettingsRepository
import com.yttrendpulse.app.data.remote.NetworkModule
import com.yttrendpulse.app.data.repository.ArtistRepository
import com.yttrendpulse.app.data.repository.AuditLogRepository
import com.yttrendpulse.app.data.repository.AuthRepository
import com.yttrendpulse.app.data.repository.ChartsRepository
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.data.repository.impl.FirebaseAuthRepository
import com.yttrendpulse.app.data.repository.impl.FirestoreArtistRepository
import com.yttrendpulse.app.data.repository.impl.FirestoreAuditLogRepository
import com.yttrendpulse.app.data.repository.impl.FirestoreTrackRepository
import com.yttrendpulse.app.data.repository.impl.YouTubeChartsRepository
import com.yttrendpulse.app.ui.screens.analyse.AnalyseViewModel
import com.yttrendpulse.app.ui.screens.artistes.ArtistesViewModel
import com.yttrendpulse.app.ui.screens.auditlog.AuditLogViewModel
import com.yttrendpulse.app.ui.screens.auth.AuthViewModel
import com.yttrendpulse.app.ui.screens.charts.ChartsViewModel
import com.yttrendpulse.app.ui.screens.figes.FigesViewModel
import com.yttrendpulse.app.ui.screens.health.HealthViewModel
import com.yttrendpulse.app.ui.screens.parametres.ParametresViewModel
import com.yttrendpulse.app.ui.screens.podium.PodiumViewModel
import com.yttrendpulse.app.ui.screens.trackdetail.TrackDetailViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    // Réseau (déclaré avant les repositories qui en dépendent)
    single { NetworkModule.youTubeApiService }

    // Repositories
    single<AuthRepository> { FirebaseAuthRepository() }
    single<TrackRepository> { FirestoreTrackRepository(youTubeApiService = get()) }
    single<ArtistRepository> { FirestoreArtistRepository() }
    single<ChartsRepository> { YouTubeChartsRepository(get(), get()) }
    single<AuditLogRepository> { FirestoreAuditLogRepository() }
    single { SettingsRepository(get()) }

    // ViewModels
    viewModel { AuthViewModel(get()) }
    viewModel { PodiumViewModel(get(), get()) }
    viewModel { FigesViewModel(get(), get()) }
    viewModel { AnalyseViewModel(get(), get()) }
    viewModel { ChartsViewModel(get(), get()) }
    viewModel {
        params ->
        TrackDetailViewModel(
            trackId = params.get(),
            trackRepository = get(),
            settingsRepository = get(),
            auditLogRepository = get(),
            context = get(),
        )
    }
    viewModel { ArtistesViewModel(get(), get()) }
    viewModel { ParametresViewModel(get(), get(), get()) }
    viewModel { AuditLogViewModel(get()) }
    viewModel { HealthViewModel(get(), get(), get()) }
}
