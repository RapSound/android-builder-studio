package com.yttrendpulse.app.data.model

/**
 * Une entrée d'historique quotidien pour un morceau (1.10).
 * L'historique est illimité : aucune suppression automatique.
 */
data class HistoryEntry(
    val id: String = "",
    val trackId: String = "",
    val date: Long = 0L, // timestamp du jour concerné (ou de la mesure, si Graphique+)

    val viewCount: Long = 0L,
    val likeCount: Long = 0L,
    val commentCount: Long = 0L,

    val score: Double = 0.0,
    val ranking: Int? = null,     // classement au podium ce jour-là
    val evolution: Double = 0.0,  // variation par rapport à l'entrée précédente

    val isPredicted: Boolean = false, // false = donnée réelle, true = point de prédiction (2.11)
)
