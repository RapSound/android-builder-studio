package com.yttrendpulse.app.data.repository.impl

import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.remote.YouTubeApiService
import com.yttrendpulse.app.data.remote.YouTubeParsing
import com.yttrendpulse.app.data.remote.YouTubeVideoItem
import com.yttrendpulse.app.data.repository.ChartType
import com.yttrendpulse.app.data.repository.ChartsRepository
import com.yttrendpulse.app.data.repository.TrackRepository

/**
 * Implémentation de [ChartsRepository] (2.8) via l'endpoint officiel
 * `videos.list?chart=mostPopular` de YouTube Data v3 (region=FR, catégorie Musique).
 *
 * ⚠️ Limite connue : YouTube ne propose pas de chart par genre. Ceci renvoie donc
 * le "Top Musique France" au sens large, pas un chart "Rap Français" strict. Aucune
 * approche de scraping n'est utilisée ici (fragile et hors conditions d'utilisation).
 *
 * Chaque appel ajoute automatiquement en base les morceaux absents (2.8), en les
 * marquant `isFromCharts = true`, et réutilise l'id existant si le morceau est déjà suivi.
 */
class YouTubeChartsRepository(
    private val youTubeApiService: YouTubeApiService,
    private val trackRepository: TrackRepository,
) : ChartsRepository {

    override suspend fun loadChart(type: ChartType): Result<List<Track>> = runCatching {
        val limit = when (type) {
            ChartType.TOP_20_RECENT -> 20
            ChartType.TOP_100_LONG_TERME -> 100
        }

        val items = fetchUpTo(limit)

        val existingByVideoId = trackRepository.getAllActiveTracks()
            .getOrDefault(emptyList())
            .associateBy { it.youtubeVideoId }

        items.map { item ->
            val fresh = toTrack(item)
            val existing = existingByVideoId[item.id]
            val toSave = if (existing != null) {
                fresh.copy(id = existing.id, isPinned = existing.isPinned, isFromCharts = true)
            } else {
                fresh
            }
            trackRepository.upsertTrack(toSave).getOrDefault(toSave)
        }
    }

    /** Récupère jusqu'à [limit] vidéos, en paginant via nextPageToken si besoin (max 50/page). */
    private suspend fun fetchUpTo(limit: Int): List<YouTubeVideoItem> {
        val items = mutableListOf<YouTubeVideoItem>()
        var pageToken: String? = null

        do {
            val response = youTubeApiService.getMostPopularVideos(
                maxResults = minOf(50, limit - items.size),
                pageToken = pageToken,
            )
            items += response.items
            pageToken = response.nextPageToken
        } while (items.size < limit && pageToken != null)

        return items.take(limit)
    }

    private fun toTrack(item: YouTubeVideoItem) = Track(
        youtubeVideoId = item.id,
        title = item.snippet.title,
        artistName = item.snippet.channelTitle,
        thumbnailUrl = item.snippet.thumbnails.high?.url ?: "",
        publishedAt = YouTubeParsing.parsePublishedAt(item.snippet.publishedAt),
        durationSeconds = YouTubeParsing.parseDurationSeconds(item.contentDetails.duration),
        viewCount = item.statistics.viewCount?.toLongOrNull() ?: 0L,
        likeCount = item.statistics.likeCount?.toLongOrNull() ?: 0L,
        commentCount = item.statistics.commentCount?.toLongOrNull() ?: 0L,
        isFromCharts = true,
    )
}
