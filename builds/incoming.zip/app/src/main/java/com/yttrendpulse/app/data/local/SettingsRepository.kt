package com.yttrendpulse.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "yt_trend_pulse_settings")

/**
 * Paramètres persistants de l'application (menu Paramètres, 1.8).
 * TODO: ajouter les intervalles Graphique+ une fois cette fonction écrite (2.12).
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val RECENT_THRESHOLD_DAYS = intPreferencesKey("recent_threshold_days")
        val PREDICTION_HORIZON_DAYS = intPreferencesKey("prediction_horizon_days")
    }

    companion object {
        const val DEFAULT_RECENT_THRESHOLD_DAYS = 5 // valeur par défaut du cahier des charges (2.5)
        const val DEFAULT_PREDICTION_HORIZON_DAYS = 7 // 3/7/15/30 jours possibles (2.11)
    }

    val recentThresholdDays: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.RECENT_THRESHOLD_DAYS] ?: DEFAULT_RECENT_THRESHOLD_DAYS
    }

    suspend fun setRecentThresholdDays(days: Int) {
        context.dataStore.edit { prefs -> prefs[Keys.RECENT_THRESHOLD_DAYS] = days }
    }

    val defaultPredictionHorizonDays: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.PREDICTION_HORIZON_DAYS] ?: DEFAULT_PREDICTION_HORIZON_DAYS
    }

    suspend fun setDefaultPredictionHorizonDays(days: Int) {
        context.dataStore.edit { prefs -> prefs[Keys.PREDICTION_HORIZON_DAYS] = days }
    }
}
