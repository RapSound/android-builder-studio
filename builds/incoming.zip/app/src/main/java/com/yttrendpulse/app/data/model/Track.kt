package com.yttrendpulse.app.data.model

/**
 * Représente un morceau YouTube suivi (2.10).
 * L'identifiant [id] doit être unique et stable (recommandation 12.9 §4).
 */
data class Track(
    val id: String = "",
    val youtubeVideoId: String = "",
    val title: String = "",
    val artistId: String = "",
    val artistName: String = "",
    val thumbnailUrl: String = "",
    val publishedAt: Long = 0L,
    val durationSeconds: Int = 0,

    // Statistiques actuelles (1.5)
    val viewCount: Long = 0L,
    val likeCount: Long = 0L,
    val commentCount: Long = 0L,

    // Score intelligent sur 100 (Viral Score)
    val currentScore: Double = 0.0,
    val previousScore: Double = 0.0,
    val scoreEngineVersion: String = "1.0", // versionnement des algorithmes (12.9 §5)

    // États du morceau
    val isPinned: Boolean = false,      // "Figé" (2.6)
    val isFromCharts: Boolean = false,  // présent dans les charts (2.8)
    val status: TrackStatus = TrackStatus.ACTIVE,

    // Fonction Graphique+ (2.12) : intervalle d'actualisation renforcée en minutes, null = désactivé
    val enhancedTrackingIntervalMinutes: Int? = null,
)

enum class TrackStatus {
    ACTIVE,
    ARCHIVED,
}
