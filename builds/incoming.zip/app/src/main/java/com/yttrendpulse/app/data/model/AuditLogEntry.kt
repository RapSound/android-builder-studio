package com.yttrendpulse.app.data.model

/**
 * Une entrée du journal d'audit des modifications manuelles (12.9 §1) :
 * ajout/suppression d'artiste, morceau figé, synchro manuelle, Graphique+...
 * Permet de savoir "qui a fait quoi" sur l'app, utile pour du support/debug.
 */
data class AuditLogEntry(
    val id: String = "",
    val timestamp: Long = 0L,
    val action: String = "", // ex: "ARTIST_ADDED", "TRACK_PINNED", "MANUAL_SYNC"...
    val targetId: String = "",
    val details: String = "",
)
