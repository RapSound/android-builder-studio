package com.yttrendpulse.app.data

import com.google.firebase.auth.FirebaseAuth

/**
 * Point d'accès unique à l'uid de l'utilisateur connecté. Toutes les données
 * Firestore (artistes, morceaux, journal d'audit) sont scopées sous
 * `users/{uid}/...` : chaque compte a ses propres données, jamais partagées.
 */
object CurrentUser {
    val uid: String?
        get() = FirebaseAuth.getInstance().currentUser?.uid

    /** À utiliser dans les repositories : lève une erreur explicite si personne n'est connecté. */
    fun requireUid(): String =
        uid ?: throw IllegalStateException("Utilisateur non connecté : impossible d'accéder aux données.")
}
