package com.yttrendpulse.app.data.repository.impl

import com.google.firebase.firestore.FirebaseFirestore
import com.yttrendpulse.app.data.CurrentUser
import com.yttrendpulse.app.data.model.Artist
import com.yttrendpulse.app.data.repository.ArtistRepository
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Implémentation Firestore de [ArtistRepository], scopée par compte :
 * `users/{uid}/artists/{artistId}`. Chaque utilisateur a ses propres artistes
 * suivis, jamais partagés entre comptes (voir aussi firestore.rules).
 */
class FirestoreArtistRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
) : ArtistRepository {

    private val artistsCollection
        get() = firestore.collection("users").document(CurrentUser.requireUid()).collection("artists")

    override fun observeArtists(): Flow<List<Artist>> = callbackFlow {
        val uid = CurrentUser.uid
        if (uid == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val registration = artistsCollection.addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val artists = snapshot?.documents?.mapNotNull { it.toObject(Artist::class.java) } ?: emptyList()
            trySend(artists)
        }
        awaitClose { registration.remove() }
    }

    override suspend fun addArtist(name: String, youtubeChannelId: String): Result<Artist> = runCatching {
        // Identifiant unique et stable (recommandation 12.9 §4), indépendant du nom affiché.
        val id = UUID.randomUUID().toString()
        val artist = Artist(
            id = id,
            name = name,
            youtubeChannelId = youtubeChannelId,
            createdAt = System.currentTimeMillis(),
        )
        artistsCollection.document(id).set(artist).await()
        artist
    }

    override suspend fun removeArtist(artistId: String): Result<Unit> = runCatching {
        artistsCollection.document(artistId).delete().await()
        // TODO: décider du sort des morceaux déjà suivis de cet artiste (les garder ou pas).
    }

    override suspend fun refreshArtistTracks(artistId: String): Result<Unit> = runCatching {
        // TODO: appeler YouTubeApiService pour lister les vidéos récentes de la chaîne,
        // créer les Track manquants (< 25 jours, cf. 1.9), partagé avec DailySyncWorker.
    }
}
