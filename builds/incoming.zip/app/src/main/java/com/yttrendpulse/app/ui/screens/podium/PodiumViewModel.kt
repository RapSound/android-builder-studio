package com.yttrendpulse.app.ui.screens.podium

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yttrendpulse.app.data.local.SettingsRepository
import com.yttrendpulse.app.data.model.Track
import com.yttrendpulse.app.data.repository.TrackRepository
import com.yttrendpulse.app.domain.TrackRecency
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class PodiumUiState(
    val topThree: List<Track> = emptyList(),
    val rankFourToTen: List<Track> = emptyList(),
    val recentThresholdDays: Int = SettingsRepository.DEFAULT_RECENT_THRESHOLD_DAYS,
    val isLoading: Boolean = true,
)

class PodiumViewModel(
    private val trackRepository: TrackRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PodiumUiState())
    val uiState: StateFlow<PodiumUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                trackRepository.observePodium(),
                settingsRepository.recentThresholdDays,
            ) { tracks, thresholdDays ->
                PodiumUiState(
                    topThree = tracks.take(3),
                    rankFourToTen = tracks.drop(3).take(7),
                    recentThresholdDays = thresholdDays,
                    isLoading = false,
                )
            }.collect { state -> _uiState.value = state }
        }
    }

    /** Un morceau publié depuis moins de [PodiumUiState.recentThresholdDays] jours (2.5, contour 🔥). */
    fun isRecent(track: Track, state: PodiumUiState): Boolean =
        TrackRecency.isRecent(track, state.recentThresholdDays)

    fun refresh() {
        viewModelScope.launch {
            // TODO: déclencher un refresh ciblé (ex: refreshTrack pour les morceaux affichés)
            // plutôt qu'une resynchronisation complète, pour économiser le quota API.
        }
    }
}
