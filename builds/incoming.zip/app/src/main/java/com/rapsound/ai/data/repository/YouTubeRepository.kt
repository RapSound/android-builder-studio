package com.rapsound.ai.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class YouTubeChannelStats(
    val subscriberCount: Long,
    val viewCount: Long,
    val videoCount: Long
)

// Statistiques YouTube publiques via YouTube Data API v3 (§15). Nécessite une clé API
// (fournie plus tard) — saisie depuis Paramètres, jamais codée en dur (§35).
class YouTubeRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun fetchChannelStats(channelId: String, apiKey: String): Result<YouTubeChannelStats> =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = "https://www.googleapis.com/youtube/v3/channels" +
                    "?part=statistics&id=$channelId&key=$apiKey"
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw IllegalStateException("YouTube API a répondu ${response.code} : $raw")
                    }
                    val items = JSONObject(raw).getJSONArray("items")
                    if (items.length() == 0) {
                        throw IllegalStateException("Aucune chaîne trouvée pour cet ID")
                    }
                    val stats = items.getJSONObject(0).getJSONObject("statistics")
                    YouTubeChannelStats(
                        subscriberCount = stats.optLong("subscriberCount", 0),
                        viewCount = stats.optLong("viewCount", 0),
                        videoCount = stats.optLong("videoCount", 0)
                    )
                }
            }
        }
}
