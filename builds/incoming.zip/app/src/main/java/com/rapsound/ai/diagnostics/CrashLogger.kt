package com.rapsound.ai.diagnostics

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Capture locale des crashs — cohérent avec le positionnement "100% local" de l'app :
// pas de Crashlytics/Sentry (ça enverrait des données à un tiers), juste un fichier
// écrit sur l'appareil, consultable/partageable manuellement depuis Paramètres.
// N'avale jamais le crash : après écriture, la main est rendue au gestionnaire par
// défaut du système (l'app plante normalement, comme sans ce logger).
object CrashLogger {

    fun install(context: Context) {
        val appContext = context.applicationContext
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { writeCrashLog(appContext, throwable) }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun logFile(context: Context): File = File(context.filesDir, "logs/crash_latest.txt")

    private fun writeCrashLog(context: Context, throwable: Throwable) {
        val file = logFile(context)
        file.parentFile?.mkdirs()

        val stackTrace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE).format(Date())

        // Un seul fichier, écrasé à chaque crash — évite une accumulation silencieuse de
        // logs sur un stockage déjà partagé avec les modèles GGUF (plusieurs Go).
        file.writeText(
            "RapSound AI — rapport de crash local\n" +
                "Horodatage : $timestamp\n" +
                "Ce fichier reste uniquement sur cet appareil — voir Paramètres → " +
                "Diagnostics pour le consulter ou le supprimer.\n\n" +
                stackTrace
        )
    }

    fun latestCrashOrNull(context: Context): String? {
        val file = logFile(context)
        return if (file.exists()) file.readText() else null
    }

    fun clear(context: Context) {
        logFile(context).delete()
    }
}
