package com.rapsound.ai.ui.screens.chat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.rapsound.ai.ui.components.ChatBubble
import com.rapsound.ai.ui.components.ChatMessage
import com.rapsound.ai.ui.components.QuickActionChip
import com.rapsound.ai.ui.components.rapSoundQuickActions

// Écran principal — inspiré des apps d'IA modernes type ChatGPT (§20), persisté via
// ChatViewModel (Room + AI Provider, §21/§33), avec streaming token par token et
// annulation en cours de génération (mission "IA locale" §PERFORMANCE) et pièces
// jointes image (§22).
@Composable
fun ChatScreen(viewModel: ChatViewModel, onOpenSettings: () -> Unit = {}) {
    val messages by viewModel.messages.collectAsState()
    val isSending by viewModel.isSending.collectAsState()
    val streamingText by viewModel.streamingText.collectAsState()
    val fallbackNotice by viewModel.fallbackNotice.collectAsState()
    val lastProviderIsLocal by viewModel.lastProviderIsLocal.collectAsState()
    val error by viewModel.error.collectAsState()
    var input by remember { mutableStateOf("") }
    var pendingImages by remember { mutableStateOf(listOf<Uri>()) }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 4)
    ) { uris -> pendingImages = uris }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(rapSoundQuickActions) { action ->
                QuickActionChip(action = action) {
                    input = it.prompt
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            if (messages.isEmpty() && streamingText == null) {
                item {
                    ChatBubble(
                        ChatMessage(
                            "Salut, je suis RapSound AI. Dis-moi ce qu'on construit aujourd'hui pour la chaîne.",
                            isFromUser = false
                        )
                    )
                }
            }
            items(messages, key = { it.id }) { message ->
                ChatBubble(ChatMessage(message.text, message.isFromUser, message.attachmentUrls))
            }
            // Bulle temporaire pour la réponse en cours de génération — pas encore
            // persistée en local, mise à jour token par token.
            streamingText?.let { partial ->
                item(key = "streaming") {
                    if (partial.isEmpty()) {
                        TypingIndicator(isLocal = lastProviderIsLocal)
                    } else {
                        ChatBubble(ChatMessage(partial, isFromUser = false))
                    }
                }
            }
        }

        error?.let { message ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.TextButton(onClick = { viewModel.clearError() }) {
                            Text("Fermer")
                        }
                        androidx.compose.material3.TextButton(onClick = onOpenSettings) {
                            Text("Ouvrir Paramètres")
                        }
                    }
                }
            }
        }

        fallbackNotice?.let { notice ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Text(
                    notice,
                    modifier = Modifier.padding(10.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (pendingImages.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pendingImages) { uri ->
                    Box {
                        AsyncImage(
                            model = uri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
                        )
                        IconButton(
                            onClick = { pendingImages = pendingImages - uri },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Retirer", tint = Color.White)
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    imagePicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                enabled = !isSending
            ) {
                Icon(Icons.Filled.AttachFile, contentDescription = "Pièce jointe")
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Écris à RapSound AI...") },
                shape = RoundedCornerShape(20.dp),
                enabled = !isSending
            )
            Spacer(Modifier.width(8.dp))
            if (isSending) {
                IconButton(onClick = { viewModel.cancelGeneration() }) {
                    Icon(Icons.Filled.Stop, contentDescription = "Arrêter la génération")
                }
            } else {
                IconButton(
                    onClick = {
                        if (input.isNotBlank() || pendingImages.isNotEmpty()) {
                            viewModel.send(input, pendingImages)
                            input = ""
                            pendingImages = emptyList()
                        }
                    }
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Envoyer")
                }
            }
        }
    }
}

@Composable
private fun TypingIndicator(isLocal: Boolean?) {
    val label = when (isLocal) {
        true -> "🧠 IA locale réfléchit..."
        false -> "☁️ Gemini réfléchit..."
        null -> "..."
    }
    Text(
        label,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}
