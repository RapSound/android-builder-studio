package com.rapsound.ai.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Section 23 du cahier des charges — fonctions rapides
data class QuickAction(val emoji: String, val label: String, val prompt: String)

val rapSoundQuickActions = listOf(
    QuickAction(
        "💡", "Idée virale",
        "Propose-moi une idée virale adaptée à RapSound. Réponds strictement sous cette forme, " +
            "une ligne par champ, sans texte avant ou après :\n" +
            "Titre: ...\nFormat: ...\nArtiste: ...\nHook: ...\nDéroulement: ...\nCTA: ...\n" +
            "Durée: ...\nPotentiel: ...\nJustification: ..."
    ),
    QuickAction("📊", "Analyser ma chaîne", "Analyse les performances actuelles de RapSound."),
    QuickAction("🎬", "Analyser ce Short", "Analyse ce Short et donne-moi ton avis."),
    QuickAction("🧠", "Trouver des artistes", "Trouve-moi des artistes pertinents pour RapSound en ce moment."),
    QuickAction("🖼️", "Idée miniature", "Propose-moi une stratégie de miniature Canva."),
    QuickAction("✍️", "Optimiser le titre", "Crée plusieurs titres et explique le meilleur."),
    QuickAction("📝", "Description", "Prépare la description et les infos YouTube."),
    QuickAction("📅", "Planning", "Crée-moi un planning de publication."),
    QuickAction("🚀", "Objectif 1 000 abonnés", "Où en est l'objectif 1 000 abonnés, et que faire pour accélérer ?"),
    QuickAction("🔥", "Booster RapSound", "Analyse globalement la situation et donne les actions prioritaires.")
)

@Composable
fun QuickActionChip(action: QuickAction, onClick: (QuickAction) -> Unit) {
    AssistChip(
        onClick = { onClick(action) },
        label = { Text("${action.emoji} ${action.label}") },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            labelColor = MaterialTheme.colorScheme.onSurface
        ),
        modifier = Modifier.padding(end = 8.dp)
    )
}
