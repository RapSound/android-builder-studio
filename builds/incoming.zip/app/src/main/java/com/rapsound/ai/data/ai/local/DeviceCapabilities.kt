package com.rapsound.ai.data.ai.local

import android.app.ActivityManager
import android.content.Context

// Détecte la RAM disponible pour recommander un modèle adapté (mission "IA locale" —
// "l'application pourrait détecter les ressources disponibles et recommander un modèle").
object DeviceCapabilities {
    fun totalRamGb(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return (info.totalMem / (1024L * 1024L * 1024L)).toInt().coerceAtLeast(1)
    }

    fun recommendedModel(context: Context): LocalModelSpec {
        val ramGb = totalRamGb(context)
        return ModelCatalog.MODELS.firstOrNull { ramGb >= it.recommendedMinRamGb }
            ?: ModelCatalog.MODELS.last()
    }
}
