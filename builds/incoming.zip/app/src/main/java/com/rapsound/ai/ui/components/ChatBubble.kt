package com.rapsound.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

data class ChatMessage(
    val text: String,
    val isFromUser: Boolean,
    val attachmentUrls: List<String> = emptyList()
)

@Composable
fun ChatBubble(message: ChatMessage) {
    val bubbleColor = if (message.isFromUser)
        MaterialTheme.colorScheme.primary
    else
        MaterialTheme.colorScheme.surfaceVariant

    val textColor = if (message.isFromUser)
        MaterialTheme.colorScheme.onPrimary
    else
        MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isFromUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(bubbleColor, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                message.attachmentUrls.forEach { url ->
                    AsyncImage(
                        model = url,
                        contentDescription = "Pièce jointe",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.height(6.dp))
                }
                if (message.text.isNotBlank()) {
                    val strategist = if (!message.isFromUser) StrategistParser.parse(message.text) else null
                    val idea = if (!message.isFromUser && strategist?.isStructured != true) {
                        IdeaParser.parse(message.text)
                    } else null
                    when {
                        strategist?.isStructured == true -> StrategistCard(strategist)
                        idea?.isStructured == true -> IdeaCard(idea)
                        else -> Text(text = message.text, color = textColor)
                    }
                }
            }
        }
    }
}
