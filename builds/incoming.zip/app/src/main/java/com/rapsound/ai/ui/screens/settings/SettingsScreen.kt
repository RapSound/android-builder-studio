package com.rapsound.ai.ui.screens.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rapsound.ai.data.ai.AiProviderRegistry
import com.rapsound.ai.data.ai.local.DownloadState
import com.rapsound.ai.data.ai.local.LocalModelSpec
import com.rapsound.ai.data.ai.local.ModelCatalog
import com.rapsound.ai.data.settings.ApiKeyStore

// Section "IA" du cahier des charges "IA locale" : fournisseur (🧠 local en priorité,
// ☁️ Gemini en option), gestion des modèles Qwen 3 (téléchargement/suppression/sélection),
// paramètres de génération, mode réflexion, repli explicite vers Gemini, clés API.
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel()) {
    var selectedProviderId by remember { mutableStateOf(AiProviderRegistry.current.id) }
    val installedModelIds by viewModel.installedModelIds.collectAsState()
    val downloadState by viewModel.downloadState.collectAsState()
    val localModelId by viewModel.localModelId.collectAsState()
    val thinkingMode by viewModel.thinkingMode.collectAsState()
    val streamingEnabled by viewModel.streamingEnabled.collectAsState()
    val geminiFallbackEnabled by viewModel.geminiFallbackEnabled.collectAsState()
    val strategistMode by viewModel.strategistMode.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val maxTokens by viewModel.maxTokens.collectAsState()
    val contextSize by viewModel.contextSize.collectAsState()
    val testResult by viewModel.testResult.collectAsState()
    val testInProgress by viewModel.testInProgress.collectAsState()
    val gemini by viewModel.geminiKey.collectAsState()
    val openRouter by viewModel.openRouterKey.collectAsState()
    val mistral by viewModel.mistralKey.collectAsState()
    val ytKey by viewModel.youTubeApiKey.collectAsState()
    val ytChannel by viewModel.youTubeChannelId.collectAsState()
    val localStorageBytes by viewModel.localStorageBytes.collectAsState()
    val exportImportMessage by viewModel.exportImportMessage.collectAsState()
    val latestCrash by viewModel.latestCrash.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let { viewModel.exportData(it) } }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importData(it) } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Text("Fournisseur IA", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Priorité à l'IA locale : elle est utilisée par défaut, sans Internet, sans " +
                    "clé et sans envoyer aucun message à l'extérieur.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
        }
        items(AiProviderRegistry.providers) { provider ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedProviderId == provider.id,
                        onClick = {
                            AiProviderRegistry.select(provider.id)
                            selectedProviderId = provider.id
                        }
                    )
                    Column {
                        Text(
                            "${if (provider.isLocal) "🧠" else "☁️"} ${provider.displayName}",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            if (provider.isLocal) "100 % local — vos données restent sur l'appareil."
                            else "Les messages nécessaires à la génération sont envoyés à ce fournisseur.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(20.dp))
            Text("🧠 IA locale — modèles Qwen 3", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Cet appareil a environ ${viewModel.totalRamGb} Go de RAM — modèle recommandé : " +
                    viewModel.recommendedModel.displayName + ".",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
        }
        items(ModelCatalog.MODELS) { spec ->
            ModelCard(
                spec = spec,
                isInstalled = installedModelIds.contains(spec.id),
                isSelected = localModelId == spec.id,
                downloadState = downloadState?.takeIf { it.first == spec.id }?.second,
                onDownload = { viewModel.downloadModel(spec) },
                onCancelDownload = { viewModel.cancelDownload(spec) },
                onDelete = { viewModel.deleteModel(spec) },
                onSelect = { viewModel.selectLocalModel(spec) }
            )
        }

        item {
            OutlinedButton(
                onClick = { viewModel.testCurrentProvider() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                enabled = !testInProgress
            ) {
                Text(if (testInProgress) "Test en cours..." else "Tester l'IA")
            }
            testResult?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(16.dp))
            Text("Génération", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            NumericField("Température (0.0–2.0, défaut 0.7)", temperature) {
                viewModel.saveKey(ApiKeyStore.LOCAL_TEMPERATURE, it)
            }
            NumericField("Nombre maximal de tokens (défaut 512)", maxTokens) {
                viewModel.saveKey(ApiKeyStore.LOCAL_MAX_TOKENS, it)
            }
            NumericField("Taille du contexte (défaut 4096)", contextSize) {
                viewModel.saveKey(ApiKeyStore.LOCAL_CONTEXT_SIZE, it)
            }
            SettingSwitchRow(
                "Streaming",
                "Affiche la réponse au fur et à mesure plutôt que d'attendre la fin.",
                streamingEnabled
            ) { viewModel.setStreamingEnabled(it) }
            SettingSwitchRow(
                "Mode réflexion (Qwen 3)",
                "Raisonnement plus poussé mais plus lent. Désactivé = réponses rapides (/no_think).",
                thinkingMode
            ) { viewModel.setThinkingMode(it) }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))
            Text("Repli vers Gemini", style = MaterialTheme.typography.titleMedium)
            SettingSwitchRow(
                "Autoriser le repli automatique",
                "Si activé et qu'une clé Gemini est configurée, RapSound AI basculera vers " +
                    "☁️ Gemini quand le modèle local n'est pas installé — toujours avec un " +
                    "message explicite, jamais en silence.",
                geminiFallbackEnabled
            ) { viewModel.setGeminiFallbackEnabled(it) }

            Spacer(Modifier.height(20.dp))
            Text("Clés API distantes", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Stockées uniquement sur cet appareil, jamais codées en dur (§35).",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            ApiKeyField("Gemini", gemini) { viewModel.saveKey(ApiKeyStore.GEMINI, it) }
            ApiKeyField("OpenRouter", openRouter) { viewModel.saveKey(ApiKeyStore.OPENROUTER, it) }
            ApiKeyField("Mistral", mistral) { viewModel.saveKey(ApiKeyStore.MISTRAL, it) }

            Spacer(Modifier.height(20.dp))
            Text("YouTube", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ApiKeyField("Clé API YouTube", ytKey) { viewModel.saveKey(ApiKeyStore.YOUTUBE_API_KEY, it) }
            ApiKeyField("ID de chaîne", ytChannel, isSecret = false) {
                viewModel.saveKey(ApiKeyStore.YOUTUBE_CHANNEL_ID, it)
            }

            Spacer(Modifier.height(20.dp))
            Text("Mode RapSound Strategist", style = MaterialTheme.typography.titleMedium)
            SettingSwitchRow(
                "Activer",
                "Structure les réponses en Diagnostic / Problèmes / Opportunités / " +
                    "Priorités / Plan d'action (§24).",
                strategistMode
            ) { viewModel.setStrategistMode(it) }

            Spacer(Modifier.height(20.dp))
            Text("Stockage", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "100 % local — mémoire, projets et conversations sont stockés dans une base " +
                            "SQLite privée à l'app (aucun compte, aucun cloud requis).",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    localStorageBytes?.let { bytes ->
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Base de données + pièces jointes : ${bytes / 1_000_000} Mo " +
                                "(hors modèles IA, listés ci-dessus).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Sauvegarde", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Le stockage étant 100 % local, perdre ou changer de téléphone sans sauvegarde " +
                    "efface tout. Exporte régulièrement un fichier JSON (mémoire, projets, " +
                    "conversations — sans les images jointes) et garde-le où tu veux " +
                    "(Drive, email, stockage local).",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportLauncher.launch("rapsound-ai-backup.json") }) {
                    Text("Exporter")
                }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json")) }) {
                    Text("Importer")
                }
            }
            exportImportMessage?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(20.dp))
            Text("Diagnostics", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Aucun rapport de crash n'est envoyé automatiquement à qui que ce soit — " +
                    "s'il y en a un, il reste sur cet appareil jusqu'à ce que tu choisisses " +
                    "explicitement de le partager.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            if (latestCrash == null) {
                Text(
                    "Aucun crash enregistré.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_TEXT, latestCrash)
                            }
                            context.startActivity(
                                android.content.Intent.createChooser(sendIntent, "Partager le rapport de crash")
                            )
                        }
                    ) {
                        Text("Partager")
                    }
                    TextButton(onClick = { viewModel.clearCrashLog() }) {
                        Text("Effacer")
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelCard(
    spec: LocalModelSpec,
    isInstalled: Boolean,
    isSelected: Boolean,
    downloadState: DownloadState?,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit,
    onDelete: () -> Unit,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(spec.displayName, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "~${spec.approxSizeBytes / 1_000_000_000} Go · ${spec.recommendedMinRamGb} Go RAM recommandés",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                when {
                    downloadState is DownloadState.Progress || downloadState is DownloadState.Verifying ->
                        TextButton(onClick = onCancelDownload) { Text("Annuler") }
                    isInstalled && isSelected -> Text("Actif ✓", color = MaterialTheme.colorScheme.primary)
                    isInstalled -> TextButton(onClick = onSelect) { Text("Sélectionner") }
                    else -> Button(onClick = onDownload) { Text("Télécharger") }
                }
            }
            when (downloadState) {
                is DownloadState.Progress -> {
                    Spacer(Modifier.height(6.dp))
                    val fraction = if (downloadState.totalBytes > 0) {
                        (downloadState.downloadedBytes.toFloat() / downloadState.totalBytes).coerceIn(0f, 1f)
                    } else 0f
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                    Text(
                        "${downloadState.downloadedBytes / 1_000_000} / ${downloadState.totalBytes / 1_000_000} Mo",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is DownloadState.Verifying -> {
                    Spacer(Modifier.height(6.dp))
                    Text("Vérification du fichier...", style = MaterialTheme.typography.bodyMedium)
                }
                is DownloadState.Failed -> {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Échec : ${downloadState.message}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                else -> Unit
            }
            if (isInstalled) {
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = onDelete) { Text("Supprimer") }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(title: String, description: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun NumericField(label: String, storedValue: String?, onSave: (String) -> Unit) {
    var text by remember(storedValue) { mutableStateOf(storedValue.orEmpty()) }
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text(label) },
            singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { onSave(text) }, enabled = text != storedValue.orEmpty()) {
            Text("Enregistrer")
        }
    }
}

@Composable
private fun ApiKeyField(
    label: String,
    storedValue: String?,
    isSecret: Boolean = true,
    onSave: (String) -> Unit
) {
    var text by remember(storedValue) { mutableStateOf(storedValue.orEmpty()) }
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text(label) },
            singleLine = true,
            visualTransformation = if (isSecret) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { onSave(text) }, enabled = text != storedValue.orEmpty()) {
            Text("Enregistrer")
        }
    }
}
