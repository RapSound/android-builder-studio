package com.rapsound.ai.ui.screens.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rapsound.ai.data.model.MemoryEntry
import com.rapsound.ai.data.repository.MemoryRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MemoryViewModel @JvmOverloads constructor(
    private val repository: MemoryRepository = MemoryRepository()
) : ViewModel() {

    val categories = MemoryRepository.CATEGORIES

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        viewModelScope.launch {
            runCatching { repository.seedDefaultMemoryIfEmpty() }
        }
    }

    val entries: StateFlow<List<MemoryEntry>> = _selectedCategory
        .flatMapLatest { category ->
            repository.observeMemory(category).catch { e ->
                _error.value = e.message
                emit(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectCategory(category: String?) {
        _selectedCategory.value = category
    }

    fun addMemory(category: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            runCatching { repository.addMemory(category, text) }
                .onFailure { _error.value = it.message }
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch {
            runCatching { repository.deleteMemory(id) }
                .onFailure { _error.value = it.message }
        }
    }
}
