package com.rapsound.ai.ui.components

// Détecte une réponse "idée structurée" (§27) au format "Label: valeur" par ligne.
// Le quick action "Idée virale" (QuickActionChip.kt) demande explicitement ce format
// au fournisseur IA ; si le modèle ne le suit pas, `parse` renvoie null et le texte
// s'affiche normalement.
data class RapSoundIdea(
    val titre: String?,
    val format: String?,
    val artiste: String?,
    val hook: String?,
    val deroulement: String?,
    val cta: String?,
    val duree: String?,
    val potentiel: String?,
    val justification: String?
) {
    val isStructured: Boolean
        get() = listOfNotNull(titre, format, hook, deroulement).size >= 2
}

private val IDEA_LABELS = listOf(
    "Titre" to "titre",
    "Format" to "format",
    "Artiste" to "artiste",
    "Hook" to "hook",
    "Déroulement" to "deroulement",
    "CTA" to "cta",
    "Durée" to "duree",
    "Potentiel" to "potentiel",
    "Justification" to "justification"
)

object IdeaParser {
    fun parse(text: String): RapSoundIdea? {
        val values = mutableMapOf<String, String>()
        text.lines().forEach { line ->
            val idx = line.indexOf(':')
            if (idx <= 0) return@forEach
            val label = line.substring(0, idx).trim().trimStart('#', '*', '-', ' ')
            val value = line.substring(idx + 1).trim()
            IDEA_LABELS.firstOrNull { it.first.equals(label, ignoreCase = true) }?.let { values[it.second] = value }
        }
        if (values.size < 2) return null
        return RapSoundIdea(
            titre = values["titre"],
            format = values["format"],
            artiste = values["artiste"],
            hook = values["hook"],
            deroulement = values["deroulement"],
            cta = values["cta"],
            duree = values["duree"],
            potentiel = values["potentiel"],
            justification = values["justification"]
        )
    }
}
