package com.rapsound.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.rapsound.ai.navigation.RapSoundNavGraph
import com.rapsound.ai.ui.components.RapSoundAppScaffold
import com.rapsound.ai.ui.screens.chat.ChatViewModel
import com.rapsound.ai.ui.theme.RapSoundAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RapSoundAITheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    // Instance unique partagée entre l'écran Conversation, le bouton
                    // "nouvelle conversation" de la top bar, et l'ouverture depuis l'Historique.
                    val chatViewModel: ChatViewModel = viewModel()
                    RapSoundAppScaffold(
                        navController = navController,
                        onNewConversation = { chatViewModel.startNewConversation() }
                    ) {
                        RapSoundNavGraph(navController = navController, chatViewModel = chatViewModel)
                    }
                }
            }
        }
    }
}
