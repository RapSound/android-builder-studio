package com.rapsound.ai.ui.screens.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rapsound.ai.data.ai.AiMessage
import com.rapsound.ai.data.ai.AiProviderRegistry
import com.rapsound.ai.data.ai.local.DeviceCapabilities
import com.rapsound.ai.data.ai.local.DownloadState
import com.rapsound.ai.data.ai.local.LocalModelSpec
import com.rapsound.ai.data.ai.local.ModelManager
import com.rapsound.ai.data.repository.ExportRepository
import com.rapsound.ai.data.settings.ApiKeyStore
import com.rapsound.ai.diagnostics.CrashLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import android.net.Uri

class SettingsViewModel @JvmOverloads constructor(
    application: Application,
    private val apiKeyStore: ApiKeyStore = ApiKeyStore(application),
    private val modelManager: ModelManager = AiProviderRegistry.modelManagerInstance(),
    private val exportRepository: ExportRepository = ExportRepository()
) : AndroidViewModel(application) {

    // --- Fournisseurs distants (clés, jamais en dur — §35) ---
    val geminiKey: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.GEMINI)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val openRouterKey: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.OPENROUTER)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val mistralKey: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.MISTRAL)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val youTubeApiKey: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.YOUTUBE_API_KEY)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val youTubeChannelId: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.YOUTUBE_CHANNEL_ID)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- IA locale (mission "IA locale") ---
    val localModelId: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.LOCAL_MODEL_ID)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val temperature: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.LOCAL_TEMPERATURE)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val maxTokens: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.LOCAL_MAX_TOKENS)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val contextSize: StateFlow<String?> = apiKeyStore.observeKey(ApiKeyStore.LOCAL_CONTEXT_SIZE)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val thinkingMode: StateFlow<Boolean> = apiKeyStore.observeThinkingMode()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val streamingEnabled: StateFlow<Boolean> = apiKeyStore.observeStreamingEnabled()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val geminiFallbackEnabled: StateFlow<Boolean> = apiKeyStore.observeGeminiFallbackEnabled()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val strategistMode: StateFlow<Boolean> = apiKeyStore.observeStrategistMode()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _installedModelIds = MutableStateFlow<Set<String>>(emptySet())
    val installedModelIds: StateFlow<Set<String>> = _installedModelIds

    // (modelId, état) du téléchargement en cours, s'il y en a un.
    private val _downloadState = MutableStateFlow<Pair<String, DownloadState>?>(null)
    val downloadState: StateFlow<Pair<String, DownloadState>?> = _downloadState
    private var downloadJob: Job? = null

    private val _testResult = MutableStateFlow<String?>(null)
    val testResult: StateFlow<String?> = _testResult
    private val _testInProgress = MutableStateFlow(false)
    val testInProgress: StateFlow<Boolean> = _testInProgress

    private val _exportImportMessage = MutableStateFlow<String?>(null)
    val exportImportMessage: StateFlow<String?> = _exportImportMessage

    private val _latestCrash = MutableStateFlow<String?>(null)
    val latestCrash: StateFlow<String?> = _latestCrash

    fun refreshCrashLog() {
        _latestCrash.value = CrashLogger.latestCrashOrNull(getApplication())
    }

    fun clearCrashLog() {
        CrashLogger.clear(getApplication())
        _latestCrash.value = null
    }

    val recommendedModel: LocalModelSpec = DeviceCapabilities.recommendedModel(application)
    val totalRamGb: Int = DeviceCapabilities.totalRamGb(application)

    private val _localStorageBytes = MutableStateFlow<Long?>(null)
    val localStorageBytes: StateFlow<Long?> = _localStorageBytes

    init {
        refreshInstalled()
        refreshStorageUsage()
        refreshCrashLog()
    }

    // Taille de la base SQLite + des pièces jointes (hors modèles GGUF, déjà affichés par
    // modèle plus haut) — transparence sur ce que "100 % local" occupe réellement (§35 en
    // esprit : rien de cette mesure ne quitte l'appareil).
    fun refreshStorageUsage() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _localStorageBytes.value = withContext(Dispatchers.IO) {
                val dbFile = app.getDatabasePath("rapsound.db")
                val attachmentsDir = File(app.filesDir, "attachments")
                dbFile.sizeRecursively() + attachmentsDir.sizeRecursively()
            }
        }
    }

    private fun File.sizeRecursively(): Long = when {
        !exists() -> 0L
        isDirectory -> listFiles()?.sumOf { it.sizeRecursively() } ?: 0L
        else -> length()
    }

    private fun refreshInstalled() {
        _installedModelIds.value = modelManager.installedModels().map { it.id }.toSet()
    }

    fun saveKey(providerId: String, value: String) {
        viewModelScope.launch { apiKeyStore.setKey(providerId, value) }
    }

    fun setStrategistMode(enabled: Boolean) {
        viewModelScope.launch { apiKeyStore.setStrategistMode(enabled) }
    }

    fun setThinkingMode(enabled: Boolean) {
        viewModelScope.launch { apiKeyStore.setThinkingMode(enabled) }
    }

    fun setStreamingEnabled(enabled: Boolean) {
        viewModelScope.launch { apiKeyStore.setStreamingEnabled(enabled) }
    }

    fun setGeminiFallbackEnabled(enabled: Boolean) {
        viewModelScope.launch { apiKeyStore.setGeminiFallbackEnabled(enabled) }
    }

    fun selectLocalModel(spec: LocalModelSpec) {
        viewModelScope.launch { apiKeyStore.setKey(ApiKeyStore.LOCAL_MODEL_ID, spec.id) }
    }

    fun downloadModel(spec: LocalModelSpec) {
        downloadJob?.cancel()
        downloadJob = viewModelScope.launch {
            modelManager.download(spec).collect { state ->
                _downloadState.value = spec.id to state
            }
            refreshInstalled()
            if (localModelId.value == null) selectLocalModel(spec)
        }
    }

    // Annule un téléchargement en cours et supprime le fichier partiel — sans ça, un
    // modèle de plusieurs Go interrompu resterait à moitié écrit sur le disque (§📦).
    fun cancelDownload(spec: LocalModelSpec) {
        downloadJob?.cancel()
        downloadJob = null
        modelManager.deletePartial(spec)
        _downloadState.value = null
    }

    fun deleteModel(spec: LocalModelSpec) {
        AiProviderRegistry.localProviderInstance().unload()
        modelManager.delete(spec)
        refreshInstalled()
    }

    fun testCurrentProvider() {
        viewModelScope.launch {
            _testInProgress.value = true
            _testResult.value = null
            runCatching {
                val builder = StringBuilder()
                AiProviderRegistry.current.sendMessageStream(
                    listOf(AiMessage(AiMessage.Role.USER, "Dis bonjour en une phrase.")),
                    "Tu es RapSound AI. Réponds très brièvement, en français."
                ).collect { builder.append(it) }
                builder.toString().ifBlank { "(réponse vide)" }
            }.onSuccess { _testResult.value = "✅ ${AiProviderRegistry.current.displayName} : $it" }
                .onFailure { _testResult.value = "❌ ${it.message}" }
            _testInProgress.value = false
        }
    }

    // Sauvegarde/restauration — filet de sécurité pour le stockage 100% local (voir
    // CHECKLIST_PROFESSIONNALISATION.md). L'Uri vient du sélecteur système
    // (CreateDocument/OpenDocument), donc aucune permission de stockage classique requise.
    fun exportData(uri: Uri) {
        viewModelScope.launch {
            _exportImportMessage.value = null
            runCatching {
                val json = exportRepository.exportToJson()
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                        it.write(json.toByteArray(Charsets.UTF_8))
                    } ?: error("Impossible d'écrire le fichier choisi")
                }
            }.onSuccess { _exportImportMessage.value = "✅ Export réussi." }
                .onFailure { _exportImportMessage.value = "❌ Échec de l'export : ${it.message}" }
        }
    }

    fun importData(uri: Uri) {
        viewModelScope.launch {
            _exportImportMessage.value = null
            runCatching {
                val json = withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use {
                        it.readBytes().toString(Charsets.UTF_8)
                    } ?: error("Fichier illisible")
                }
                exportRepository.importFromJson(json)
            }.onSuccess { result ->
                _exportImportMessage.value = "✅ Importé : ${result.memoryEntries} souvenirs, " +
                    "${result.projects} projets, ${result.conversations} conversations."
            }.onFailure { _exportImportMessage.value = "❌ Échec de l'import : ${it.message}" }
        }
    }
}
