package com.rapsound.ai.data.local

import android.content.Context
import androidx.room.Room

// Point d'accès unique à la base Room, initialisé une fois au démarrage
// (RapSoundApplication.onCreate) — permet aux repositories de garder un constructeur
// sans argument, exactement comme avant avec Firestore, pour ne pas répercuter le
// changement d'architecture dans tous les ViewModels.
object LocalDatabase {
    private lateinit var db: RapSoundDatabase

    fun init(context: Context) {
        if (!::db.isInitialized) {
            db = Room.databaseBuilder(
                context.applicationContext,
                RapSoundDatabase::class.java,
                "rapsound.db"
            )
                // Pas encore de migrations formelles à ce stade du projet ; à remplacer
                // par de vraies Migration() dès que le schéma doit évoluer sans perdre
                // les données existantes des utilisateurs.
                .fallbackToDestructiveMigration()
                .build()
        }
    }

    val database: RapSoundDatabase
        get() = db
}
