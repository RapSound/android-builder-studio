package com.rapsound.ai.data.repository

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

// Pièces jointes (images) — §22 du cahier des charges. Stockage 100% local : les
// fichiers sont copiés dans le stockage privé de l'app (aucune permission requise,
// invisible aux autres apps), plus d'upload vers un service distant.
class AttachmentRepository {

    // Copie l'image pointée par `uri` dans files/attachments/{conversationId}/ et
    // retourne un chemin "file://..." directement utilisable par Coil (AsyncImage).
    suspend fun storeImage(context: Context, conversationId: String, uri: Uri): String =
        withContext(Dispatchers.IO) {
            val dir = File(context.filesDir, "attachments/$conversationId").apply { mkdirs() }
            val target = File(dir, "${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            } ?: error("Impossible de lire la pièce jointe")
            "file://${target.absolutePath}"
        }

    // Supprime tous les fichiers d'une conversation — à appeler quand la conversation
    // elle-même est supprimée, sinon les images restent orphelines sur le disque
    // indéfiniment (le stockage étant 100% local, rien ne les nettoie automatiquement).
    suspend fun deleteConversationAttachments(context: Context, conversationId: String) {
        withContext(Dispatchers.IO) {
            File(context.filesDir, "attachments/$conversationId").deleteRecursively()
        }
    }
}
