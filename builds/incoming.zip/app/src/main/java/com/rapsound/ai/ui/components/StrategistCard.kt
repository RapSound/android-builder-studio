package com.rapsound.ai.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun StrategistCard(sections: StrategistSections) {
    Column(modifier = Modifier.fillMaxWidth()) {
        StrategistSectionCard("Diagnostic", sections.diagnostic)
        StrategistSectionCard("Problèmes", sections.problemes)
        StrategistSectionCard("Opportunités", sections.opportunites)
        StrategistSectionCard("Priorités", sections.priorites)
        StrategistSectionCard("Plan d'action", sections.planAction)
    }
}

@Composable
private fun StrategistSectionCard(title: String, content: String?) {
    if (content.isNullOrBlank()) return
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(content, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
