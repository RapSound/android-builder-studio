package com.rapsound.ai.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// Schéma local (Room/SQLite) — remplace Firestore, tout reste sur l'appareil.
// Les identifiants restent des String (UUID) plutôt que des Long auto-incrémentés,
// pour matcher les modèles de domaine existants (data/model/Models.kt) et éviter de
// répercuter un changement de type dans tout le reste de l'app.

@Entity(tableName = "memory_entries")
data class MemoryEntryEntity(
    @PrimaryKey val id: String,
    val category: String,
    val text: String,
    val enabled: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "projects")
data class RapProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val status: String,
    val description: String,
    val createdAt: Long
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectId: String = "",
    val projectName: String = "",
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val lastMessagePreview: String = "",
    val updatedAt: Long
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("conversationId")]
)
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val text: String,
    val isFromUser: Boolean,
    // Chemins de fichiers locaux ("file://...") joints par une virgule — évite un
    // TypeConverter Room pour une simple liste de chaînes.
    val attachmentPaths: String = "",
    val createdAt: Long
)

@Entity(tableName = "goals")
data class SubscriberGoalEntity(
    @PrimaryKey val id: String = "subscribers",
    val label: String = "Abonnés",
    val current: Long = 792,
    val target: Long = 1000
)
