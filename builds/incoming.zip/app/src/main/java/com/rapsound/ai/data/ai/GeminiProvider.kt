package com.rapsound.ai.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Google Gemini via l'API REST generativelanguage.googleapis.com, en streaming SSE (§33).
// Supporte les images en pièce jointe via inline_data (§22 — Gemini est multimodal).
// La clé est lue à l'exécution via `apiKeyProvider` — jamais codée en dur (§35).
// C'est un fournisseur DISTANT (isLocal = false) : les messages quittent l'appareil.
class GeminiProvider(
    private val apiKeyProvider: suspend () -> String?,
    private val model: String = "gemini-2.0-flash"
) : AiProvider {
    override val id = "gemini"
    override val displayName = "Google Gemini"
    override val isFree = false
    override val isLocal = false

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    override fun sendMessageStream(history: List<AiMessage>, systemPrompt: String): Flow<String> = flow {
        val apiKey = apiKeyProvider()
        if (apiKey.isNullOrBlank()) {
            throw IllegalStateException("Clé API Gemini manquante (Paramètres → IA)")
        }

        val contents = JSONArray()
        history.filter { it.role != AiMessage.Role.SYSTEM }.forEach { message ->
            val parts = JSONArray()
            if (message.content.isNotBlank()) {
                parts.put(JSONObject().put("text", message.content))
            }
            message.images.forEach { image ->
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", image.mimeType).put("data", image.base64)
                    )
                )
            }
            contents.put(
                JSONObject().apply {
                    put("role", if (message.role == AiMessage.Role.USER) "user" else "model")
                    put("parts", parts)
                }
            )
        }

        val body = JSONObject().apply {
            put("contents", contents)
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini a répondu ${response.code} : ${response.body?.string().orEmpty()}")
            }
            val source = response.body?.source() ?: throw IllegalStateException("Réponse vide de Gemini")
            while (!source.exhausted()) {
                currentCoroutineContext().ensureActive()
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data: ")) continue
                val jsonText = line.removePrefix("data: ").trim()
                if (jsonText.isEmpty() || jsonText == "[DONE]") continue
                val chunk = runCatching {
                    JSONObject(jsonText)
                        .optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                        ?.optString("text")
                }.getOrNull()
                if (!chunk.isNullOrEmpty()) emit(chunk)
            }
        }
    }.flowOn(Dispatchers.IO)
}
