package com.rapsound.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_entries WHERE enabled = 1 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<MemoryEntryEntity>>

    @Query("SELECT * FROM memory_entries WHERE enabled = 1 AND category = :category ORDER BY createdAt DESC")
    fun observeByCategory(category: String): Flow<List<MemoryEntryEntity>>

    @Query("SELECT COUNT(*) FROM memory_entries")
    suspend fun count(): Int

    @Insert
    suspend fun insert(entry: MemoryEntryEntity)

    @Insert
    suspend fun insertAll(entries: List<MemoryEntryEntity>)

    @Query("DELETE FROM memory_entries WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE memory_entries SET enabled = :enabled, updatedAt = :updatedAt WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean, updatedAt: Long)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<RapProjectEntity>>

    @Query("SELECT COUNT(*) FROM projects")
    suspend fun count(): Int

    @Insert
    suspend fun insertAll(projects: List<RapProjectEntity>)

    @Query("UPDATE projects SET description = :description, status = :status WHERE id = :id")
    suspend fun update(id: String, description: String, status: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE archived = 0 ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeForProject(projectId: String): Flow<List<ConversationEntity>>

    @Insert
    suspend fun insert(conversation: ConversationEntity)

    @Query("UPDATE conversations SET title = :title WHERE id = :id")
    suspend fun rename(id: String, title: String)

    @Query("UPDATE conversations SET favorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: String, favorite: Boolean)

    @Query("UPDATE conversations SET archived = 1 WHERE id = :id")
    suspend fun archive(id: String)

    @Query("UPDATE conversations SET projectId = :projectId, projectName = :projectName WHERE id = :id")
    suspend fun setProject(id: String, projectId: String, projectName: String)

    @Query("UPDATE conversations SET lastMessagePreview = :preview, updatedAt = :updatedAt WHERE id = :id")
    suspend fun touch(id: String, preview: String, updatedAt: Long)

    // ON DELETE CASCADE (voir ChatMessageEntity) supprime les messages automatiquement —
    // plus besoin de la suppression manuelle en cascade qu'il fallait faire côté client
    // avec Firestore.
    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    fun observeMessages(conversationId: String): Flow<List<ChatMessageEntity>>

    @Insert
    suspend fun insert(message: ChatMessageEntity)
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE id = 'subscribers' LIMIT 1")
    fun observe(): Flow<SubscriberGoalEntity?>

    @Query("SELECT COUNT(*) FROM goals")
    suspend fun count(): Int

    // REPLACE plutôt que le défaut ABORT : permet à l'import (ExportRepository) d'écraser
    // l'objectif existant sans devoir gérer un cas d'erreur de contrainte à part.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goal: SubscriberGoalEntity)
}
