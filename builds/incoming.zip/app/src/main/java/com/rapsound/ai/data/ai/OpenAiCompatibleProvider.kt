package com.rapsound.ai.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Fournisseur générique pour toute API compatible "OpenAI chat completions" en streaming
// SSE (OpenRouter, Mistral partagent le même format) — §33. Supporte les images en
// pièce jointe (§22) via le format "image_url" — nécessite un modèle multimodal côté
// fournisseur (ex. openai/gpt-4o-mini sur OpenRouter ; pixtral-large-latest sur Mistral).
// Ce sont des fournisseurs DISTANTS (isLocal = false) : les messages quittent l'appareil.
class OpenAiCompatibleProvider(
    override val id: String,
    override val displayName: String,
    private val endpoint: String,
    private val model: String,
    private val apiKeyProvider: suspend () -> String?
) : AiProvider {
    override val isFree = false
    override val isLocal = false

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    override fun sendMessageStream(history: List<AiMessage>, systemPrompt: String): Flow<String> = flow {
        val apiKey = apiKeyProvider()
        if (apiKey.isNullOrBlank()) {
            throw IllegalStateException("Clé API manquante pour $displayName (Paramètres → IA)")
        }

        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            history.forEach { message ->
                val roleStr = if (message.role == AiMessage.Role.USER) "user" else "assistant"
                if (message.images.isEmpty()) {
                    put(JSONObject().put("role", roleStr).put("content", message.content))
                } else {
                    val contentParts = JSONArray()
                    if (message.content.isNotBlank()) {
                        contentParts.put(JSONObject().put("type", "text").put("text", message.content))
                    }
                    message.images.forEach { image ->
                        contentParts.put(
                            JSONObject().put("type", "image_url").put(
                                "image_url",
                                JSONObject().put("url", "data:${image.mimeType};base64,${image.base64}")
                            )
                        )
                    }
                    put(JSONObject().put("role", roleStr).put("content", contentParts))
                }
            }
        }

        val body = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("stream", true)
        }

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("$displayName a répondu ${response.code} : ${response.body?.string().orEmpty()}")
            }
            val source = response.body?.source() ?: throw IllegalStateException("Réponse vide de $displayName")
            while (!source.exhausted()) {
                currentCoroutineContext().ensureActive()
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data: ")) continue
                val jsonText = line.removePrefix("data: ").trim()
                if (jsonText.isEmpty() || jsonText == "[DONE]") continue
                val chunk = runCatching {
                    JSONObject(jsonText)
                        .optJSONArray("choices")?.optJSONObject(0)
                        ?.optJSONObject("delta")?.optString("content")
                }.getOrNull()
                if (!chunk.isNullOrEmpty()) emit(chunk)
            }
        }
    }.flowOn(Dispatchers.IO)
}
