package com.rapsound.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Identité RapSound — noir / rouge / blanc
val RapBackground = Color(0xFF0B0B0D)
val RapSurface = Color(0xFF16161A)
val RapSurfaceElevated = Color(0xFF1F1F24)
val RapRed = Color(0xFFE8283F)
val RapRedDark = Color(0xFFB01E30)
val RapWhite = Color(0xFFF5F5F7)
val RapGrey = Color(0xFF8B8B92)
val RapDivider = Color(0xFF2A2A30)
