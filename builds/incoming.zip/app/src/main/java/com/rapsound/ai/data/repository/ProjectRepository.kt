package com.rapsound.ai.data.repository

import com.rapsound.ai.data.local.LocalDatabase
import com.rapsound.ai.data.local.RapProjectEntity
import com.rapsound.ai.data.model.RapProject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Date
import java.util.UUID

// Système de projets — §19 du cahier des charges. Stockage 100% local (Room/SQLite).
class ProjectRepository {
    private val dao get() = LocalDatabase.database.projectDao()

    fun observeProjects(): Flow<List<RapProject>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun updateProject(projectId: String, description: String, status: String) {
        dao.update(projectId, description, status)
    }

    // Pré-remplit les projets connus de RapSound à la première ouverture (arborescence §19).
    suspend fun seedDefaultProjectsIfEmpty() {
        if (dao.count() > 0) return
        val now = System.currentTimeMillis()
        dao.insertAll(
            DEFAULT_PROJECTS.map { (name, status) ->
                RapProjectEntity(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    status = status,
                    description = "",
                    createdAt = now
                )
            }
        )
    }

    companion object {
        val DEFAULT_PROJECTS = listOf(
            "Shorts" to "Actif",
            "Karaokés" to "Actif",
            "Blind Tests" to "Actif",
            "Blind dans le passé" to "Actif",
            "Ligue du son" to "En préparation",
            "Top 3" to "À lancer",
            "YT-Trend-Pulse" to "En développement",
            "Site RapSound" to "En développement"
        )
    }
}

private fun RapProjectEntity.toDomain() = RapProject(
    id = id,
    name = name,
    status = status,
    description = description,
    createdAt = Date(createdAt)
)
