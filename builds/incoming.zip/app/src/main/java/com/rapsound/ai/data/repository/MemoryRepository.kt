package com.rapsound.ai.data.repository

import com.rapsound.ai.data.local.LocalDatabase
import com.rapsound.ai.data.local.MemoryEntryEntity
import com.rapsound.ai.data.model.MemoryEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Date
import java.util.UUID

// Mémoire RapSound — §17-18 du cahier des charges.
// Principe : tout ce que l'utilisateur veut conserver reste mémorisé jusqu'à suppression
// explicite. Stockage 100% local (Room/SQLite) — plus de Firestore ni de compte requis.
class MemoryRepository {
    private val dao get() = LocalDatabase.database.memoryDao()

    fun observeMemory(category: String? = null): Flow<List<MemoryEntry>> {
        val entities = if (category == null) dao.observeAll() else dao.observeByCategory(category)
        return entities.map { list -> list.map { it.toDomain() } }
    }

    suspend fun addMemory(category: String, text: String) {
        val now = System.currentTimeMillis()
        dao.insert(
            MemoryEntryEntity(
                id = UUID.randomUUID().toString(),
                category = category,
                text = text,
                enabled = true,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun deleteMemory(memoryId: String) {
        // Suppression explicite : le souvenir ne doit plus jamais être réutilisé par l'IA (§18).
        dao.delete(memoryId)
    }

    suspend fun setEnabled(memoryId: String, enabled: Boolean) {
        dao.setEnabled(memoryId, enabled, System.currentTimeMillis())
    }

    // Pré-remplit la mémoire avec les faits déjà connus de RapSound au moment du
    // cahier des charges (§1 : l'app doit donner l'impression de connaître RapSound
    // depuis le début, pas repartir d'une mémoire vide). Reste modifiable/supprimable
    // ensuite comme n'importe quel autre souvenir (§18).
    suspend fun seedDefaultMemoryIfEmpty() {
        if (dao.count() > 0) return
        val now = System.currentTimeMillis()
        dao.insertAll(
            DEFAULT_MEMORY.map { (category, text) ->
                MemoryEntryEntity(
                    id = UUID.randomUUID().toString(),
                    category = category,
                    text = text,
                    enabled = true,
                    createdAt = now,
                    updatedAt = now
                )
            }
        )
    }

    companion object {
        val CATEGORIES = listOf(
            "Identité", "Objectifs", "Contenu", "Artistes", "Stratégie",
            "Statistiques", "Projets", "Outils", "Workflow", "Idées", "Préférences", "Historique"
        )

        val DEFAULT_MEMORY = listOf(
            "Identité" to "RapSound est une chaîne YouTube de rap français qui fait découvrir des " +
                "sons et fait participer les spectateurs pour créer une vraie communauté — pas " +
                "seulement pour l'argent.",
            "Identité" to "RapSound compte environ 792 abonnés (point de départ pour le suivi d'objectif).",
            "Historique" to "La chaîne est partie du doute \"suis-je capable d'avoir 100 abonnés ?\" et a " +
                "dépassé plusieurs centaines d'abonnés en environ un an.",
            "Objectifs" to "Objectif prioritaire : augmenter fortement la fréquence de publication " +
                "(actuellement environ 1 à 2 contenus toutes les deux semaines).",
            "Objectifs" to "Créneau de publication préféré : 17h-20h maximum.",
            "Objectifs" to "Viser le maximum de croissance plutôt qu'un nombre précis d'abonnés — ne " +
                "jamais promettre de date d'arrivée à un palier.",
            "Contenu" to "Format Dilemme : question ou choix qui fait réagir (commentaires, débat, engagement).",
            "Contenu" to "Format Blind Test : reconnaître morceaux/artistes — participation, rétention, découverte.",
            "Contenu" to "Format Blind dans le passé : anciens morceaux, nostalgie, touche plusieurs générations.",
            "Contenu" to "Format Ligue du son : compétition musicale, pensée comme une mécanique récurrente " +
                "transformable en série (règles, classements, votes, épisodes).",
            "Contenu" to "Format Top 3 (à venir) : ex. Top 3 sons de la semaine, Top 3 artistes, Top 3 découvertes.",
            "Artistes" to "Artiste préféré de RapSound : Gims — mais la chaîne ne doit pas s'y limiter.",
            "Artistes" to "Artistes de référence : PLK, Merveille, Dadju, SCH, JUL, Dr Yaro, La Mano.",
            "Artistes" to "La Mano représente à peu près le niveau plancher acceptable pour une suggestion d'artiste.",
            "Artistes" to "Équilibrer popularité, potentiel viral, actualité et intérêt pour plusieurs " +
                "générations — jamais un petit artiste juste parce qu'il est tendance.",
            "Stratégie" to "Ne jamais juger une vidéo réussie sur une seule métrique — vues, likes, " +
                "rétention, abonnés et commentaires s'évaluent ensemble.",
            "Stratégie" to "Priorité de l'utilisateur sur les métriques : les likes comptent beaucoup, la " +
                "rétention et les abonnés aussi.",
            "Stratégie" to "Ne jamais conseiller de contourner le copyright ou les règles YouTube — " +
                "signaler les risques et proposer une alternative légale.",
            "Outils" to "Canva : karaokés, vidéos longues, éléments graphiques, animations.",
            "Outils" to "CapCut : montage des Shorts, chroma key, rythme, finalisation.",
            "Outils" to "Remove.bg : suppression de fond, PNG transparents. GitHub : projets web/techniques " +
                "liés à RapSound. YouTube Studio : publication et statistiques.",
            "Outils" to "HTML/CSS/JS : animations personnalisées (ex. le podium animé en cours de développement).",
            "Workflow" to "Les deux points qui prennent le plus de temps : le montage, et la préparation " +
                "YouTube (titre/description/paramètres) — priorités d'automatisation.",
            "Workflow" to "Process Short résumé : idée → concept → montage CapCut → animations/fond vert si " +
                "besoin → recherche des sons → sélection → export → titre/description/publication → analyse.",
            "Workflow" to "Les vidéos longues sont davantage travaillées sur Canva, plus soignées et plus " +
                "développées que les Shorts.",
            "Préférences" to "L'utilisateur aime : animations, montage, création visuelle, réponses aux " +
                "commentaires, programmation, modélisation 3D, recherche d'idées — ne pas proposer de " +
                "sous-traiter ce qu'il sait déjà faire.",
            "Préférences" to "L'utilisateur n'aime pas : trouver le titre, rédiger la description, régler " +
                "les paramètres de publication.",
            "Projets" to "YT-Trend-Pulse : projet associé à RapSound pour automatiser la recherche de " +
                "sons et de tendances.",
            "Projets" to "Karaokés créés principalement avec Canva ; remixes spéciaux pour les abonnés " +
                "(ex. Damso sans Sarah Sey, PLK sans Théodora)."
        )
    }
}

private fun MemoryEntryEntity.toDomain() = MemoryEntry(
    id = id,
    category = category,
    text = text,
    enabled = enabled,
    createdAt = Date(createdAt),
    updatedAt = Date(updatedAt)
)
