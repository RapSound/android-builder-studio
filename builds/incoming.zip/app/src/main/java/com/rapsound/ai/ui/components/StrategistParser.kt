package com.rapsound.ai.ui.components

// Détecte et découpe une réponse "RapSound Strategist" (§24) en sections structurées :
// Diagnostic / Problèmes / Opportunités / Priorités / Plan d'action. Repose sur les
// intitulés demandés au fournisseur IA via SystemPromptBuilder ; si le modèle ne les a
// pas utilisés, `parse` renvoie null et le texte s'affiche normalement (dégradation
// silencieuse plutôt qu'un rendu cassé).
data class StrategistSections(
    val diagnostic: String?,
    val problemes: String?,
    val opportunites: String?,
    val priorites: String?,
    val planAction: String?
) {
    val isStructured: Boolean
        get() = listOfNotNull(diagnostic, problemes, opportunites, priorites, planAction).size >= 2
}

private val SECTION_HEADERS = listOf(
    "Diagnostic" to "diagnostic",
    "Problèmes" to "problemes",
    "Opportunités" to "opportunites",
    "Priorités" to "priorites",
    "Plan d'action" to "planAction"
)

object StrategistParser {
    fun parse(text: String): StrategistSections? {
        val values = mutableMapOf<String, String>()
        var currentKey: String? = null
        val buffer = StringBuilder()

        fun flush() {
            currentKey?.let { values[it] = buffer.toString().trim() }
            buffer.clear()
        }

        text.lines().forEach { rawLine ->
            val cleaned = rawLine.trim().trimStart('#', '*', '-', ' ').trimEnd(':', ' ')
            val match = SECTION_HEADERS.firstOrNull { (label, _) -> cleaned.equals(label, ignoreCase = true) }
            if (match != null) {
                flush()
                currentKey = match.second
            } else if (currentKey != null) {
                buffer.appendLine(rawLine)
            }
        }
        flush()

        if (values.size < 2) return null
        return StrategistSections(
            diagnostic = values["diagnostic"],
            problemes = values["problemes"],
            opportunites = values["opportunites"],
            priorites = values["priorites"],
            planAction = values["planAction"]
        )
    }
}
