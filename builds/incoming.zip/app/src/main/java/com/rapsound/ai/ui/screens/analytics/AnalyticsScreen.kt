package com.rapsound.ai.ui.screens.analytics

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

// §15 et §25 du cahier des charges — objectif abonnés (stockage local) + métriques clés.
// Les vues/abonnés basculent sur les vraies données YouTube dès que la clé + l'ID de
// chaîne sont renseignés dans Paramètres ; sinon l'app reste utilisable avec l'objectif
// stockage local seul (aucune dépendance bloquante à une clé externe, §34).
@Composable
fun AnalyticsScreen(viewModel: AnalyticsViewModel = viewModel()) {
    val goal by viewModel.subscriberGoal.collectAsState()
    val liveStats by viewModel.liveStats.collectAsState()
    val youtubeError by viewModel.youtubeError.collectAsState()

    val currentSubscribers = liveStats?.subscriberCount ?: goal.current
    val progress = if (goal.target > 0) currentSubscribers.toFloat() / goal.target.toFloat() else 0f

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Card {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Objectif ${goal.label.lowercase()}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                Text(
                    "$currentSubscribers / ${goal.target}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary
                )
                if (liveStats != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Donnée en direct depuis YouTube",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Rétention", "—", Modifier.weight(1f))
            MetricCard("Vues", liveStats?.viewCount?.toString() ?: "—", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Likes", "—", Modifier.weight(1f))
            MetricCard("Vidéos", liveStats?.videoCount?.toString() ?: "—", Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            youtubeError?.let { "Erreur YouTube : $it" }
                ?: if (liveStats == null)
                    "Renseigne ta clé API YouTube et l'ID de chaîne dans Paramètres pour afficher les données réelles."
                else
                    "Rétention et likes arriveront avec l'intégration YouTube Analytics (accès OAuth, §15).",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}
