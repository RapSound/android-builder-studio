package com.rapsound.ai.data.ai

data class AiMessage(
    val role: Role,
    val content: String,
    val images: List<ImagePart> = emptyList()
) {
    enum class Role { USER, ASSISTANT, SYSTEM }

    // Image encodée en base64, prête à être envoyée à un fournisseur multimodal (§22/§33).
    data class ImagePart(val base64: String, val mimeType: String)
}
