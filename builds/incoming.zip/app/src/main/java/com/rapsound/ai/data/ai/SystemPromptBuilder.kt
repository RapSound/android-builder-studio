package com.rapsound.ai.data.ai

import com.rapsound.ai.data.model.MemoryEntry
import com.rapsound.ai.data.model.SubscriberGoal

// Construit le prompt système à partir de l'identité RapSound + de la mémoire vivante
// stockée localement (§14 : exploiter automatiquement les données disponibles).
object SystemPromptBuilder {

    private val BASE_IDENTITY = """
        Tu es RapSound AI, le cerveau externe stratégique de la chaîne YouTube RapSound
        (rap français, formats : Dilemme, Blind Test, Blind dans le passé, Ligue du son, Top 3).
        Tu n'es pas un chatbot générique : tu connais l'historique, les objectifs et les
        méthodes de RapSound, et tu dois te comporter comme un vrai conseiller expert YouTube.
        Règles de personnalité :
        - Sois honnête, jamais complaisant. Si une idée est mauvaise, dis-le et explique pourquoi.
        - Propose des idées ambitieuses et concrètes, jamais génériques.
        - Ne juge jamais une vidéo sur une seule métrique.
        - Ne conseille jamais de contourner le copyright ou les règles YouTube.
    """.trimIndent()

    private val STRATEGIST_INSTRUCTIONS = """
        Mode RapSound Strategist activé (§24) : quand la question porte sur la stratégie
        globale de la chaîne, structure ta réponse avec ces sections précises : Diagnostic
        (ce qui fonctionne), Problèmes (ce qui ralentit RapSound), Opportunités (ce qui
        pourrait accélérer la croissance), Priorités (3 à 5 actions les plus importantes),
        Plan d'action (étapes concrètes).
    """.trimIndent()

    fun build(memory: List<MemoryEntry>, goal: SubscriberGoal?, strategistMode: Boolean = false): String {
        val memorySection = if (memory.isEmpty()) {
            "Aucun souvenir enregistré pour l'instant."
        } else {
            memory.joinToString("\n") { "- [${it.category}] ${it.text}" }
        }
        val goalSection = goal?.let { "${it.label} : ${it.current} / ${it.target}" }
            ?: "Objectif non défini."

        return buildString {
            appendLine(BASE_IDENTITY)
            appendLine()
            appendLine("Mémoire RapSound actuelle :")
            appendLine(memorySection)
            appendLine()
            appendLine("Objectif actuel :")
            appendLine(goalSection)
            if (strategistMode) {
                appendLine()
                appendLine(STRATEGIST_INSTRUCTIONS)
            }
        }
    }
}
