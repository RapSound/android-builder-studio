package com.rapsound.ai.ui.screens.chat

import android.app.Application
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rapsound.ai.data.ai.AiMessage
import com.rapsound.ai.data.ai.AiProvider
import com.rapsound.ai.data.ai.AiProviderRegistry
import com.rapsound.ai.data.ai.SystemPromptBuilder
import com.rapsound.ai.data.ai.local.LocalAiProvider
import com.rapsound.ai.data.model.ChatMessageDoc
import com.rapsound.ai.data.repository.AttachmentRepository
import com.rapsound.ai.data.repository.ConversationRepository
import com.rapsound.ai.data.repository.GoalRepository
import com.rapsound.ai.data.repository.MemoryRepository
import com.rapsound.ai.data.settings.ApiKeyStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Relie l'écran Conversation à la base locale Room (persistance, §21), aux pièces jointes
// (§22), et à la couche AI Provider en streaming (§33). Priorité absolue à l'IA locale
// (mission "IA locale") : le repli vers Gemini n'a jamais lieu en silence — voir
// resolveProvider() et fallbackNotice.
@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel @JvmOverloads constructor(
    application: Application,
    private val conversationRepository: ConversationRepository = ConversationRepository(),
    private val memoryRepository: MemoryRepository = MemoryRepository(),
    private val goalRepository: GoalRepository = GoalRepository(),
    private val attachmentRepository: AttachmentRepository = AttachmentRepository(),
    private val apiKeyStore: ApiKeyStore = ApiKeyStore(application)
) : AndroidViewModel(application) {

    private val _conversationId = MutableStateFlow<String?>(null)
    val conversationId: StateFlow<String?> = _conversationId

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending

    // Texte en cours de génération, affiché en direct dans une bulle temporaire tant que
    // la réponse n'est pas terminée et persistée en local (évite une écriture SQLite par
    // token, inutile et coûteux).
    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // Bannière explicite affichée quand le tour en cours utilise un fournisseur différent
    // de celui sélectionné (typiquement : repli local → Gemini). Jamais silencieux.
    private val _fallbackNotice = MutableStateFlow<String?>(null)
    val fallbackNotice: StateFlow<String?> = _fallbackNotice

    // Indicateur 🧠/☁️ du fournisseur ayant effectivement répondu au dernier tour.
    private val _lastProviderIsLocal = MutableStateFlow<Boolean?>(null)
    val lastProviderIsLocal: StateFlow<Boolean?> = _lastProviderIsLocal

    private var generationJob: Job? = null

    // Limite la fenêtre d'historique envoyée au fournisseur — surtout critique pour l'IA
    // locale, dont le contexte est fixe et fini (§PERFORMANCE : "limitation de la taille
    // du contexte"). Ce n'est pas un compte de tokens exact (pas de tokenizer côté
    // Kotlin), mais une borne raisonnable ; la limite fine reste gouvernée par la
    // "Taille du contexte" configurée dans Paramètres → IA locale.
    private val maxHistoryMessages = 20

    val messages: StateFlow<List<ChatMessageDoc>> = _conversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else conversationRepository.observeMessages(id).catch { emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun startNewConversation() {
        _conversationId.value = null
    }

    fun openConversation(id: String) {
        _conversationId.value = id
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        _streamingText.value = null
        _isSending.value = false
    }

    fun clearError() {
        _error.value = null
    }

    fun send(text: String, attachmentUris: List<Uri> = emptyList()) {
        if (text.isBlank() && attachmentUris.isEmpty()) return
        if (_isSending.value) return

        generationJob = viewModelScope.launch {
            _isSending.value = true
            _error.value = null
            _fallbackNotice.value = null
            _streamingText.value = ""

            runCatching {
                val id = _conversationId.value ?: conversationRepository
                    .createConversation(title = text.ifBlank { "Pièce jointe" }.take(60))
                    .also { _conversationId.value = it }

                val uploadedUrls = attachmentUris.map { uri ->
                    attachmentRepository.storeImage(getApplication(), id, uri)
                }
                val imageParts = encodeImages(attachmentUris)
                conversationRepository.addMessage(id, text, isFromUser = true, attachmentUrls = uploadedUrls)

                val memory = memoryRepository.observeMemory().first()
                val goal = runCatching { goalRepository.observeSubscriberGoal().first() }.getOrNull()
                val strategistMode = apiKeyStore.observeStrategistMode().first()
                val systemPrompt = SystemPromptBuilder.build(memory, goal, strategistMode)

                val history = messages.value.takeLast(maxHistoryMessages).map {
                    AiMessage(
                        role = if (it.isFromUser) AiMessage.Role.USER else AiMessage.Role.ASSISTANT,
                        content = it.text
                    )
                } + AiMessage(AiMessage.Role.USER, text, imageParts)

                val provider = resolveProvider()
                _lastProviderIsLocal.value = provider.isLocal

                val streamingEnabled = apiKeyStore.observeStreamingEnabled().first()
                val builder = StringBuilder()
                provider.sendMessageStream(history, systemPrompt).collect { chunk ->
                    builder.append(chunk)
                    if (streamingEnabled) {
                        _streamingText.value = builder.toString()
                    }
                }

                val finalText = builder.toString().ifBlank { "(réponse vide)" }
                conversationRepository.addMessage(id, finalText, isFromUser = false)
            }.onFailure { throwable ->
                if (throwable is CancellationException) throw throwable
                _error.value = throwable.message
            }

            _streamingText.value = null
            _isSending.value = false
        }
    }

    // Résout le fournisseur à utiliser pour ce tour. Si le fournisseur sélectionné est
    // l'IA locale mais que le modèle n'est pas installé, propose un repli vers Gemini
    // UNIQUEMENT si l'utilisateur l'a explicitement autorisé (Paramètres → IA) et qu'une
    // clé est configurée — jamais de bascule silencieuse (règle FALLBACK).
    private suspend fun resolveProvider(): AiProvider {
        val preferred = AiProviderRegistry.current
        if (preferred is LocalAiProvider && !preferred.isReady()) {
            val fallbackAllowed = apiKeyStore.observeGeminiFallbackEnabled().first()
            val geminiKey = apiKeyStore.observeKey(ApiKeyStore.GEMINI).first()
            if (fallbackAllowed && !geminiKey.isNullOrBlank()) {
                _fallbackNotice.value = "🧠 Modèle local non installé → repli vers ☁️ Gemini " +
                    "(ce message est envoyé à Google)."
                return AiProviderRegistry.providers.first { it.id == "gemini" }
            }
            throw LocalAiProvider.ModelNotInstalledException(preferred.currentModelSpec(null))
        }
        return preferred
    }

    private suspend fun encodeImages(uris: List<Uri>): List<AiMessage.ImagePart> = withContext(Dispatchers.IO) {
        val resolver = getApplication<Application>().contentResolver
        uris.mapNotNull { uri ->
            runCatching {
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("Impossible de lire la pièce jointe")
                val mimeType = resolver.getType(uri) ?: "image/jpeg"
                AiMessage.ImagePart(base64 = Base64.encodeToString(bytes, Base64.NO_WRAP), mimeType = mimeType)
            }.getOrNull()
        }
    }
}
