package com.rapsound.ai.data.ai.local

// Catalogue des modèles Qwen 3 quantifiés (GGUF, compatibles llama.cpp) — mission "IA
// locale". Tailles approximatives pour un quant Q4_K_M ; la taille réelle vient de
// l'en-tête HTTP au moment du téléchargement. Sources : dépôts publics Hugging Face
// "unsloth/Qwen3-*-GGUF" (vérifiés au 17/08/2026).
data class LocalModelSpec(
    val id: String,
    val displayName: String,
    val huggingFaceRepo: String,
    val fileName: String,
    val approxSizeBytes: Long,
    val recommendedMinRamGb: Int
) {
    val downloadUrl: String
        get() = "https://huggingface.co/$huggingFaceRepo/resolve/main/$fileName?download=true"
}

object ModelCatalog {
    val MODELS = listOf(
        LocalModelSpec(
            id = "qwen3-8b-q4",
            displayName = "Qwen 3 8B (Q4_K_M)",
            huggingFaceRepo = "unsloth/Qwen3-8B-GGUF",
            fileName = "Qwen3-8B-Q4_K_M.gguf",
            approxSizeBytes = 5_100_000_000L,
            recommendedMinRamGb = 8
        ),
        LocalModelSpec(
            id = "qwen3-4b-q4",
            displayName = "Qwen 3 4B (Q4_K_M)",
            huggingFaceRepo = "unsloth/Qwen3-4B-GGUF",
            fileName = "Qwen3-4B-Q4_K_M.gguf",
            approxSizeBytes = 2_600_000_000L,
            recommendedMinRamGb = 6
        ),
        LocalModelSpec(
            id = "qwen3-1_7b-q4",
            displayName = "Qwen 3 1.7B (Q4_K_M)",
            huggingFaceRepo = "unsloth/Qwen3-1.7B-GGUF",
            fileName = "Qwen3-1.7B-Q4_K_M.gguf",
            approxSizeBytes = 1_100_000_000L,
            recommendedMinRamGb = 4
        )
    )

    fun byId(id: String): LocalModelSpec? = MODELS.firstOrNull { it.id == id }
}
