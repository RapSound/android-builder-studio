package com.rapsound.ai.data.ai

import kotlinx.coroutines.flow.Flow

// Couche d'abstraction IA — §33 du cahier des charges.
// L'app ne doit jamais être verrouillée sur un seul fournisseur : chaque implémentation
// peut être échangée depuis l'écran Paramètres sans toucher au reste du code.
//
// isLocal distingue les fournisseurs qui tournent sur l'appareil (aucune donnée envoyée
// à l'extérieur) de ceux qui appellent une API distante — utilisé pour l'indicateur de
// confidentialité 🧠/☁️ dans l'UI et pour ne jamais basculer silencieusement de l'un à
// l'autre (règle de fallback du cahier des charges "IA locale").
interface AiProvider {
    val id: String
    val displayName: String
    val isFree: Boolean
    val isLocal: Boolean

    // Émet des fragments de texte au fur et à mesure de la génération (streaming).
    // Un provider qui ne supporte pas le vrai streaming peut émettre la réponse
    // complète en un seul élément (voir EchoAiProvider).
    fun sendMessageStream(history: List<AiMessage>, systemPrompt: String): Flow<String>
}
