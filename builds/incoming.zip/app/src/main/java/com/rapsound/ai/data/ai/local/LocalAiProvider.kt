package com.rapsound.ai.data.ai.local

import com.rapsound.ai.data.ai.AiMessage
import com.rapsound.ai.data.ai.AiProvider
import com.rapsound.ai.data.settings.ApiKeyStore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

// Fournisseur IA local — Qwen 3 quantifié via llama.cpp/JNI (mission "IA locale").
// Aucune donnée ne quitte l'appareil : isLocal = true. C'est le fournisseur PAR DÉFAUT
// (voir AiProviderRegistry) ; Gemini/OpenRouter/Mistral restent des choix explicites.
//
// Le contexte llama.cpp n'est pas thread-safe : toutes les opérations passent par un
// executor à un seul thread, réutilisé entre les messages pour éviter de recharger le
// modèle à chaque tour de conversation (§PERFORMANCE : chargement uniquement si nécessaire).
class LocalAiProvider(
    private val modelManager: ModelManager,
    private val apiKeyStore: ApiKeyStore
) : AiProvider {
    override val id = "local"
    override val displayName = "IA locale (Qwen 3)"
    override val isFree = true
    override val isLocal = true

    private val llamaDispatcher: CoroutineDispatcher =
        Executors.newSingleThreadExecutor { Thread(it, "rapsound-llama") }.asCoroutineDispatcher()

    @Volatile private var loadedHandle: Long = 0L
    @Volatile private var loadedModelId: String? = null

    class ModelNotInstalledException(val spec: LocalModelSpec) :
        IllegalStateException("Le modèle ${spec.displayName} n'est pas installé (Paramètres → IA)")

    class NativeLibraryMissingException : IllegalStateException(
        "La bibliothèque native rapsound_llama n'est pas disponible — le sous-module " +
            "llama.cpp doit être ajouté et le projet recompilé (voir app/src/main/cpp/README.md)."
    )

    fun currentModelSpec(modelId: String?): LocalModelSpec =
        modelId?.let { ModelCatalog.byId(it) } ?: ModelCatalog.MODELS.first()

    suspend fun isReady(): Boolean {
        val modelId = apiKeyStore.observeKey(ApiKeyStore.LOCAL_MODEL_ID).first()
        return modelManager.isInstalled(currentModelSpec(modelId))
    }

    override fun sendMessageStream(history: List<AiMessage>, systemPrompt: String): Flow<String> = callbackFlow {
        if (!LlamaBridge.ensureLoaded()) {
            close(NativeLibraryMissingException())
            return@callbackFlow
        }

        val modelId = apiKeyStore.observeKey(ApiKeyStore.LOCAL_MODEL_ID).first()
        val spec = currentModelSpec(modelId)
        if (!modelManager.isInstalled(spec)) {
            close(ModelNotInstalledException(spec))
            return@callbackFlow
        }

        val contextSize = apiKeyStore.observeKey(ApiKeyStore.LOCAL_CONTEXT_SIZE).first()?.toIntOrNull() ?: 4096
        val maxTokens = apiKeyStore.observeKey(ApiKeyStore.LOCAL_MAX_TOKENS).first()?.toIntOrNull() ?: 512
        val temperature = apiKeyStore.observeKey(ApiKeyStore.LOCAL_TEMPERATURE).first()?.toFloatOrNull() ?: 0.7f
        val thinkingMode = apiKeyStore.observeThinkingMode().first()

        val fullSystemPrompt = if (thinkingMode) systemPrompt else "$systemPrompt\n\n/no_think"
        val prompt = buildQwenChatPrompt(history, fullSystemPrompt)
        val cancelled = AtomicBoolean(false)

        withContext(llamaDispatcher) {
            try {
                if (loadedHandle == 0L || loadedModelId != spec.id) {
                    if (loadedHandle != 0L) LlamaBridge.freeModel(loadedHandle)
                    loadedHandle = LlamaBridge.loadModel(
                        modelManager.fileFor(spec).absolutePath,
                        contextSize,
                        Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
                    )
                    loadedModelId = spec.id
                }
                if (loadedHandle == 0L) {
                    close(IllegalStateException("Échec du chargement du modèle ${spec.displayName}"))
                    return@withContext
                }

                LlamaBridge.generate(loadedHandle, prompt, maxTokens, temperature) { token ->
                    if (cancelled.get()) {
                        false
                    } else {
                        trySend(token).isSuccess
                    }
                }
                close()
            } catch (t: Throwable) {
                close(t)
            }
        }

        // callbackFlow attend cette fermeture pour propager l'annulation côté Kotlin ;
        // le flag est lu par le callback natif (voir plus haut) pour arrêter la boucle
        // de génération côté C++ dès le prochain token (annulation, §PERFORMANCE).
        awaitClose { cancelled.set(true) }
    }

    // Libère le modèle chargé (RAM) — à appeler en changeant/supprimant le modèle actif,
    // ou quand l'app passe longtemps en arrière-plan.
    fun unload() {
        if (loadedHandle != 0L) {
            LlamaBridge.freeModel(loadedHandle)
            loadedHandle = 0L
            loadedModelId = null
        }
    }

    // Qwen 3 utilise un gabarit de chat façon ChatML.
    private fun buildQwenChatPrompt(history: List<AiMessage>, systemPrompt: String): String = buildString {
        append("<|im_start|>system\n").append(systemPrompt).append("<|im_end|>\n")
        history.forEach { message ->
            val role = if (message.role == AiMessage.Role.USER) "user" else "assistant"
            append("<|im_start|>").append(role).append("\n").append(message.content).append("<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }
}
