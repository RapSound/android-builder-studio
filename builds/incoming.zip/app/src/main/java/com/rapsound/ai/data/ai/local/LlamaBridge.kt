package com.rapsound.ai.data.ai.local

// Pont JNI vers llama.cpp — implémentation native dans
// app/src/main/cpp/llama-bridge.cpp (voir app/src/main/cpp/README.md pour l'intégration
// du sous-module llama.cpp, non fourni ici : dépôt C++ tiers volumineux).
//
// Toutes les fonctions sont bloquantes côté natif : LocalAiProvider les appelle depuis un
// thread dédié unique (le contexte llama.cpp n'est pas thread-safe, §PERFORMANCE).
object LlamaBridge {
    private var libraryLoaded = false

    // Le chargement est protégé par try/catch : tant que la lib native n'est pas
    // compilée (sous-module llama.cpp absent), l'app doit rester utilisable avec les
    // autres fournisseurs plutôt que planter au démarrage.
    fun ensureLoaded(): Boolean {
        if (libraryLoaded) return true
        return runCatching {
            System.loadLibrary("rapsound_llama")
            libraryLoaded = true
            true
        }.getOrElse { false }
    }

    // Charge un modèle GGUF depuis un chemin de fichier absolu. Retourne un handle natif
    // (pointeur opaque vers modèle + contexte) à réutiliser pour les appels suivants,
    // ou 0L en cas d'échec.
    external fun loadModel(modelPath: String, contextSize: Int, nThreads: Int): Long

    // Libère le modèle et son contexte (rend la RAM). À appeler quand le modèle change,
    // est supprimé, ou que l'app passe longtemps en arrière-plan.
    external fun freeModel(handle: Long)

    // Lance une génération à partir d'un prompt déjà formaté avec le gabarit de chat Qwen
    // (voir LocalAiProvider.buildQwenChatPrompt). `onToken` est appelé depuis le thread
    // natif pour chaque fragment de texte généré ; retourner `false` interrompt la
    // génération immédiatement (utilisé pour l'annulation).
    external fun generate(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        onToken: (String) -> Boolean
    )
}
