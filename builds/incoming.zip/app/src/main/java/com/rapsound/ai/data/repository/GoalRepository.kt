package com.rapsound.ai.data.repository

import com.rapsound.ai.data.local.LocalDatabase
import com.rapsound.ai.data.local.SubscriberGoalEntity
import com.rapsound.ai.data.model.SubscriberGoal
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Suivi de l'objectif abonnés — §25-26 du cahier des charges. Stockage 100% local.
class GoalRepository {
    private val dao get() = LocalDatabase.database.goalDao()

    fun observeSubscriberGoal(): Flow<SubscriberGoal> =
        dao.observe().map { it?.toDomain() ?: SubscriberGoal(id = "subscribers", label = "Abonnés", current = 792, target = 1000) }

    suspend fun seedIfMissing() {
        if (dao.count() > 0) return
        dao.insert(SubscriberGoalEntity(id = "subscribers", label = "Abonnés", current = 792, target = 1000))
    }
}

private fun SubscriberGoalEntity.toDomain() = SubscriberGoal(
    id = id,
    label = label,
    current = current,
    target = target
)
