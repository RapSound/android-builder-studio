package com.rapsound.ai.data.ai

import android.content.Context
import com.rapsound.ai.data.ai.local.LocalAiProvider
import com.rapsound.ai.data.ai.local.ModelManager
import com.rapsound.ai.data.settings.ApiKeyStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// Registre des fournisseurs disponibles (§33). Priorité absolue : IA locale > Gemini
// (mission "IA locale") — LocalAiProvider est sélectionné par défaut et le choix persiste
// (DataStore) tant que l'utilisateur ne change pas explicitement de fournisseur dans
// Paramètres. Rien ici ne bascule jamais silencieusement vers un fournisseur distant.
object AiProviderRegistry {
    private val echo = EchoAiProvider()
    private lateinit var apiKeyStore: ApiKeyStore
    private lateinit var localProvider: LocalAiProvider
    private lateinit var modelManager: ModelManager
    private val registryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val providers: List<AiProvider> by lazy {
        listOf(
            localProvider,
            GeminiProvider(apiKeyProvider = { apiKeyStore.observeKey(ApiKeyStore.GEMINI).first() }),
            OpenAiCompatibleProvider(
                id = ApiKeyStore.OPENROUTER,
                displayName = "OpenRouter",
                endpoint = "https://openrouter.ai/api/v1/chat/completions",
                model = "openai/gpt-4o-mini",
                apiKeyProvider = { apiKeyStore.observeKey(ApiKeyStore.OPENROUTER).first() }
            ),
            OpenAiCompatibleProvider(
                id = ApiKeyStore.MISTRAL,
                displayName = "Mistral AI",
                endpoint = "https://api.mistral.ai/v1/chat/completions",
                model = "mistral-large-latest",
                apiKeyProvider = { apiKeyStore.observeKey(ApiKeyStore.MISTRAL).first() }
            ),
            echo
        )
    }

    var current: AiProvider = echo
        private set

    fun init(context: Context) {
        apiKeyStore = ApiKeyStore(context.applicationContext)
        modelManager = ModelManager(context.applicationContext)
        localProvider = LocalAiProvider(modelManager, apiKeyStore)
        current = localProvider // priorité absolue : IA locale par défaut

        registryScope.launch {
            val savedId = apiKeyStore.observeKey(ApiKeyStore.ACTIVE_PROVIDER_ID).first()
            if (savedId != null) {
                providers.firstOrNull { it.id == savedId }?.let { current = it }
            }
        }
    }

    fun select(providerId: String) {
        providers.firstOrNull { it.id == providerId }?.let { provider ->
            current = provider
            registryScope.launch { apiKeyStore.setKey(ApiKeyStore.ACTIVE_PROVIDER_ID, providerId) }
        }
    }

    fun localProviderInstance(): LocalAiProvider = localProvider
    fun modelManagerInstance(): ModelManager = modelManager
}
