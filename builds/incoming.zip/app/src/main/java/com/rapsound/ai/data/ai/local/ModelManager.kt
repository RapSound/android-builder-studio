package com.rapsound.ai.data.ai.local

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.job
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

sealed class DownloadState {
    data class Progress(val downloadedBytes: Long, val totalBytes: Long) : DownloadState()
    data object Verifying : DownloadState()
    data object Done : DownloadState()
    data class Failed(val message: String) : DownloadState()
}

// Installation / vérification / suppression des modèles GGUF en local (mission "IA
// locale", §📦 MODÈLE). Stocke les modèles dans le stockage privé de l'app
// (files/models/) — aucune permission Android requise. Le téléchargement initial
// nécessite Internet ; une fois le fichier présent et vérifié, LocalAiProvider ne fait
// plus aucun appel réseau (§MODE HORS-LIGNE).
class ModelManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun modelsDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    fun fileFor(spec: LocalModelSpec): File = File(modelsDir(), spec.fileName)

    fun isInstalled(spec: LocalModelSpec): Boolean {
        val file = fileFor(spec)
        return file.exists() && file.length() > 0 && looksLikeGguf(file)
    }

    fun installedModels(): List<LocalModelSpec> = ModelCatalog.MODELS.filter { isInstalled(it) }

    fun delete(spec: LocalModelSpec) {
        fileFor(spec).delete()
    }

    // Supprime un téléchargement partiel — appelé sur annulation, pour ne pas laisser
    // un fichier ".part" de plusieurs Go traîner sur le disque sans jamais être terminé.
    fun deletePartial(spec: LocalModelSpec) {
        File(modelsDir(), "${spec.fileName}.part").delete()
    }

    // Vérifie la signature "GGUF" en tête de fichier — détection basique d'un fichier
    // corrompu/tronqué, sans dépendre d'un hash externe qui pourrait changer avec le dépôt.
    private fun looksLikeGguf(file: File): Boolean = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            val magic = ByteArray(4)
            raf.readFully(magic)
            magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46)) // "GGUF"
        }
    }.getOrDefault(false)

    fun download(spec: LocalModelSpec): Flow<DownloadState> = flow {
        val target = fileFor(spec)
        val tmp = File(modelsDir(), "${spec.fileName}.part")

        val request = Request.Builder().url(spec.downloadUrl).build()
        val call = client.newCall(request)

        // Un modèle GGUF fait plusieurs Go : sans ceci, annuler la coroutine (bouton
        // "Annuler" côté UI) ne libère pas immédiatement la connexion — le socket OkHttp
        // continuerait de lire en arrière-plan jusqu'à la fin du fichier. En reliant
        // explicitement call.cancel() à la fin du Job, la lecture bloquante est
        // interrompue au prochain octet plutôt qu'à la fin du téléchargement.
        currentCoroutineContext().job.invokeOnCompletion { cause ->
            if (cause is CancellationException) call.cancel()
        }

        call.execute().use { response ->
            if (!response.isSuccessful) {
                emit(DownloadState.Failed("Téléchargement échoué : HTTP ${response.code}"))
                return@flow
            }
            val body = response.body
            if (body == null) {
                emit(DownloadState.Failed("Réponse vide"))
                return@flow
            }
            val totalBytes = body.contentLength().let { if (it > 0) it else spec.approxSizeBytes }
            var downloaded = 0L
            var lastEmit = 0L

            tmp.outputStream().use { output ->
                body.byteStream().use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        downloaded += read
                        // Limite la fréquence d'émission pour ne pas saturer la recomposition UI.
                        if (downloaded - lastEmit > 512 * 1024) {
                            emit(DownloadState.Progress(downloaded, totalBytes))
                            lastEmit = downloaded
                        }
                    }
                }
            }
            emit(DownloadState.Progress(downloaded, totalBytes))
        }

        emit(DownloadState.Verifying)
        if (!looksLikeGguf(tmp)) {
            tmp.delete()
            emit(DownloadState.Failed("Fichier téléchargé invalide (en-tête GGUF absent)"))
            return@flow
        }
        target.delete()
        tmp.renameTo(target)
        emit(DownloadState.Done)
    }.flowOn(Dispatchers.IO)
}
