package com.rapsound.ai.ui.screens.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rapsound.ai.data.model.RapProject
import com.rapsound.ai.data.repository.ProjectRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProjectsViewModel @JvmOverloads constructor(
    private val repository: ProjectRepository = ProjectRepository()
) : ViewModel() {

    val projects: StateFlow<List<RapProject>> = repository.observeProjects()
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            runCatching { repository.seedDefaultProjectsIfEmpty() }
        }
    }

    fun updateProject(projectId: String, description: String, status: String) {
        viewModelScope.launch {
            runCatching { repository.updateProject(projectId, description, status) }
        }
    }
}
