package com.rapsound.ai.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        MemoryEntryEntity::class,
        RapProjectEntity::class,
        ConversationEntity::class,
        ChatMessageEntity::class,
        SubscriberGoalEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RapSoundDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun projectDao(): ProjectDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun goalDao(): GoalDao
}
