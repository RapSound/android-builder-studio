package com.rapsound.ai.ui.screens.analytics

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rapsound.ai.data.model.SubscriberGoal
import com.rapsound.ai.data.repository.GoalRepository
import com.rapsound.ai.data.repository.YouTubeChannelStats
import com.rapsound.ai.data.repository.YouTubeRepository
import com.rapsound.ai.data.settings.ApiKeyStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val DEFAULT_GOAL = SubscriberGoal(label = "Abonnés", current = 792, target = 1000)

// §15 et §25 : objectif abonnés (stockage local) + statistiques YouTube réelles dès que la clé
// API + l'ID de chaîne sont renseignés dans Paramètres (§35 : jamais codés en dur ici).
class AnalyticsViewModel @JvmOverloads constructor(
    application: Application,
    private val goalRepository: GoalRepository = GoalRepository(),
    private val youTubeRepository: YouTubeRepository = YouTubeRepository(),
    private val apiKeyStore: ApiKeyStore = ApiKeyStore(application)
) : AndroidViewModel(application) {

    val subscriberGoal: StateFlow<SubscriberGoal> = goalRepository.observeSubscriberGoal()
        .catch { emit(DEFAULT_GOAL) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DEFAULT_GOAL)

    private val _liveStats = MutableStateFlow<YouTubeChannelStats?>(null)
    val liveStats: StateFlow<YouTubeChannelStats?> = _liveStats

    private val _youtubeError = MutableStateFlow<String?>(null)
    val youtubeError: StateFlow<String?> = _youtubeError

    init {
        viewModelScope.launch {
            runCatching { goalRepository.seedIfMissing() }
        }
        refreshYouTubeStats()
    }

    fun refreshYouTubeStats() {
        viewModelScope.launch {
            val apiKey = apiKeyStore.observeKey(ApiKeyStore.YOUTUBE_API_KEY).first()
            val channelId = apiKeyStore.observeKey(ApiKeyStore.YOUTUBE_CHANNEL_ID).first()
            if (apiKey.isNullOrBlank() || channelId.isNullOrBlank()) {
                _liveStats.value = null
                return@launch
            }
            youTubeRepository.fetchChannelStats(channelId, apiKey)
                .onSuccess {
                    _liveStats.value = it
                    _youtubeError.value = null
                }
                .onFailure { _youtubeError.value = it.message }
        }
    }
}
