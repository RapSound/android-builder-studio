package com.rapsound.ai.data.repository

import com.rapsound.ai.data.local.ChatMessageEntity
import com.rapsound.ai.data.local.ConversationEntity
import com.rapsound.ai.data.local.LocalDatabase
import com.rapsound.ai.data.model.ChatMessageDoc
import com.rapsound.ai.data.model.ConversationSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Date
import java.util.UUID

// Conversations persistantes — §21 du cahier des charges. Stockage 100% local
// (Room/SQLite) — la suppression en cascade des messages est gérée nativement par SQLite
// (ON DELETE CASCADE, voir data/local/Entities.kt) au lieu d'une boucle manuelle.
class ConversationRepository {
    private val dao get() = LocalDatabase.database.conversationDao()
    private val messageDao get() = LocalDatabase.database.messageDao()

    fun observeConversations(): Flow<List<ConversationSummary>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    fun observeConversationsForProject(projectId: String): Flow<List<ConversationSummary>> =
        dao.observeForProject(projectId).map { list -> list.map { it.toDomain() } }

    fun observeMessages(conversationId: String): Flow<List<ChatMessageDoc>> =
        messageDao.observeMessages(conversationId).map { list -> list.map { it.toDomain() } }

    suspend fun createConversation(title: String): String {
        val id = UUID.randomUUID().toString()
        dao.insert(
            ConversationEntity(
                id = id,
                title = title,
                projectId = "",
                projectName = "",
                favorite = false,
                archived = false,
                lastMessagePreview = "",
                updatedAt = System.currentTimeMillis()
            )
        )
        return id
    }

    suspend fun addMessage(
        conversationId: String,
        text: String,
        isFromUser: Boolean,
        attachmentUrls: List<String> = emptyList()
    ) {
        messageDao.insert(
            ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                text = text,
                isFromUser = isFromUser,
                attachmentPaths = attachmentUrls.joinToString(","),
                createdAt = System.currentTimeMillis()
            )
        )
        dao.touch(conversationId, text.take(120), System.currentTimeMillis())
    }

    suspend fun renameConversation(conversationId: String, title: String) {
        dao.rename(conversationId, title)
    }

    suspend fun setProject(conversationId: String, projectId: String, projectName: String) {
        dao.setProject(conversationId, projectId, projectName)
    }

    suspend fun clearProject(conversationId: String) {
        dao.setProject(conversationId, "", "")
    }

    suspend fun deleteConversation(conversationId: String) {
        dao.delete(conversationId)
    }

    suspend fun setFavorite(conversationId: String, favorite: Boolean) {
        dao.setFavorite(conversationId, favorite)
    }

    suspend fun archive(conversationId: String) {
        dao.archive(conversationId)
    }
}

private fun ConversationEntity.toDomain() = ConversationSummary(
    id = id,
    title = title,
    projectId = projectId,
    projectName = projectName,
    favorite = favorite,
    archived = archived,
    lastMessagePreview = lastMessagePreview,
    updatedAt = Date(updatedAt)
)

private fun ChatMessageEntity.toDomain() = ChatMessageDoc(
    id = id,
    text = text,
    isFromUser = isFromUser,
    attachmentUrls = if (attachmentPaths.isBlank()) emptyList() else attachmentPaths.split(","),
    createdAt = Date(createdAt)
)
