package com.rapsound.ai.ui.screens.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rapsound.ai.data.model.ConversationSummary
import com.rapsound.ai.data.model.RapProject
import com.rapsound.ai.data.repository.AttachmentRepository
import com.rapsound.ai.data.repository.ConversationRepository
import com.rapsound.ai.data.repository.ProjectRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// §21 du cahier des charges : renommer, supprimer, rechercher, mettre en favoris,
// archiver, classer par projet.
class HistoryViewModel @JvmOverloads constructor(
    application: Application,
    private val repository: ConversationRepository = ConversationRepository(),
    private val projectRepository: ProjectRepository = ProjectRepository(),
    private val attachmentRepository: AttachmentRepository = AttachmentRepository()
) : AndroidViewModel(application) {

    val conversations: StateFlow<List<ConversationSummary>> = repository.observeConversations()
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projects: StateFlow<List<RapProject>> = projectRepository.observeProjects()
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleFavorite(id: String, favorite: Boolean) {
        viewModelScope.launch { runCatching { repository.setFavorite(id, favorite) } }
    }

    fun rename(id: String, title: String) {
        if (title.isBlank()) return
        viewModelScope.launch { runCatching { repository.renameConversation(id, title) } }
    }

    fun archive(id: String) {
        viewModelScope.launch { runCatching { repository.archive(id) } }
    }

    // Supprime la conversation ET ses pièces jointes sur disque — sans ce deuxième
    // appel, les images resteraient orphelines dans le stockage interne indéfiniment
    // (rien d'autre ne les référence une fois la conversation effacée).
    fun delete(id: String) {
        viewModelScope.launch {
            runCatching {
                repository.deleteConversation(id)
                attachmentRepository.deleteConversationAttachments(getApplication(), id)
            }
        }
    }

    fun assignProject(id: String, project: RapProject?) {
        viewModelScope.launch {
            runCatching {
                if (project == null) repository.clearProject(id)
                else repository.setProject(id, project.id, project.name)
            }
        }
    }
}
