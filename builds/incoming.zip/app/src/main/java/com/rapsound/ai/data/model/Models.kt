package com.rapsound.ai.data.model

import java.util.Date

// Modèles de domaine — stockés 100% localement (Room/SQLite), voir data/local/Entities.kt
// pour le schéma physique et les repositories correspondants pour le mapping :
//   MemoryEntry        -> MemoryRepository        (§17-18)
//   RapProject         -> ProjectRepository        (§19)
//   SubscriberGoal      -> GoalRepository           (§25-26)
//   ConversationSummary  -> ConversationRepository    (§21)
//   ChatMessageDoc         -> ConversationRepository     (sous-collection messages)

data class MemoryEntry(
    val id: String = "",
    val category: String = "",
    val text: String = "",
    val enabled: Boolean = true,
    val createdAt: Date? = null,
    val updatedAt: Date? = null
)

data class RapProject(
    val id: String = "",
    val name: String = "",
    val status: String = "",
    val description: String = "",
    val createdAt: Date? = null
)

data class ConversationSummary(
    val id: String = "",
    val title: String = "",
    val projectId: String = "",
    val projectName: String = "",
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val lastMessagePreview: String = "",
    val updatedAt: Date? = null
)

data class ChatMessageDoc(
    val id: String = "",
    val text: String = "",
    val isFromUser: Boolean = false,
    val attachmentUrls: List<String> = emptyList(),
    val createdAt: Date? = null
)

data class SubscriberGoal(
    val id: String = "",
    val label: String = "Abonnés",
    val current: Long = 792,
    val target: Long = 1000
)
