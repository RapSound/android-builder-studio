package com.rapsound.ai.ui.screens.projects

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rapsound.ai.data.model.ConversationSummary
import com.rapsound.ai.data.model.RapProject
import com.rapsound.ai.data.repository.ConversationRepository

private val PROJECT_STATUSES = listOf(
    "Actif", "En préparation", "À lancer", "En développement", "En pause", "Terminé"
)

// §19 du cahier des charges — arborescence de projets RapSound, stockage 100% local (Room).
// Un tap ouvre le détail : description/statut éditables + conversations liées (§21).
@Composable
fun ProjectsScreen(
    viewModel: ProjectsViewModel = viewModel(),
    onOpenConversation: (String) -> Unit = {}
) {
    val projects by viewModel.projects.collectAsState()
    var selectedProject by remember { mutableStateOf<RapProject?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(projects, key = { it.id }) { project ->
            Card(modifier = Modifier.clickable { selectedProject = project }) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(project.name, style = MaterialTheme.typography.bodyLarge)
                        if (project.description.isNotBlank()) {
                            Text(
                                project.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    AssistChip(onClick = { selectedProject = project }, label = { Text(project.status) })
                }
            }
        }
    }

    selectedProject?.let { project ->
        ProjectDetailDialog(
            project = project,
            onDismiss = { selectedProject = null },
            onSave = { description, status -> viewModel.updateProject(project.id, description, status) },
            onOpenConversation = { id ->
                selectedProject = null
                onOpenConversation(id)
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectDetailDialog(
    project: RapProject,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
    onOpenConversation: (String) -> Unit
) {
    var description by remember(project.id) { mutableStateOf(project.description) }
    var status by remember(project.id) { mutableStateOf(project.status) }
    var statusMenuExpanded by remember { mutableStateOf(false) }

    val conversationRepository = remember { ConversationRepository() }
    val linkedConversations by produceState(
        initialValue = emptyList<ConversationSummary>(),
        key1 = project.id
    ) {
        conversationRepository.observeConversationsForProject(project.id).collect { value = it }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(project.name) },
        text = {
            Column {
                ExposedDropdownMenuBox(
                    expanded = statusMenuExpanded,
                    onExpandedChange = { statusMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = status,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Statut") },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    androidx.compose.material3.ExposedDropdownMenu(
                        expanded = statusMenuExpanded,
                        onDismissRequest = { statusMenuExpanded = false }
                    ) {
                        PROJECT_STATUSES.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = { status = option; statusMenuExpanded = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / notes") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                if (linkedConversations.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    Text("Conversations liées", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    linkedConversations.forEach { conversation ->
                        Text(
                            "• ${conversation.title}",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenConversation(conversation.id) }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(description, status); onDismiss() }) {
                Text("Enregistrer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Fermer") }
        }
    )
}
