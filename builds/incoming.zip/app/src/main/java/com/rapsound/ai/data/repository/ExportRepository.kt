package com.rapsound.ai.data.repository

import com.rapsound.ai.data.local.ChatMessageEntity
import com.rapsound.ai.data.local.ConversationEntity
import com.rapsound.ai.data.local.LocalDatabase
import com.rapsound.ai.data.local.MemoryEntryEntity
import com.rapsound.ai.data.local.RapProjectEntity
import com.rapsound.ai.data.local.SubscriberGoalEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// Export/import JSON de toutes les données locales — filet de sécurité pour le
// stockage 100% local (voir CHECKLIST_PROFESSIONNALISATION.md, "Export / sauvegarde des
// données") : si le téléphone est perdu/changé sans ça, tout disparaît sans recours.
//
// Les pièces jointes (fichiers image) ne sont PAS incluses dans l'export — seuls les
// chemins sont conservés à titre indicatif — pour garder le fichier JSON léger et
// portable par email/Drive/etc.
class ExportRepository {
    private val db get() = LocalDatabase.database

    suspend fun exportToJson(): String = withContext(Dispatchers.IO) {
        val memory = db.memoryDao().observeAll().first()
        val projects = db.projectDao().observeAll().first()
        val conversations = db.conversationDao().observeAll().first()
        val goal = db.goalDao().observe().first()

        val root = JSONObject().apply {
            put("exportVersion", 1)
            put("exportedAt", System.currentTimeMillis())

            put("memory", JSONArray(memory.map { e ->
                JSONObject().apply {
                    put("category", e.category)
                    put("text", e.text)
                    put("enabled", e.enabled)
                    put("createdAt", e.createdAt)
                    put("updatedAt", e.updatedAt)
                }
            }))

            put("projects", JSONArray(projects.map { p ->
                JSONObject().apply {
                    put("name", p.name)
                    put("status", p.status)
                    put("description", p.description)
                    put("createdAt", p.createdAt)
                }
            }))

            val conversationsArray = JSONArray()
            for (c in conversations) {
                val messages = db.messageDao().observeMessages(c.id).first()
                conversationsArray.put(
                    JSONObject().apply {
                        put("title", c.title)
                        put("favorite", c.favorite)
                        put("archived", c.archived)
                        put("lastMessagePreview", c.lastMessagePreview)
                        put("updatedAt", c.updatedAt)
                        put("messages", JSONArray(messages.map { m ->
                            JSONObject().apply {
                                put("text", m.text)
                                put("isFromUser", m.isFromUser)
                                put("createdAt", m.createdAt)
                                // Indicatif seulement — les fichiers ne sont pas réimportables.
                                put("attachmentPaths", m.attachmentPaths)
                            }
                        }))
                    }
                )
            }
            put("conversations", conversationsArray)

            goal?.let {
                put("goal", JSONObject().apply {
                    put("label", it.label)
                    put("current", it.current)
                    put("target", it.target)
                })
            }
        }

        root.toString(2)
    }

    data class ImportResult(val memoryEntries: Int, val projects: Int, val conversations: Int)

    // Import additif : chaque entrée reçoit un nouvel identifiant (UUID), donc aucun
    // conflit possible avec les données déjà présentes — l'import n'écrase jamais rien,
    // sauf l'objectif abonnés (clé fixe "subscribers", volontairement écrasé).
    suspend fun importFromJson(json: String): ImportResult = withContext(Dispatchers.IO) {
        val root = JSONObject(json)
        val now = System.currentTimeMillis()
        var memoryCount = 0
        var projectCount = 0
        var conversationCount = 0

        root.optJSONArray("memory")?.let { array ->
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                db.memoryDao().insert(
                    MemoryEntryEntity(
                        id = UUID.randomUUID().toString(),
                        category = obj.getString("category"),
                        text = obj.getString("text"),
                        enabled = obj.optBoolean("enabled", true),
                        createdAt = obj.optLong("createdAt", now),
                        updatedAt = obj.optLong("updatedAt", now)
                    )
                )
                memoryCount++
            }
        }

        root.optJSONArray("projects")?.let { array ->
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                db.projectDao().insertAll(
                    listOf(
                        RapProjectEntity(
                            id = UUID.randomUUID().toString(),
                            name = obj.getString("name"),
                            status = obj.optString("status", ""),
                            description = obj.optString("description", ""),
                            createdAt = obj.optLong("createdAt", now)
                        )
                    )
                )
                projectCount++
            }
        }

        root.optJSONArray("conversations")?.let { array ->
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val newConversationId = UUID.randomUUID().toString()
                db.conversationDao().insert(
                    ConversationEntity(
                        id = newConversationId,
                        title = obj.getString("title"),
                        // Les projets ont de nouveaux id après import : pas de
                        // ré-association automatique (l'utilisateur peut la refaire
                        // manuellement depuis Historique, §21).
                        projectId = "",
                        projectName = "",
                        favorite = obj.optBoolean("favorite", false),
                        archived = obj.optBoolean("archived", false),
                        lastMessagePreview = obj.optString("lastMessagePreview", ""),
                        updatedAt = obj.optLong("updatedAt", now)
                    )
                )
                obj.optJSONArray("messages")?.let { messages ->
                    for (j in 0 until messages.length()) {
                        val m = messages.getJSONObject(j)
                        db.messageDao().insert(
                            ChatMessageEntity(
                                id = UUID.randomUUID().toString(),
                                conversationId = newConversationId,
                                text = m.getString("text"),
                                isFromUser = m.optBoolean("isFromUser", false),
                                attachmentPaths = "", // fichiers non réimportés (non inclus dans l'export)
                                createdAt = m.optLong("createdAt", now)
                            )
                        )
                    }
                }
                conversationCount++
            }
        }

        root.optJSONObject("goal")?.let { obj ->
            db.goalDao().insert(
                SubscriberGoalEntity(
                    id = "subscribers",
                    label = obj.optString("label", "Abonnés"),
                    current = obj.optLong("current", 0),
                    target = obj.optLong("target", 1000)
                )
            )
        }

        ImportResult(memoryCount, projectCount, conversationCount)
    }
}
