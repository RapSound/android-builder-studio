package com.rapsound.ai.data.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "rapsound_settings")

// Stockage local des clés API et préférences — jamais codées en dur dans le code (§35).
// Les clés (Gemini/OpenRouter/Mistral/YouTube) sont saisies depuis Paramètres, une fois
// fournies, et ne quittent jamais l'appareil (DataStore local, pas de Firestore).
class ApiKeyStore(private val context: Context) {

    fun observeKey(providerId: String): Flow<String?> =
        context.settingsDataStore.data.map { it[keyFor(providerId)] }

    suspend fun setKey(providerId: String, value: String) {
        context.settingsDataStore.edit { it[keyFor(providerId)] = value }
    }

    fun observeStrategistMode(): Flow<Boolean> =
        context.settingsDataStore.data.map { it[STRATEGIST_MODE] ?: false }

    suspend fun setStrategistMode(enabled: Boolean) {
        context.settingsDataStore.edit { it[STRATEGIST_MODE] = enabled }
    }

    // Mode réflexion Qwen 3 (§ IA locale) : désactivé par défaut pour des réponses plus
    // rapides sur mobile ("/no_think"). L'utilisateur peut l'activer pour un raisonnement
    // plus poussé au prix de la latence.
    fun observeThinkingMode(): Flow<Boolean> =
        context.settingsDataStore.data.map { it[LOCAL_THINKING_MODE] ?: false }

    suspend fun setThinkingMode(enabled: Boolean) {
        context.settingsDataStore.edit { it[LOCAL_THINKING_MODE] = enabled }
    }

    // Autorise (ou non) le repli automatique vers Gemini quand le modèle local n'est pas
    // installé — désactivé par défaut : jamais de bascule silencieuse (§ FALLBACK).
    fun observeGeminiFallbackEnabled(): Flow<Boolean> =
        context.settingsDataStore.data.map { it[GEMINI_FALLBACK_ENABLED] ?: false }

    suspend fun setGeminiFallbackEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[GEMINI_FALLBACK_ENABLED] = enabled }
    }

    // Streaming des tokens (§ PERFORMANCE) : activé par défaut, peut être coupé si
    // l'utilisateur préfère attendre la réponse complète.
    fun observeStreamingEnabled(): Flow<Boolean> =
        context.settingsDataStore.data.map { it[STREAMING_ENABLED] ?: true }

    suspend fun setStreamingEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[STREAMING_ENABLED] = enabled }
    }

    private fun keyFor(providerId: String) = stringPreferencesKey("api_key_$providerId")

    companion object {
        private val STRATEGIST_MODE = booleanPreferencesKey("strategist_mode")
        private val LOCAL_THINKING_MODE = booleanPreferencesKey("local_thinking_mode")
        private val GEMINI_FALLBACK_ENABLED = booleanPreferencesKey("gemini_fallback_enabled")
        private val STREAMING_ENABLED = booleanPreferencesKey("streaming_enabled")

        const val GEMINI = "gemini"
        const val OPENROUTER = "openrouter"
        const val MISTRAL = "mistral"
        const val YOUTUBE_API_KEY = "youtube_api_key"
        const val YOUTUBE_CHANNEL_ID = "youtube_channel_id"

        // IA locale (mission "IA locale") — stockées comme chaînes pour rester
        // cohérentes avec le reste du store ; parsées par les consommateurs.
        const val LOCAL_MODEL_ID = "local_model_id"
        const val LOCAL_CONTEXT_SIZE = "local_context_size"
        const val LOCAL_MAX_TOKENS = "local_max_tokens"
        const val LOCAL_TEMPERATURE = "local_temperature"
        const val ACTIVE_PROVIDER_ID = "active_provider_id"
    }
}
