package com.rapsound.ai

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import com.rapsound.ai.data.ai.AiProviderRegistry
import com.rapsound.ai.data.local.LocalDatabase
import com.rapsound.ai.diagnostics.CrashLogger

// Bootstrap au démarrage : base de données locale (Room — plus de Firestore, tout reste
// sur l'appareil), stockage local de clés API branché sur le registre de fournisseurs IA
// (§33/§35), capture de crash locale (diagnostics/CrashLogger.kt — jamais envoyée à un
// tiers), et gestion de la RAM du modèle local (§PERFORMANCE : "déchargement si nécessaire").
class RapSoundApplication : Application(), ComponentCallbacks2 {
    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
        LocalDatabase.init(this)
        AiProviderRegistry.init(this)
    }

    // Le modèle Qwen 3 chargé peut occuper plusieurs Go de RAM. Sous pression mémoire
    // (app en arrière-plan depuis un moment, ou système à court de RAM), on le décharge
    // — il sera rechargé automatiquement au prochain message (§PERFORMANCE). On ne décharge
    // volontairement PAS sur les niveaux "légers" (TRIM_MEMORY_RUNNING_*) pour éviter de
    // recharger le modèle à chaque fois que l'app perd brièvement le focus.
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when (level) {
            ComponentCallbacks2.TRIM_MEMORY_BACKGROUND,
            ComponentCallbacks2.TRIM_MEMORY_MODERATE,
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE,
            ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                runCatching { AiProviderRegistry.localProviderInstance().unload() }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching { AiProviderRegistry.localProviderInstance().unload() }
    }
}
