package com.rapsound.ai.data.ai

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

// Fournisseur par défaut, gratuit et local — permet de tester toute l'app sans clé API (§34).
// Les vrais fournisseurs sont LocalAiProvider (Qwen embarqué), GeminiProvider et
// OpenAiCompatibleProvider (OpenRouter/Mistral).
class EchoAiProvider : AiProvider {
    override val id = "echo"
    override val displayName = "Écho local (aucune clé requise)"
    override val isFree = true
    override val isLocal = true

    override fun sendMessageStream(history: List<AiMessage>, systemPrompt: String): Flow<String> = flow {
        delay(400)
        val lastUserMessage = history.lastOrNull { it.role == AiMessage.Role.USER }
        val imageNote = lastUserMessage?.images?.takeIf { it.isNotEmpty() }
            ?.let { " (+ ${it.size} image(s) jointe(s), non analysées par ce fournisseur de test)" }
            .orEmpty()
        emit(
            "(Réponse de test — aucun vrai modèle n'est actif.)\n\n" +
                "Tu as demandé : « ${lastUserMessage?.content.orEmpty()} »$imageNote\n\n" +
                "Installe le modèle local (Paramètres → IA) ou configure Gemini pour obtenir une " +
                "vraie réponse de RapSound AI."
        )
    }
}
