package com.example.monapp;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.InputStream;

public final class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 40);
        root.setBackgroundColor(Color.rgb(248, 250, 252));
        TextView element0 = new TextView(this);
        element0.setText("Bienvenue");
        element0.setTextSize(28f);
        element0.setTextColor(Color.parseColor("#7c3aed"));
        element0.setGravity(Gravity.CENTER_HORIZONTAL);
        element0.setPadding(0, 10, 0, 10);
        root.addView(element0, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView element1 = new TextView(this);
        element1.setText("Créez votre première application mobile sans code.");
        element1.setTextSize(17f);
        element1.setTextColor(Color.rgb(35, 43, 58));
        element1.setGravity(Gravity.CENTER_HORIZONTAL);
        element1.setPadding(0, 10, 0, 10);
        root.addView(element1, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView element2 = new TextView(this);
        element2.setText("SALUT 👋");
        element2.setTextSize(25f);
        element2.setTextColor(Color.rgb(35, 43, 58));
        element2.setGravity(Gravity.CENTER_HORIZONTAL);
        element2.setPadding(0, 10, 0, 10);
        root.addView(element2, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        scroll.addView(root);
        setContentView(scroll);
    }
}
