package com.rapsound.ai.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.rapsound.ai.ui.screens.analytics.AnalyticsScreen
import com.rapsound.ai.ui.screens.chat.ChatScreen
import com.rapsound.ai.ui.screens.chat.ChatViewModel
import com.rapsound.ai.ui.screens.history.HistoryScreen
import com.rapsound.ai.ui.screens.memory.MemoryScreen
import com.rapsound.ai.ui.screens.projects.ProjectsScreen
import com.rapsound.ai.ui.screens.settings.SettingsScreen

@Composable
fun RapSoundNavGraph(navController: NavHostController, chatViewModel: ChatViewModel) {
    NavHost(navController = navController, startDestination = Screen.Chat.route) {
        composable(Screen.Chat.route) {
            ChatScreen(
                viewModel = chatViewModel,
                onOpenSettings = {
                    navController.navigate(Screen.Settings.route) {
                        launchSingleTop = true
                    }
                }
            )
        }
        composable(Screen.History.route) {
            HistoryScreen(
                onOpenConversation = { id ->
                    chatViewModel.openConversation(id)
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.Chat.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }
        composable(Screen.Memory.route) { MemoryScreen() }
        composable(Screen.Projects.route) {
            ProjectsScreen(
                onOpenConversation = { id ->
                    chatViewModel.openConversation(id)
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.Chat.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }
        composable(Screen.Analytics.route) { AnalyticsScreen() }
        composable(Screen.Settings.route) { SettingsScreen() }
    }
}
