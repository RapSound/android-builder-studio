package com.rapsound.ai.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Chat : Screen("chat", "Conversation", Icons.Filled.Chat)
    object History : Screen("history", "Historique", Icons.Filled.History)
    object Memory : Screen("memory", "Mémoire RapSound", Icons.Filled.Psychology)
    object Projects : Screen("projects", "Projets", Icons.Filled.Folder)
    object Analytics : Screen("analytics", "Analyses", Icons.Filled.BarChart)
    object Settings : Screen("settings", "Paramètres", Icons.Filled.Settings)

    companion object {
        val drawerItems = listOf(Chat, History, Memory, Projects, Analytics, Settings)
    }
}
