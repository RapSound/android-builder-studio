# Intégration llama.cpp — étape manuelle requise

Tout le pont JNI (`llama-bridge.cpp`/`.h`), la config CMake, le wrapper Kotlin
(`LlamaBridge.kt`) et le fournisseur (`LocalAiProvider.kt`) sont déjà écrits et branchés
dans l'app. La seule pièce manquante est **le code source de llama.cpp lui-même** — un
dépôt C++ tiers de plusieurs centaines de fichiers, trop volumineux pour être généré ou
vendorisé à la main ici.

## Ce qu'il faut faire (une seule fois)

Depuis la racine du projet Android (là où se trouve `settings.gradle.kts`) :

```bash
git submodule add https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
git submodule update --init --recursive
```

Puis synchronise Gradle dans Android Studio. `app/build.gradle.kts` détecte
automatiquement la présence de `app/src/main/cpp/llama.cpp/CMakeLists.txt`
(variable `llamaCppPresent`) et active le build natif — aucune autre config à toucher.

## Pourquoi ce n'est pas déjà fait

- Pas d'accès réseau dans l'environnement où ce projet a été généré : impossible de
  cloner le dépôt.
- Même avec accès réseau, embarquer directement les sources de llama.cpp dans les
  réponses aurait été peu pratique (des centaines de fichiers C/C++).
- En sous-module git, tu gardes le contrôle total de la version (voir ci-dessous).

## Épingler une version qui fonctionne

L'API C de llama.cpp évolue. `llama-bridge.cpp` est écrit contre l'API "moderne"
(séparation model/vocab, `llama_sampler_chain_*`), documentée en commentaire en tête de
fichier. Si tu rencontres des erreurs de compilation après avoir ajouté le sous-module,
la cause la plus probable est un décalage de version. Deux options :

1. **Épingler un tag connu pour fonctionner** : après `git submodule update`, fais
   `cd app/src/main/cpp/llama.cpp && git checkout <tag>` pour une release stable citée
   dans les releases GitHub de llama.cpp, puis `git commit` le nouveau pointeur de
   sous-module.
2. **Adapter le pont** : ouvre `llama.cpp/include/llama.h` et ajuste les noms de
   fonctions dans `llama-bridge.cpp` en conséquence (les points sensibles sont listés en
   commentaire en tête du fichier).

## Ce qui est déjà prêt côté app, indépendamment de cette étape

- Si la librairie native n'est pas compilée, `LlamaBridge.ensureLoaded()` échoue
  proprement (try/catch autour de `System.loadLibrary`) et `LocalAiProvider` lève une
  `NativeLibraryMissingException` claire au lieu de planter l'app.
- Gemini / OpenRouter / Mistral / Écho restent pleinement fonctionnels avec ou sans le
  sous-module.
- `app/build.gradle.kts` ne branche `externalNativeBuild` que si le sous-module est
  présent, donc le module Kotlin compile normalement tant que cette étape n'est pas faite.

## Après l'intégration : télécharger un modèle

Une fois l'app compilée avec le sous-module, va dans **Paramètres → IA locale**, choisis
un modèle (Qwen 3 1.7B/4B/8B selon la RAM du téléphone) et appuie sur *Télécharger*. Le
fichier GGUF est stocké dans le stockage privé de l'app (`files/models/`) ; une fois
téléchargé, plus aucun appel réseau n'est nécessaire pour discuter avec l'IA locale.
