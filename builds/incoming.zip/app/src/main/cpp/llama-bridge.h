#pragma once
#include <jni.h>

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_rapsound_ai_data_ai_local_LlamaBridge_loadModel(
    JNIEnv *env, jobject thiz, jstring modelPath, jint contextSize, jint nThreads);

JNIEXPORT void JNICALL
Java_com_rapsound_ai_data_ai_local_LlamaBridge_freeModel(
    JNIEnv *env, jobject thiz, jlong handle);

JNIEXPORT void JNICALL
Java_com_rapsound_ai_data_ai_local_LlamaBridge_generate(
    JNIEnv *env, jobject thiz, jlong handle, jstring prompt, jint maxTokens,
    jfloat temperature, jobject onToken);

}
