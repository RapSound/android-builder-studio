// Pont JNI entre RapSoundAI (Kotlin) et llama.cpp (C++) — mission "IA locale".
//
// IMPORTANT : ce fichier est écrit contre l'API "moderne" de llama.cpp (séparation
// model/vocab introduite en 2024, chaîne de sampling llama_sampler_chain_*). Si le
// commit du sous-module que tu utilises est plus ancien ou plus récent, certains noms
// de fonctions peuvent avoir changé — vérifie llama.cpp/include/llama.h en cas d'erreur
// de compilation. Points les plus susceptibles de bouger :
//   - llama_model_load_from_file (anciennement llama_load_model_from_file)
//   - llama_init_from_model (anciennement llama_new_context_with_model)
//   - llama_model_get_vocab / le type llama_vocab (séparation model/vocab)
//   - la chaîne de sampling llama_sampler_chain_* (anciennement llama_sample_*)

#include "llama-bridge.h"
#include "llama.h"
#include <android/log.h>
#include <string>
#include <vector>

#define LOG_TAG "RapSoundLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

struct LlamaSession {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
};

bool g_backend_initialized = false;

void ensure_backend() {
    if (!g_backend_initialized) {
        llama_backend_init();
        g_backend_initialized = true;
    }
}

}  // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_rapsound_ai_data_ai_local_LlamaBridge_loadModel(
    JNIEnv *env, jobject /*thiz*/, jstring modelPath, jint contextSize, jint nThreads) {
    ensure_backend();

    const char *path = env->GetStringUTFChars(modelPath, nullptr);

    llama_model_params model_params = llama_model_default_params();
    // Tout tourne sur CPU sur mobile : pas de n_gpu_layers ici. Si le device supporte un
    // backend GPU llama.cpp (Vulkan/OpenCL), c'est le prochain axe d'optimisation naturel.
    llama_model *model = llama_model_load_from_file(path, model_params);
    env->ReleaseStringUTFChars(modelPath, path);

    if (model == nullptr) {
        LOGE("Echec du chargement du modele");
        return 0;
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = static_cast<uint32_t>(contextSize);
    ctx_params.n_threads = nThreads;
    ctx_params.n_threads_batch = nThreads;

    llama_context *ctx = llama_init_from_model(model, ctx_params);
    if (ctx == nullptr) {
        LOGE("Echec de la creation du contexte");
        llama_model_free(model);
        return 0;
    }

    auto *session = new LlamaSession{model, ctx};
    LOGI("Modele charge : ctx=%d threads=%d", contextSize, nThreads);
    return reinterpret_cast<jlong>(session);
}

extern "C" JNIEXPORT void JNICALL
Java_com_rapsound_ai_data_ai_local_LlamaBridge_freeModel(
    JNIEnv * /*env*/, jobject /*thiz*/, jlong handle) {
    if (handle == 0) return;
    auto *session = reinterpret_cast<LlamaSession *>(handle);
    if (session->ctx) llama_free(session->ctx);
    if (session->model) llama_model_free(session->model);
    delete session;
}

extern "C" JNIEXPORT void JNICALL
Java_com_rapsound_ai_data_ai_local_LlamaBridge_generate(
    JNIEnv *env, jobject /*thiz*/, jlong handle, jstring prompt, jint maxTokens,
    jfloat temperature, jobject onToken) {
    if (handle == 0) return;
    auto *session = reinterpret_cast<LlamaSession *>(handle);
    llama_model *model = session->model;
    llama_context *ctx = session->ctx;
    const llama_vocab *vocab = llama_model_get_vocab(model);

    // --- Callback Kotlin (String) -> Boolean, appelé depuis ce thread natif pour
    // chaque fragment de texte généré. Retourner false interrompt la génération
    // (annulation, voir LocalAiProvider.sendMessageStream). ---
    jclass fnClass = env->GetObjectClass(onToken);
    jmethodID invokeMethod = env->GetMethodID(fnClass, "invoke", "(Ljava/lang/Object;)Ljava/lang/Object;");
    jclass booleanClass = env->FindClass("java/lang/Boolean");
    jmethodID booleanValue = env->GetMethodID(booleanClass, "booleanValue", "()Z");

    auto emit_token = [&](const std::string &piece) -> bool {
        jstring jpiece = env->NewStringUTF(piece.c_str());
        jobject result = env->CallObjectMethod(onToken, invokeMethod, jpiece);
        bool cont = true;
        if (result != nullptr) {
            cont = env->CallBooleanMethod(result, booleanValue);
            env->DeleteLocalRef(result);
        }
        env->DeleteLocalRef(jpiece);
        return cont;
    };

    // --- Tokenisation du prompt (déjà formaté avec le gabarit de chat Qwen côté Kotlin) ---
    const char *prompt_chars = env->GetStringUTFChars(prompt, nullptr);
    std::string prompt_str(prompt_chars);
    env->ReleaseStringUTFChars(prompt, prompt_chars);

    int n_prompt_max = static_cast<int>(prompt_str.size()) + 32;
    std::vector<llama_token> tokens(n_prompt_max);
    int n_tokens = llama_tokenize(
        vocab, prompt_str.c_str(), static_cast<int32_t>(prompt_str.size()),
        tokens.data(), n_prompt_max, /*add_special=*/true, /*parse_special=*/true);
    if (n_tokens < 0) {
        // Le buffer était trop petit : llama_tokenize renvoie -n_tokens_requis.
        tokens.resize(-n_tokens);
        n_tokens = llama_tokenize(
            vocab, prompt_str.c_str(), static_cast<int32_t>(prompt_str.size()),
            tokens.data(), -n_tokens, true, true);
    }
    tokens.resize(n_tokens);

    // --- Chaîne de sampling : température + tirage aléatoire pondéré ---
    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    llama_sampler *smpl = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    // --- Traitement du prompt (prefill) ---
    llama_batch batch = llama_batch_get_one(tokens.data(), static_cast<int32_t>(tokens.size()));
    if (llama_decode(ctx, batch) != 0) {
        LOGE("Echec du decode initial (prompt trop long pour le contexte ?)");
        llama_sampler_free(smpl);
        return;
    }

    // --- Génération token par token, avec streaming vers Kotlin ---
    for (int i = 0; i < maxTokens; i++) {
        llama_token new_token = llama_sampler_sample(smpl, ctx, -1);
        llama_sampler_accept(smpl, new_token);

        if (llama_vocab_is_eog(vocab, new_token)) {
            break;
        }

        char piece_buf[256];
        int piece_len = llama_token_to_piece(vocab, new_token, piece_buf, sizeof(piece_buf), 0, true);
        if (piece_len < 0) {
            break;
        }
        std::string piece(piece_buf, piece_len);

        if (!emit_token(piece)) {
            LOGI("Generation annulee par l'utilisateur");
            break;
        }

        llama_batch next_batch = llama_batch_get_one(&new_token, 1);
        if (llama_decode(ctx, next_batch) != 0) {
            LOGE("Echec du decode en cours de generation");
            break;
        }
    }

    llama_sampler_free(smpl);
}
