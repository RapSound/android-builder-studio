plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

// IA locale (mission "IA locale") — le sous-module llama.cpp n'est pas fourni dans ce
// projet (dépôt C++ tiers volumineux, voir app/src/main/cpp/README.md pour l'ajouter).
// Tant qu'il est absent, on NE branche PAS externalNativeBuild du tout : le module Kotlin
// continue de compiler normalement et l'app reste utilisable avec Gemini/OpenRouter/
// Mistral/Écho — seul LocalAiProvider signalera au runtime que le modèle local est
// indisponible (voir LlamaBridge.ensureLoaded()). Une fois le sous-module ajouté, ce
// flag passe à true automatiquement et le build natif s'active.
val llamaCppPresent = file("src/main/cpp/llama.cpp/CMakeLists.txt").exists()

android {
    namespace = "com.rapsound.ai"
    compileSdk = 34
    if (llamaCppPresent) {
        ndkVersion = "26.1.10909125"
    }

    defaultConfig {
        applicationId = "com.rapsound.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-skeleton"

        if (llamaCppPresent) {
            // llama.cpp compilé pour arm64 uniquement : c'est l'architecture de la
            // quasi-totalité des téléphones Android modernes, et limiter les ABI réduit
            // fortement la taille de l'APK.
            ndk {
                abiFilters += listOf("arm64-v8a")
            }
            externalNativeBuild {
                cmake {
                    cppFlags += "-std=c++17"
                    arguments += "-DANDROID_STL=c++_shared"
                }
            }
        }
    }

    if (llamaCppPresent) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.22.1"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Stockage 100% local — plus de Firestore/Firebase. Room pour les données structurées
    // (mémoire, projets, conversations, messages, objectif), DataStore pour les préférences
    // (déjà en place, voir data/settings/ApiKeyStore.kt), stockage interne pour les fichiers.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Stockage local des clés API / préférences (§35)
    implementation("androidx.datastore:datastore-preferences:1.0.0")

    // Appels HTTP directs vers les fournisseurs IA / YouTube Data API (§33, §15)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Chargement des images (pièces jointes, §22)
    implementation("io.coil-kt:coil-compose:2.6.0")

    debugImplementation("androidx.compose.ui:ui-tooling")

    // Tests unitaires (ex. IdeaParser, StrategistParser — logique pure, sans Android)
    testImplementation("junit:junit:4.13.2")
}
