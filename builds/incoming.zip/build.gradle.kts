// Top-level build file
plugins {
    id("com.android.application") version "8.2.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    // Room (données 100% locales — plus de Firestore) : KSP pour le compilateur d'annotations.
    id("com.google.devtools.ksp") version "1.9.22-1.0.17" apply false
}
