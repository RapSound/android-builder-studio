# RecallMe - Guide de Construction de l'APK

## 📋 Prérequis

- **Java 11+** installé et configuré (vérifier avec `java -version`)
- **Android SDK** (API 31 minimum)
- **Gradle 8.7** (inclus dans le wrapper)

## 🔧 Étapes de Configuration

### 1. Télécharger gradle-wrapper.jar (IMPORTANT)

Le fichier `gradle/wrapper/gradle-wrapper.jar` manque et doit être téléchargé :

```bash
# Option 1 : Télécharger manuellement
curl -o gradle/wrapper/gradle-wrapper.jar \
  "https://github.com/gradle/gradle/releases/download/v8.7.0/gradle-8.7-wrapper.jar"
```

Ou utiliser Android Studio qui téléchargera automatiquement le wrapper lors de la première synchronisation.

### 2. Configurer les Variables d'Environnement

```bash
# Linux/Mac
export ANDROID_HOME=$HOME/Android/Sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export PATH=$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools:$PATH

# Windows (PowerShell)
$env:ANDROID_HOME="C:\Users\YourUsername\AppData\Local\Android\Sdk"
$env:PATH="$env:ANDROID_HOME\tools;$env:ANDROID_HOME\platform-tools;$env:PATH"
```

### 3. Accepter les Licences Android

```bash
# Télécharger les SDK nécessaires
sdkmanager "platforms;android-34" "build-tools;34.0.0" "ndk;25.2.9519653"

# Accepter les licences
yes | sdkmanager --licenses
```

## 🚀 Construction

### Build Debug APK (plus rapide)
```bash
./gradlew assembleDebug
# Résultat : app/build/outputs/apk/debug/app-debug.apk
```

### Build Release APK (optimisé, 3-5 MB)
```bash
./gradlew assembleRelease
# Résultat : app/build/outputs/apk/release/app-release-unsigned.apk
```

#### ⚠️ Signer l'APK Release

Créer un keystore :
```bash
keytool -genkey -v -keystore release.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias recallme
# Mémoriser le mot de passe
```

Ajouter à `app/build.gradle.kts` dans la section `android{}` :

```kotlin
signingConfigs {
    create("release") {
        storeFile = file("../release.keystore")
        storePassword = "your_keystore_password"
        keyAlias = "recallme"
        keyPassword = "your_key_password"
    }
}

buildTypes {
    release {
        signingConfig = signingConfigs.getByName("release")
        isMinifyEnabled = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
}
```

Puis :
```bash
./gradlew assembleRelease
# Résultat : app/build/outputs/apk/release/app-release.apk
```

## 🧹 Commandes Utiles

```bash
# Nettoyer les builds
./gradlew clean

# Synchroniser les dépendances
./gradlew sync

# Vérifier les dépendances
./gradlew dependencies

# Lancer les tests
./gradlew test

# Build verbeux (pour debug)
./gradlew assembleDebug --debug
```

## ❌ Dépannage

### "Gradle wrapper jar not found"
→ Télécharger gradle-wrapper.jar comme indiqué ci-dessus

### "ANDROID_HOME not set"
→ Configurer les variables d'environnement (voir étape 2)

### "compileSdkVersion not found"
→ Exécuter `sdkmanager "platforms;android-34"`

### "Gradle out of memory"
→ Augmenter la RAM dans `gradle.properties` :
```properties
org.gradle.jvmargs=-Xmx2048m -XX:MaxPermSize=512m
```

## 📦 Déployer sur le Play Store

1. Créer un keystore pour la production (voir "Signer l'APK Release")
2. Générer un APK signé en Release
3. Télécharger vers https://play.google.com/console

---

**Notes** :
- L'app cible Android 14 (API 34)
- Minimum : Android 7.1 (API 25)
- Permissions nécessaires : LOCATION, CAMERA, VIBRATE, POST_NOTIFICATIONS

