#!/usr/bin/env bash
# Build de l'APK RecallMe SANS Android Studio (Linux / macOS).
# Installe automatiquement le SDK Android en ligne de commande si besoin.
set -euo pipefail

cd "$(dirname "$0")"

CMDLINE_VERSION="11076708"   # cmdline-tools 12.0
SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/android-sdk}"

command -v java >/dev/null 2>&1 || { echo "Java 17 est requis (apt install openjdk-17-jdk / brew install openjdk@17)"; exit 1; }

if [ ! -d "$SDK_ROOT/cmdline-tools/latest" ]; then
  echo "==> Installation du SDK Android dans $SDK_ROOT"
  mkdir -p "$SDK_ROOT/cmdline-tools"
  case "$(uname -s)" in
    Darwin) OS=mac ;;
    *)      OS=linux ;;
  esac
  TMP_ZIP="$(mktemp -d)/tools.zip"
  curl -L -o "$TMP_ZIP" "https://dl.google.com/android/repository/commandlinetools-${OS}-${CMDLINE_VERSION}_latest.zip"
  unzip -q "$TMP_ZIP" -d "$SDK_ROOT/cmdline-tools"
  mv "$SDK_ROOT/cmdline-tools/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
fi

export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_HOME="$SDK_ROOT"
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$PATH"

yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

echo "sdk.dir=$SDK_ROOT" > local.properties

chmod +x ./gradlew
./gradlew assembleDebug --no-daemon

echo
echo "APK généré : app/build/outputs/apk/debug/app-debug.apk"
echo "Copie-le sur ton téléphone et installe-le (autoriser les sources inconnues)."
