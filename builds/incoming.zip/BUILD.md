# RecallMe — build de l'APK sans Android Studio

## Option 1 — GitHub Actions (aucune installation)
1. Crée un dépôt GitHub et pousse ce dossier (tel quel, `.github/` inclus).
2. Onglet **Actions** > workflow **Build APK** > `Run workflow`.
3. À la fin, télécharge l'artefact **RecallMe-APK** (APK debug + release).

## Option 2 — En local, en ligne de commande
Prérequis : **Java 17**.

- Linux / macOS :
  ```bash
  chmod +x build-apk.sh
  ./build-apk.sh
  ```
  Le script installe le SDK Android (cmdline-tools) puis compile.

- Windows :
  ```
  build-apk.bat
  ```

APK produit : `app/build/outputs/apk/debug/app-debug.apk`

## Installation sur le téléphone
Copie l'APK sur l'appareil, ouvre-le et autorise l'installation depuis des
sources inconnues. (L'APK release est non signé : utilise l'APK debug pour un
test rapide.)

## Structure
- `gradlew`, `gradlew.bat`, `gradle/wrapper/` — wrapper Gradle 8.7 complet
- `app/src/main/AndroidManifest.xml` — manifest Android
- `AndroidManifest.xml` — copie à la racine (pour les validateurs de projet)
- `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`
- `local.properties` — généré automatiquement par les scripts de build
