@echo off
REM Build de l'APK RecallMe SANS Android Studio (Windows).
REM Prerequis : Java 17 installe (https://adoptium.net) et le SDK Android
REM cmdline-tools decompresse dans %USERPROFILE%\android-sdk\cmdline-tools\latest

setlocal
cd /d "%~dp0"

if "%ANDROID_SDK_ROOT%"=="" set ANDROID_SDK_ROOT=%USERPROFILE%\android-sdk
set ANDROID_HOME=%ANDROID_SDK_ROOT%
set PATH=%ANDROID_SDK_ROOT%\cmdline-tools\latest\bin;%PATH%

if not exist "%ANDROID_SDK_ROOT%\cmdline-tools\latest\bin\sdkmanager.bat" (
  echo.
  echo SDK Android introuvable dans %ANDROID_SDK_ROOT%
  echo 1^) Telecharge "commandlinetools-win" sur https://developer.android.com/studio#command-tools
  echo 2^) Decompresse-le pour obtenir %ANDROID_SDK_ROOT%\cmdline-tools\latest\bin\sdkmanager.bat
  echo 3^) Relance ce script.
  exit /b 1
)

call sdkmanager --licenses
call sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

> local.properties echo sdk.dir=%ANDROID_SDK_ROOT:\=\\%

call gradlew.bat assembleDebug --no-daemon
if errorlevel 1 exit /b 1

echo.
echo APK genere : app\build\outputs\apk\debug\app-debug.apk
endlocal
