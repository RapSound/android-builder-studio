# Firebase / google-services.json

La compilation echouait avec :
`Execution failed for task ':app:processDebugGoogleServices' - File google-services.json is missing.`

## Ce qui a ete ajoute
`app/google-services.json` : un fichier **placeholder** valide (package `com.yttrendpulse.app`).
Il permet a Gradle de compiler et de generer l'APK.

## Important
Avec ce placeholder, l'app se compile et s'installe, mais les services Firebase
(Auth, Firestore, Storage) ne fonctionneront PAS en runtime.

Pour une app fonctionnelle :
1. https://console.firebase.google.com -> creer un projet
2. Ajouter une app Android avec le package `com.yttrendpulse.app`
3. Telecharger le vrai `google-services.json`
4. Remplacer `app/google-services.json` par celui-ci

## Alternative : compiler sans Firebase
- `app/build.gradle` : supprimer `id 'com.google.gms.google-services'` et les dependances `com.google.firebase:*`
- `build.gradle` (racine) : supprimer `id 'com.google.gms.google-services' version ...`
- Puis retirer/remplacer le code Kotlin qui importe Firebase (repositories, auth).
